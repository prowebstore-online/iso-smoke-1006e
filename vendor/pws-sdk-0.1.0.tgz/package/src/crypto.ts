// Shared HMAC-SHA256 + base64url utilities used by OAuth state, magic links,
// and console cookie signing.

export function b64url(s: string): string {
  return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

export function b64urlDecode(s: string): string {
  return atob(s.replace(/-/g, '+').replace(/_/g, '/'));
}

/** SHA-256 of a string, hex-encoded. */
export async function sha256Hex(data: string): Promise<string> {
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(data));
  return Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, '0')).join('');
}

export async function hmacSha256(data: string, keyMaterial: string): Promise<string> {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey(
    'raw',
    enc.encode(keyMaterial),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign'],
  );
  const sig = await crypto.subtle.sign('HMAC', key, enc.encode(data));
  const bytes = new Uint8Array(sig);
  let bin = '';
  for (const b of bytes) bin += String.fromCharCode(b);
  return b64url(bin);
}

/** Sign a time-limited state token. Format: base64url(JSON) + "." + HMAC. */
export async function signTimedToken(
  payload: Record<string, unknown>,
  secret: string,
): Promise<string> {
  const body = b64url(JSON.stringify({ ...payload, ts: Date.now() }));
  const sig = await hmacSha256(body, secret);
  return `${body}.${sig}`;
}

/** Verify and decode a timed token. Returns null if invalid or expired. */
export async function verifyTimedToken<T extends Record<string, unknown>>(
  token: string,
  secret: string,
  ttlMs: number,
): Promise<(T & { ts: number }) | null> {
  const dot = token.lastIndexOf('.');
  if (dot < 0) return null;
  const body = token.slice(0, dot);
  const sig = token.slice(dot + 1);
  const expected = await hmacSha256(body, secret);
  if (sig.length !== expected.length) return null;
  let diff = 0;
  for (let i = 0; i < expected.length; i++) {
    diff |= expected.charCodeAt(i) ^ sig.charCodeAt(i);
  }
  if (diff !== 0) return null;
  try {
    const payload = JSON.parse(b64urlDecode(body)) as T & { ts?: number };
    if (!payload.ts) return null;
    if (Date.now() - payload.ts > ttlMs) return null;
    return payload as T & { ts: number };
  } catch {
    return null;
  }
}
