// Quality testing utilities for PWS sites.
// Import in your site's test suite to validate template/content quality.
//
// Usage:
//   import { runQualityChecks } from '@pws/sdk/testing';
//
// For now, the quality tests are in quality.test.ts and run via vitest.
// Future: export individual check functions for per-site test suites.

export {};
