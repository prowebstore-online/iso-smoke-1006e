// Single source of truth for the platform's design tokens — fonts, colors,
// spacing — shared by the admin, the console, and any server-rendered surface.
// Define typography ONCE here so it can't drift (or break) per surface.
//
// IMPORTANT: inject CSS via <StyleTag> (or raw()), never as JSX children. Hono
// HTML-escapes children, which turns `"Segoe UI"` into `&quot;…&quot;` — invalid
// CSS that silently breaks the whole stylesheet (this caused the platform-wide
// Times New Roman bug). StyleTag injects raw, so that class of bug can't recur.

import { html, raw } from 'hono/html';
import type { FC } from 'hono/jsx';

/** Canonical font stacks — system fonts, so there's no remote dependency to be
 *  blocked by privacy tools/networks (which caused the earlier serif fallback). */
export const FONT_SANS =
  'ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif';
export const FONT_MONO = 'ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace';

/** Shared :root tokens + base element resets. Both admin and console inject this
 *  first, then add their own component CSS on top — so palette + typography are
 *  identical everywhere. */
export const DESIGN_TOKENS = `
  :root {
    color-scheme: dark;
    --bg: #0b1020;
    --surface: #131a2e;
    --surface-2: #1b2440;
    --border: #273449;
    --text: #e6edf7;
    --muted: #94a3b8;
    --primary: #a78bfa;
    --primary-on: #0b1020;
    --danger: #f87171;
    --success: #34d399;
    --radius: 10px;
    --font: ${FONT_SANS};
    --font-display: ${FONT_SANS};
    --font-mono: ${FONT_MONO};
  }
  *, *::before, *::after { box-sizing: border-box; }
  html, body { margin: 0; padding: 0; height: 100%; }
  body {
    background: var(--bg);
    color: var(--text);
    font-family: var(--font);
    font-size: 14px;
    line-height: 1.5;
    -webkit-font-smoothing: antialiased;
    text-rendering: optimizeLegibility;
  }
  a { color: var(--primary); text-decoration: none; }
  a:hover { text-decoration: underline; }
  code, pre, kbd, samp { font-family: var(--font-mono); }
`;

/** Inject a CSS string into a <style> tag SAFELY (raw, never escaped). Use this
 *  instead of <style>{css}</style> anywhere CSS is server-rendered. */
export const StyleTag: FC<{ css: string }> = ({ css }) => html`<style>${raw(css)}</style>`;
