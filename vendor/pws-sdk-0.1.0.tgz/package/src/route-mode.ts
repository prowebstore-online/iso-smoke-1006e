// Determine whether a request is hitting a tenant subdomain (renders that
// tenant's site) or a platform hostname (admin, console).
//
// TENANT mode: request URL is {slug}.prowebstore.online/...
//   - site_id derived from the Host header, never from the URL path
//   - only renders pages; admin endpoints return 404
//
// ADMIN mode: admin.prowebstore.online (primary) or api.prowebstore.online (legacy)
//   - admin UI + API endpoints + agent endpoint
//   - cookie or bearer auth required
//
// CONSOLE mode: prowebstore.online/console/* (path-based, no subdomain)
//   - platform dashboard for site owners
//   - shares cookies with the marketing site (same origin)
//
// Reserved subdomains (www, app, media) are not treated as tenants.

export const RESERVED_SUBDOMAINS = new Set([
  'www',
  'api',
  'app',
  'admin',
  'media',
  'console', // legacy — now path-based, but keep reserved so it's not a tenant
  'manage',
  'mcp',
]);

const PLATFORM_DOMAIN = 'prowebstore.online';
const ADMIN_HOST_SUFFIX = '.workers.dev';

export type RouteMode =
  | { kind: 'tenant'; siteId: string; hostname: string }
  | { kind: 'admin'; hostname: string }
  | { kind: 'console'; hostname: string }
  | { kind: 'custom_domain'; hostname: string }
  | { kind: 'reserved'; hostname: string; subdomain: string };

/**
 * Classify a request by hostname + path. The path is needed to detect
 * apex /console/* requests (path-based console on the marketing domain).
 */
export function classifyHost(hostname: string, pathname?: string): RouteMode {
  const lower = hostname.toLowerCase();

  // Workers.dev URL -> admin
  if (lower.endsWith(ADMIN_HOST_SUFFIX)) {
    return { kind: 'admin', hostname: lower };
  }

  // Subdomains of the platform domain
  const suffix = `.${PLATFORM_DOMAIN}`;
  if (lower.endsWith(suffix)) {
    const subdomain = lower.slice(0, -suffix.length);
    if (subdomain.length === 0 || subdomain === PLATFORM_DOMAIN) {
      return { kind: 'reserved', hostname: lower, subdomain: '' };
    }

    // admin.prowebstore.online -- primary admin host
    // api.prowebstore.online -- legacy, same as admin
    // manage.prowebstore.online -- legacy, same as admin
    if (subdomain === 'admin' || subdomain === 'api' || subdomain === 'manage') {
      return { kind: 'admin', hostname: lower };
    }
    // Legacy subdomain console — redirect to path-based
    if (subdomain === 'console') {
      return { kind: 'console', hostname: lower };
    }
    if (RESERVED_SUBDOMAINS.has(subdomain)) {
      return { kind: 'reserved', hostname: lower, subdomain };
    }
    if (!isValidSiteSlug(subdomain)) {
      return { kind: 'reserved', hostname: lower, subdomain };
    }
    return { kind: 'tenant', siteId: subdomain, hostname: lower };
  }

  // Apex prowebstore.online — check for /console/* path
  if (lower === PLATFORM_DOMAIN) {
    if (pathname && (pathname === '/console' || pathname.startsWith('/console/'))) {
      return { kind: 'console', hostname: lower };
    }
    return { kind: 'reserved', hostname: lower, subdomain: '' };
  }

  // Unknown hostname — could be a custom domain. Mark for D1 lookup.
  return { kind: 'custom_domain', hostname: lower };
}

/**
 * Tenant slug = lowercase letters, digits, hyphens. Length 1-63 (DNS label
 * limit). No leading/trailing hyphen.
 */
export function isValidSiteSlug(s: string): boolean {
  return /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(s);
}
