/** @jsxRuntime automatic */
/** @jsxImportSource hono/jsx */
// Admin UI routes — server-rendered Hono JSX. Mounted on the admin host
// (admin.prowebstore.online, legacy: api.prowebstore.online) under `/admin/*`.
//
// Auth: cookie-based session (pws_session=<siteId>:<token>). Login form
// exchanges email+password via the existing SiteDO.authenticate path, sets
// the cookie, and 302s to the dashboard.
//
// OAuth routes (Google, GitHub, Magic Link) are in admin/oauth.ts.

import { Hono } from 'hono';
import { resolveCookieSession } from '../auth.ts';
import type { SiteRpc } from '../do/rpc.ts';
import { type Env, siteStub } from '../env.ts';
import { buildSessionCookie, clearSessionCookie } from './cookies.ts';
import { mountOAuthRoutes } from './oauth.tsx';
import {
  AdminEntityView,
  ChatPage,
  DashboardPage,
  LoginPage,
  PagesPage,
  SettingsPage,
  ThemeEditorPage,
  UsersPage,
} from './pages.tsx';

// biome-ignore lint/suspicious/noExplicitAny: parent app supplies wider Variables
type AppEnv = { Bindings: Env; Variables: any };

async function siteTitleOf(stub: SiteRpc): Promise<string> {
  try {
    const snap = await stub.siteSnapshot();
    return snap.config?.title ?? '';
  } catch {
    return '';
  }
}

const SECURITY_HEADERS: Record<string, string> = {
  'content-security-policy':
    "default-src 'self'; " +
    "script-src 'self' 'unsafe-inline'; " +
    "style-src 'self' 'unsafe-inline'; " +
    "img-src 'self' data: https://media.prowebstore.online; " +
    "font-src 'self' data:; " +
    "connect-src 'self'; " +
    'frame-src https://*.prowebstore.online; ' +
    "form-action 'self' https://accounts.google.com https://github.com; " +
    "frame-ancestors 'none'; " +
    "base-uri 'self'; " +
    "object-src 'none'",
  'x-content-type-options': 'nosniff',
  'referrer-policy': 'strict-origin-when-cross-origin',
  'x-frame-options': 'DENY',
  'strict-transport-security': 'max-age=31536000; includeSubDomains',
};

function hasGoogle(env: Env) {
  return !!(env.GOOGLE_CLIENT_ID && env.GOOGLE_CLIENT_SECRET);
}
function hasGitHub(env: Env) {
  return !!(env.GITHUB_CLIENT_ID && env.GITHUB_CLIENT_SECRET);
}
function hasMagicLink(env: Env) {
  return !!env.MAGIC_LINK_SECRET;
}

function parsePrefs(cookie: string | undefined): { theme: string; fontSize: string } {
  if (!cookie) return { theme: 'dark', fontSize: 'normal' };
  const match = cookie.match(/pws_prefs=([^;]+)/);
  if (!match) return { theme: 'dark', fontSize: 'normal' };
  try {
    const p = JSON.parse(decodeURIComponent(match[1]!)) as Record<string, string>;
    return { theme: p.theme ?? 'dark', fontSize: p.fontSize ?? 'normal' };
  } catch {
    return { theme: 'dark', fontSize: 'normal' };
  }
}

export function buildAdminRoutes(): Hono<AppEnv> {
  const admin = new Hono<AppEnv>();

  admin.use('*', async (c, next) => {
    await next();
    for (const [k, v] of Object.entries(SECURITY_HEADERS)) {
      if (!c.res.headers.has(k)) c.res.headers.set(k, v);
    }
  });

  // Block members from the admin panel. Auth-flow routes (login, logout, SSO,
  // OAuth callbacks) are exempt so users can sign in/out; every other admin
  // route requires owner/editor. Without this, a self-registered member could
  // read all records (PII) and mutate site config via /admin/*.
  admin.use('*', async (c, next) => {
    const path = new URL(c.req.url).pathname;
    if (
      path.startsWith('/admin/login') ||
      path.startsWith('/admin/logout') ||
      path.startsWith('/admin/sso') ||
      path.startsWith('/admin/auth/')
    ) {
      return next();
    }
    const sess = await resolveCookieSession(c);
    if (sess && sess.user.role === 'member') {
      return c.text('Forbidden — admin access requires owner or editor role.', 403);
    }
    return next();
  });

  // ─── SSO from console ─────────────────────────────────────────────────
  admin.get('/sso', async (c) => {
    const site = c.req.query('site');
    const token = c.req.query('token');
    const exp = c.req.query('exp');
    if (!site || !token || !exp) return c.redirect('/admin/login', 302);
    const user = await siteStub(c.env, site).resolveSession(token);
    if (!user) return c.redirect('/admin/login', 302);
    const cookie = buildSessionCookie(site, token, Number(exp));
    return new Response(null, {
      status: 302,
      headers: {
        ...SECURITY_HEADERS,
        Location: '/admin',
        'Set-Cookie': cookie,
        'Cache-Control': 'no-store',
      },
    });
  });

  // ─── Login ────────────────────────────────────────────────────────────
  admin.get('/login', async (c) => {
    const sess = await resolveCookieSession(c);
    if (sess) return c.redirect('/admin', 302);
    return c.html(
      <LoginPage
        googleEnabled={hasGoogle(c.env)}
        githubEnabled={hasGitHub(c.env)}
        magicLinkEnabled={hasMagicLink(c.env)}
      />,
    );
  });

  admin.post('/login', async (c) => {
    const form = await c.req.parseBody();
    const siteId = String(form.site_id ?? '')
      .trim()
      .toLowerCase();
    const email = String(form.email ?? '').trim();
    const password = String(form.password ?? '');
    const loginProps = {
      googleEnabled: hasGoogle(c.env),
      githubEnabled: hasGitHub(c.env),
      magicLinkEnabled: hasMagicLink(c.env),
    };
    if (!siteId || !email || !password) {
      return c.html(
        <LoginPage
          error="All three fields are required."
          prefillSite={siteId}
          prefillEmail={email}
          {...loginProps}
        />,
        400,
      );
    }

    if (c.env.AUTH_RATE_LIMIT) {
      const ip = c.req.header('cf-connecting-ip') ?? c.req.header('x-forwarded-for') ?? 'unknown';
      const { success } = await c.env.AUTH_RATE_LIMIT.limit({ key: `auth:${siteId}:${ip}` });
      if (!success) {
        return c.html(
          <LoginPage
            error="Too many login attempts. Try again in 60 seconds."
            prefillSite={siteId}
            prefillEmail={email}
            {...loginProps}
          />,
          429,
        );
      }
    }

    const result = await siteStub(c.env, siteId).authenticate(email, password);
    if (!result) {
      return c.html(
        <LoginPage
          error="Invalid site id, email, or password."
          prefillSite={siteId}
          prefillEmail={email}
          {...loginProps}
        />,
        401,
      );
    }
    return new Response(null, {
      status: 302,
      headers: {
        ...SECURITY_HEADERS,
        Location: '/admin',
        'Set-Cookie': buildSessionCookie(siteId, result.token, result.expires_at),
      },
    });
  });

  // ─── Logout ───────────────────────────────────────────────────────────
  admin.post('/logout', async (c) => {
    const sess = await resolveCookieSession(c);
    if (sess) {
      await siteStub(c.env, sess.siteId)
        .revokeSession(sess.token)
        .catch(() => {});
    }
    return new Response(null, {
      status: 302,
      headers: { Location: '/admin/login', 'Set-Cookie': clearSessionCookie() },
    });
  });

  // ─── OAuth (Google, GitHub, Magic Link) → admin/oauth.ts ──────────────
  mountOAuthRoutes(admin);

  // ─── Dashboard ────────────────────────────────────────────────────────
  admin.get('/', async (c) => {
    const sess = await resolveCookieSession(c);
    if (!sess) return c.redirect('/admin/login', 302);
    const stub = siteStub(c.env, sess.siteId);
    const [diag, siteTitle] = await Promise.all([stub.diagnostics(), siteTitleOf(stub)]);
    let views = await stub.listAdminViews();

    if (views.length === 0 && diag.entities > 0) {
      const schemas = await stub.listSchemas();
      for (let i = 0; i < schemas.length; i++) {
        const s = schemas[i]!;
        const layout = s.fields.some((f) => f.slug === 'status' && f.type === 'select')
          ? 'pipeline'
          : s.fields.some((f) => f.type === 'image')
            ? 'cards'
            : 'table';
        const config: Record<string, unknown> =
          layout === 'pipeline'
            ? {
                stages: s.fields.find((f) => f.slug === 'status')?.options ?? [],
                stage_field: 'status',
                card_fields: ['title'],
              }
            : layout === 'cards'
              ? {
                  image_field: s.fields.find((f) => f.type === 'image')?.slug,
                  title_field:
                    s.fields.find((f) => f.slug === 'name' || f.slug === 'title')?.slug ??
                    s.fields[0]?.slug,
                }
              : {
                  columns: s.fields
                    .filter((f) => ['text', 'email', 'number', 'select', 'date'].includes(f.type))
                    .slice(0, 5)
                    .map((f) => f.slug),
                };
        await stub.defineAdminView({
          entity_slug: s.slug,
          label: s.name_plural,
          icon: s.icon ?? s.name[0]!,
          layout,
          sort_order: i,
          config,
        });
      }
      views = await stub.listAdminViews();
    }

    let recentPosts: import('@pws/shared').EntityRecord[] = [];
    if (views.length > 0) {
      recentPosts = await stub.listRecords(views[0]!.entity_slug, { limit: 5 }).catch(() => []);
    }
    const prefs = parsePrefs(c.req.header('cookie'));
    return c.html(
      <DashboardPage
        siteId={sess.siteId}
        siteTitle={siteTitle}
        user={sess.user}
        fontSize={prefs.fontSize}
        diag={diag}
        recentPosts={recentPosts}
        adminViews={views}
      />,
    );
  });

  admin.get('/chat', async (c) => {
    const sess = await resolveCookieSession(c);
    if (!sess) return c.redirect('/admin/login', 302);
    const siteTitle = await siteTitleOf(siteStub(c.env, sess.siteId));
    return c.html(
      <ChatPage
        siteId={sess.siteId}
        siteTitle={siteTitle}
        user={sess.user}
        fontSize={parsePrefs(c.req.header('cookie')).fontSize}
      />,
    );
  });

  admin.get('/pages', async (c) => {
    const sess = await resolveCookieSession(c);
    if (!sess) return c.redirect('/admin/login', 302);
    const stub = siteStub(c.env, sess.siteId);
    const [pages, siteTitle] = await Promise.all([stub.listPages(), siteTitleOf(stub)]);
    return c.html(
      <PagesPage
        siteId={sess.siteId}
        siteTitle={siteTitle}
        user={sess.user}
        pages={pages}
        fontSize={parsePrefs(c.req.header('cookie')).fontSize}
      />,
    );
  });

  admin.get('/users', async (c) => {
    const sess = await resolveCookieSession(c);
    if (!sess) return c.redirect('/admin/login', 302);
    if (sess.user.role !== 'owner') return c.redirect('/admin', 302);
    const stub = siteStub(c.env, sess.siteId);
    const [users, siteTitle] = await Promise.all([stub.listUsers(), siteTitleOf(stub)]);
    return c.html(
      <UsersPage
        siteId={sess.siteId}
        siteTitle={siteTitle}
        user={sess.user}
        users={users}
        fontSize={parsePrefs(c.req.header('cookie')).fontSize}
      />,
    );
  });

  // ─── Settings ─────────────────────────────────────────────────────────
  admin.get('/settings', async (c) => {
    const sess = await resolveCookieSession(c);
    if (!sess) return c.redirect('/admin/login', 302);
    const siteTitle = await siteTitleOf(siteStub(c.env, sess.siteId));
    const prefs = parsePrefs(c.req.header('cookie'));
    return c.html(
      <SettingsPage
        siteId={sess.siteId}
        siteTitle={siteTitle}
        user={sess.user}
        success={c.req.query('success') ?? undefined}
        currentTheme={prefs.theme}
        currentFontSize={prefs.fontSize}
      />,
    );
  });

  admin.post('/settings', async (c) => {
    const sess = await resolveCookieSession(c);
    if (!sess) return c.redirect('/admin/login', 302);
    const form = await c.req.parseBody();
    const theme = String(form.theme ?? 'dark');
    const fontSize = String(form.font_size ?? 'normal');
    const prefsCookie = `pws_prefs=${encodeURIComponent(JSON.stringify({ theme, fontSize }))}; Path=/; Max-Age=${30 * 24 * 60 * 60}; SameSite=Lax; Secure`;
    return new Response(null, {
      status: 302,
      headers: { Location: '/admin/settings?success=saved', 'Set-Cookie': prefsCookie },
    });
  });

  // ─── Theme editor ────────────────────────────────────────────────────
  admin.get('/theme', async (c) => {
    const sess = await resolveCookieSession(c);
    if (!sess) return c.redirect('/admin/login', 302);
    const stub = siteStub(c.env, sess.siteId);
    const snap = await stub.siteSnapshot();
    const siteTitle = snap.config.title ?? sess.siteId;
    const prefs = parsePrefs(c.req.header('cookie'));
    return c.html(
      <ThemeEditorPage
        siteId={sess.siteId}
        siteTitle={siteTitle}
        user={sess.user}
        fontSize={prefs.fontSize}
        theme={snap.theme}
        success={c.req.query('success')}
        error={c.req.query('error')}
      />,
    );
  });

  admin.post('/theme', async (c) => {
    const sess = await resolveCookieSession(c);
    if (!sess) return c.redirect('/admin/login', 302);
    const form = await c.req.parseBody();
    const stub = siteStub(c.env, sess.siteId);
    const theme = {
      colors: {
        primary: String(form.primary || '#1e3a5f'),
        secondary: String(form.secondary || ''),
        accent: String(form.accent || ''),
        background: String(form.background || '#ffffff'),
        surface: String(form.surface || ''),
        text: String(form.text || '#2d3748'),
        heading: String(form.heading || ''),
      },
      fonts: {
        heading: String(form.font_heading || 'Inter, system-ui, sans-serif'),
        body: String(form.font_body || 'Inter, system-ui, sans-serif'),
      },
      radius: String(form.radius || 'md') as 'none' | 'sm' | 'md' | 'lg' | 'full',
      shadow: String(form.shadow || 'sm') as 'none' | 'sm' | 'md' | 'lg',
      spacing: String(form.spacing || 'normal') as 'compact' | 'normal' | 'relaxed',
    };
    // Remove empty optional colors
    const colors = theme.colors as Record<string, string>;
    for (const key of ['secondary', 'accent', 'surface', 'heading']) {
      if (!colors[key]) delete colors[key];
    }
    const result = await stub.setMeta('theme', theme);
    if (!result.ok) {
      return c.redirect(`/admin/theme?error=${encodeURIComponent('Invalid theme values.')}`);
    }
    return c.redirect('/admin/theme?success=saved');
  });

  // ─── Dynamic entity views ─────────────────────────────────────────────
  admin.get('/records/:entity', async (c) => {
    const sess = await resolveCookieSession(c);
    if (!sess) return c.redirect('/admin/login', 302);
    const entitySlug = c.req.param('entity');
    const stub = siteStub(c.env, sess.siteId);
    const [views, schema, records, snap] = await Promise.all([
      stub.listAdminViews(),
      stub.getSchema(entitySlug),
      stub.listRecords(entitySlug, { limit: 200 }),
      stub.siteSnapshot(),
    ]);
    if (!schema) return c.text('Entity not found', 404);
    const view = views.find((v) => v.entity_slug === entitySlug);
    return c.html(
      <AdminEntityView
        siteId={sess.siteId}
        siteTitle={snap.config.title ?? sess.siteId}
        user={sess.user}
        schema={schema}
        records={records}
        allViews={views}
        view={
          view ?? {
            id: '',
            entity_slug: entitySlug,
            label: schema.name_plural,
            icon: null,
            layout: 'table',
            sort_order: 99,
            config: {},
          }
        }
      />,
    );
  });

  return admin;
}
