/** @jsxRuntime automatic */
/** @jsxImportSource hono/jsx */
// Shared admin UI shell — dark theme, matching the marketing/tenant default.
// Single inline <style> tag; no SPA, no client framework.

import { raw } from 'hono/html';
import type { FC, PropsWithChildren } from 'hono/jsx';
import { DESIGN_TOKENS, StyleTag } from '../design-tokens.ts';
import { pwaMetaTags } from '../pwa.ts';

interface LayoutProps {
  title: string;
  siteId?: string;
  userEmail?: string;
  fontSize?: string;
}

// Component CSS only — :root tokens + base resets come from DESIGN_TOKENS.
const STYLES = `
  code, pre { font-size: 0.85em; }

  .app-header {
    display: flex;
    align-items: center;
    gap: 1.5rem;
    padding: 0.6rem 1.25rem;
    background: var(--surface);
    border-bottom: 1px solid var(--border);
    position: sticky;
    top: 0;
    z-index: 10;
  }
  .brand {
    font-weight: 700;
    font-size: 0.9rem;
    letter-spacing: -0.01em;
    flex: 0 0 auto;
    color: var(--text);
    text-decoration: none;
  }
  .brand:hover { text-decoration: none; opacity: 0.85; }
  .brand .accent { color: var(--primary); }

  .site-context {
    flex: 0 0 auto;
    padding: 0.2rem 0.7rem;
    border: 0;
    border-left: 1px solid var(--border);
    border-radius: 0;
    margin-left: 0.25rem;
    display: flex;
    flex-direction: column;
    gap: 0.05rem;
    max-width: 240px;
    background: none;
    color: inherit;
    font: inherit;
    text-align: left;
    cursor: pointer;
  }
  .site-context:hover { background: var(--surface-2); }
  .site-context-copy {
    color: #34d399;
    opacity: 0;
    transition: opacity 0.15s;
    margin-left: 0.4rem;
  }
  .site-context-title {
    font-size: 0.85rem;
    font-weight: 600;
    color: var(--text);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .site-context-slug {
    font-size: 0.7rem;
    font-family: var(--font-mono);
    color: var(--muted);
    letter-spacing: 0;
  }
  .nav-burger { flex: 1 1 auto; min-width: 0; }
  .nav-burger > summary { list-style: none; }
  .nav-burger > summary::-webkit-details-marker { display: none; }
  /* Chrome 2024+ hides a closed <details>'s content via ::details-content
     { content-visibility: hidden }, which a child's display:flex can't override —
     so the desktop nav (details is closed; the ☰ toggle is display:none) vanished
     entirely. Force the content visible; mobile still collapses via .top-nav
     display:none (below) until the burger is [open]. */
  .nav-burger::details-content { content-visibility: visible; }
  .nav-burger-toggle {
    display: none;
    cursor: pointer;
    padding: 0.3rem 0.55rem;
    border-radius: 8px;
    font-size: 1.2rem;
    line-height: 1;
    color: var(--text);
    user-select: none;
  }
  .nav-burger-toggle:hover { background: var(--surface-2); }
  .top-nav {
    display: flex;
    gap: 0.25rem;
    align-items: center;
    flex-wrap: wrap;
  }
  .nav-dd { position: relative; }
  .nav-dd > summary {
    list-style: none;
    cursor: pointer;
    padding: 0.45rem 0.8rem;
    border-radius: 6px;
    color: var(--muted);
    font-size: 0.85rem;
    font-weight: 500;
    white-space: nowrap;
  }
  .nav-dd > summary::-webkit-details-marker { display: none; }
  .nav-dd > summary::after { content: ' ▾'; opacity: 0.6; }
  .nav-dd > summary:hover { background: var(--surface-2); color: var(--text); }
  .nav-dd > summary.active { color: var(--text); }
  .nav-dd[open] > summary { background: var(--surface-2); color: var(--text); }
  .nav-dd-menu {
    position: absolute;
    top: calc(100% + 0.3rem);
    left: 0;
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 0.3rem;
    min-width: 180px;
    max-height: 70vh;
    overflow-y: auto;
    display: flex;
    flex-direction: column;
    gap: 0.1rem;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
    z-index: 30;
  }
  .nav-dd-menu a { white-space: nowrap; }
  .top-nav a {
    padding: 0.45rem 0.8rem;
    color: var(--muted);
    border-radius: 6px;
    font-size: 0.85rem;
    font-weight: 500;
    text-decoration: none;
    white-space: nowrap;
    transition: background 0.12s, color 0.12s;
  }
  .top-nav a:hover { background: var(--surface-2); color: var(--text); text-decoration: none; }
  .top-nav a.active {
    background: var(--surface-2);
    color: var(--text);
  }
  .top-nav a.active::before {
    content: '';
    display: inline-block;
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: var(--primary);
    margin-right: 0.45rem;
    vertical-align: middle;
  }
  .header-meta { display: flex; gap: 0.75rem; align-items: center; font-size: 0.8rem; flex: 0 0 auto; }
  .header-meta .muted { color: var(--muted); }
  .header-meta .tag {
    padding: 0.15rem 0.55rem;
    background: var(--surface-2);
    border: 1px solid var(--border);
    border-radius: 999px;
    font-size: 0.72rem;
    font-weight: 500;
  }
  .header-meta form { margin: 0; }
  .header-meta .btn { padding: 0.35rem 0.7rem; font-size: 0.8rem; }

  .container { max-width: 1280px; margin: 0 auto; padding: 1.5rem 1.25rem; }
  .container.wide { max-width: none; padding: 1rem 1.25rem; }
  .stack { display: flex; flex-direction: column; gap: 1.25rem; }
  .row { display: flex; gap: 1.25rem; flex-wrap: wrap; }
  .grow { flex: 1 1 0; min-width: 0; }
  .muted { color: var(--muted); }

  .page-head {
    display: flex;
    align-items: flex-end;
    justify-content: space-between;
    gap: 1rem;
    margin-bottom: 1.25rem;
    flex-wrap: wrap;
  }
  .page-head h1 {
    margin: 0;
    font-size: 1.5rem;
    font-weight: 700;
    letter-spacing: -0.02em;
  }
  .page-head .lede { margin: 0.3rem 0 0; color: var(--muted); font-size: 0.9rem; }
  .page-head .actions { display: flex; gap: 0.5rem; align-items: center; flex-shrink: 0; }

  .card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 1rem 1.25rem;
  }
  .card h2 { margin: 0 0 0.5rem; font-size: 0.95rem; font-weight: 600; letter-spacing: -0.005em; }
  .card h3 { margin: 0 0 0.5rem; font-size: 0.85rem; font-weight: 600; color: var(--muted); text-transform: uppercase; letter-spacing: 0.05em; }

  .stat { display: grid; grid-template-columns: auto 1fr; gap: 0.5rem 1rem; font-size: 0.85rem; }
  .stat dt { color: var(--muted); }
  .stat dd { margin: 0; font-variant-numeric: tabular-nums; }

  .stat-row { display: flex; gap: 1.25rem; flex-wrap: wrap; }

  .stat-tile {
    flex: 1 1 0;
    min-width: 130px;
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 0.9rem 1.1rem;
    text-decoration: none;
    color: var(--text);
    transition: border-color 0.12s, background 0.12s, transform 0.12s;
  }
  a.stat-tile:hover {
    border-color: var(--primary);
    background: var(--surface-2);
    text-decoration: none;
    transform: translateY(-1px);
  }
  .stat-tile-value { font-size: 1.5rem; font-weight: 700; font-variant-numeric: tabular-nums; letter-spacing: -0.02em; }
  .stat-tile-label { font-size: 0.75rem; color: var(--muted); text-transform: uppercase; letter-spacing: 0.06em; margin-top: 0.25rem; }

  .btn, button.btn {
    display: inline-flex;
    align-items: center;
    gap: 0.4rem;
    padding: 0.5rem 0.9rem;
    background: var(--primary);
    color: var(--primary-on);
    border: 0;
    border-radius: 6px;
    font-weight: 600;
    font-size: 0.85rem;
    cursor: pointer;
    text-decoration: none;
  }
  .btn:hover { opacity: 0.9; }
  .btn.btn-ghost {
    background: transparent;
    color: var(--text);
    border: 1px solid var(--border);
  }
  .btn.btn-ghost:hover { background: var(--surface-2); }

  input, textarea, select {
    width: 100%;
    background: var(--bg);
    color: var(--text);
    border: 1px solid var(--border);
    border-radius: 6px;
    padding: 0.55rem 0.7rem;
    font: inherit;
  }
  input:focus, textarea:focus, select:focus {
    outline: 2px solid var(--primary);
    outline-offset: -1px;
    border-color: var(--primary);
  }
  label { display: block; font-size: 0.8rem; color: var(--muted); margin-bottom: 0.3rem; }
  .field + .field { margin-top: 0.85rem; }

  .table { width: 100%; border-collapse: collapse; font-size: 0.85rem; }
  .table th, .table td { padding: 0.6rem 0.75rem; text-align: left; border-bottom: 1px solid var(--border); }
  .table th { color: var(--muted); font-weight: 500; font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.06em; background: rgba(0,0,0,0.15); }
  .table tr:last-child td { border-bottom: 0; }
  .table tbody tr { transition: background 0.1s; }
  .table tbody tr:hover { background: rgba(167,139,250,0.04); }
  .table .num { text-align: right; font-variant-numeric: tabular-nums; }

  .preview-frame {
    width: 100%;
    aspect-ratio: 16 / 11;
    border: 1px solid var(--border);
    border-radius: var(--radius);
    background: var(--bg);
    overflow: hidden;
  }
  .preview-frame iframe { width: 100%; height: 100%; border: 0; display: block; background: var(--bg); }

  .chat {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
    min-height: 420px;
  }
  .chat-log {
    flex: 1;
    overflow-y: auto;
    background: var(--bg);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 0.75rem;
    font-size: 0.85rem;
    min-height: 200px;
    max-height: 480px;
  }
  .chat-msg { padding: 0.5rem 0; border-bottom: 1px dashed var(--border); }
  .chat-msg:last-child { border-bottom: 0; }
  .chat-role { font-size: 0.7rem; color: var(--muted); text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 0.25rem; }
  .chat-msg.user .chat-role { color: var(--primary); }
  .chat-msg.assistant .chat-role { color: var(--success); }
  .chat-msg.thinking .chat-role { color: var(--muted); }
  .chat-msg.thinking > div:nth-child(2) { font-style: italic; opacity: 0.7; }
  .chat-msg.error {
    background: rgba(248, 113, 113, 0.08);
    border-left: 3px solid var(--danger);
    padding-left: 0.6rem;
    margin: 0.25rem -0.4rem;
    border-radius: 0 4px 4px 0;
  }
  .chat-msg.error .chat-role { color: var(--danger); }
  .chat-msg pre { margin: 0.5rem 0 0; padding: 0.5rem; background: var(--surface-2); border-radius: 4px; font-size: 0.75rem; overflow-x: auto; }
  /* Rendered-markdown assistant messages */
  .chat-md { font-size: 0.85rem; line-height: 1.5; }
  .chat-md > *:first-child { margin-top: 0; }
  .chat-md > *:last-child { margin-bottom: 0; }
  .chat-md p { margin: 0.4rem 0; }
  .chat-md h3, .chat-md h4, .chat-md h5, .chat-md h6 { margin: 0.7rem 0 0.35rem; line-height: 1.25; font-weight: 650; }
  .chat-md h3 { font-size: 1rem; }
  .chat-md h4 { font-size: 0.92rem; }
  .chat-md h5, .chat-md h6 { font-size: 0.85rem; color: var(--muted); }
  .chat-md ul, .chat-md ol { margin: 0.4rem 0; padding-left: 1.25rem; }
  .chat-md li { margin: 0.15rem 0; }
  .chat-md a { color: var(--primary); text-decoration: underline; }
  .chat-md code { background: var(--surface-2); padding: 0.05rem 0.3rem; border-radius: 3px; font-size: 0.8em; }
  .chat-md hr { border: 0; border-top: 1px solid var(--border); margin: 0.7rem 0; }
  .chat-md table { border-collapse: collapse; width: 100%; margin: 0.5rem 0; font-size: 0.8rem; display: block; overflow-x: auto; }
  .chat-md th, .chat-md td { border: 1px solid var(--border); padding: 0.3rem 0.5rem; text-align: left; vertical-align: top; }
  .chat-md th { background: var(--surface-2); font-weight: 600; }
  .chat-form { display: flex; gap: 0.5rem; }
  .chat-form textarea { flex: 1; min-height: 60px; resize: vertical; }
  .chat-form button:disabled { opacity: 0.6; cursor: not-allowed; }
  .chat-form textarea:disabled { opacity: 0.7; }

  .alert { padding: 0.75rem 1rem; border-radius: 6px; margin-bottom: 1rem; font-size: 0.85rem; }
  .alert.error { background: rgba(248, 113, 113, 0.1); border: 1px solid var(--danger); color: var(--danger); }
  .alert.info { background: rgba(167, 139, 250, 0.08); border: 1px solid var(--primary); }

  .empty-state { text-align: center; padding: 2.5rem 1rem; }
  .empty-state-icon { font-size: 2rem; margin-bottom: 0.75rem; opacity: 0.4; }
  .empty-state-text { color: var(--muted); font-size: 0.85rem; }
  .empty-state-action { margin-top: 1rem; }

  .badge {
    display: inline-flex; align-items: center; gap: 0.3rem;
    padding: 0.15rem 0.55rem; border-radius: 999px; font-size: 0.72rem; font-weight: 600;
    background: var(--surface-2); color: var(--muted); border: 1px solid var(--border);
  }
  .badge-primary { background: rgba(167,139,250,0.12); color: var(--primary); border-color: rgba(167,139,250,0.25); }
  .badge-success { background: rgba(52,211,153,0.1); color: var(--success); border-color: rgba(52,211,153,0.25); }
  .badge-danger { background: rgba(248,113,113,0.1); color: var(--danger); border-color: rgba(248,113,113,0.25); }

  .login-shell {
    min-height: 100vh; display: grid; place-items: center; padding: 1rem;
    background: linear-gradient(135deg, var(--bg) 0%, #0f1629 50%, #131a2e 100%);
  }
  .login-card { width: 100%; max-width: 400px; padding: 2rem 2.25rem; }
  .login-card h1 { margin: 0 0 0.25rem; font-size: 1.5rem; letter-spacing: -0.02em; }
  .login-card .lede { margin: 0 0 1.5rem; color: var(--muted); font-size: 0.85rem; }
  .login-brand { text-align: center; margin-bottom: 1.5rem; }
  .login-brand-name { font-size: 1.1rem; font-weight: 700; letter-spacing: -0.01em; }
  .login-brand-name .accent { color: var(--primary); }

  @media (max-width: 768px) {
    .app-header { position: relative; gap: 0.5rem; padding: 0.5rem 0.75rem; }
    .site-context { max-width: 150px; padding: 0.15rem 0.5rem; }
    .nav-burger { flex: 0 0 auto; }
    .nav-burger-toggle { display: inline-flex; align-items: center; }
    .nav-burger > .top-nav { display: none; }
    .nav-burger[open] > .top-nav {
      display: flex;
      flex-direction: column;
      align-items: stretch;
      position: absolute;
      top: 100%;
      left: 0;
      right: 0;
      background: var(--surface);
      border-bottom: 1px solid var(--border);
      box-shadow: 0 10px 28px rgba(0, 0, 0, 0.45);
      padding: 0.5rem 0.75rem;
      gap: 0.1rem;
      z-index: 25;
    }
    .nav-dd, .nav-dd-menu { position: static; }
    .nav-dd-menu { box-shadow: none; border: 0; min-width: 0; padding: 0.1rem 0 0.1rem 0.75rem; max-height: none; }
    .top-nav a { padding: 0.45rem 0.6rem; font-size: 0.85rem; }
    .header-meta { margin-left: auto; }
    .header-meta .btn { padding: 0.3rem 0.55rem; font-size: 0.75rem; }
    .container { padding: 1rem 0.75rem; }
    .container.wide { padding: 0.75rem; }
    .page-head { flex-direction: column; align-items: flex-start; }
    .page-head .actions { width: 100%; }
    .page-head h1 { font-size: 1.25rem; }
    .row { flex-direction: column; }
    .stat-row { gap: 0.75rem; }
    .stat-tile { min-width: calc(50% - 0.5rem); flex: 1 1 calc(50% - 0.5rem); padding: 0.7rem 0.85rem; }
    .stat-tile-value { font-size: 1.25rem; }
    .card { padding: 0.75rem 1rem; }
    .card h2 { font-size: 0.9rem; }
    .table { font-size: 0.8rem; }
    .table th, .table td { padding: 0.45rem 0.5rem; }
    .chat-form { flex-direction: column; }
    .chat-form textarea { min-height: 50px; }
    .chat-form button { width: 100%; justify-content: center; }
    .chat-log { max-height: 320px; }
    .preview-col { display: none; }
    .login-card { padding: 1.5rem; }
  }
`;

const FONT_SIZES: Record<string, string> = {
  xs: '12px',
  small: '13px',
  normal: '14px',
  medium: '15px',
  large: '16px',
  xl: '18px',
};

export const AdminLayout: FC<PropsWithChildren<LayoutProps>> = (props) => {
  const bodyFontSize = FONT_SIZES[props.fontSize ?? 'normal'] ?? '14px';
  return (
    <html lang="en" data-theme="dark">
      <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>{props.title}</title>
        <meta name="robots" content="noindex, nofollow" />
        {raw(pwaMetaTags({ themeColor: '#0b1020', iconLetter: 'W', iconBgColor: '#a78bfa' }))}
        <link
          rel="icon"
          href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3E%3Crect width='16' height='16' fill='%23475569' rx='3'/%3E%3Ctext x='8' y='12' font-family='ui-sans-serif' font-size='10' fill='%23a78bfa' text-anchor='middle' font-weight='700'%3EW%3C/text%3E%3C/svg%3E"
        />
        <link href="/_/styles.css" rel="stylesheet" />
        <StyleTag css={`${DESIGN_TOKENS}\n${STYLES}`} />
      </head>
      <body style={bodyFontSize !== '14px' ? `font-size: ${bodyFontSize};` : undefined}>
        {props.children}
      </body>
    </html>
  );
};

export type NavKey = 'dashboard' | 'chat' | 'pages' | 'users' | 'none' | string;

export interface NavItem {
  key: string;
  label: string;
  href: string;
  ownerOnly?: boolean;
  icon?: string;
}

const NAV: NavItem[] = [
  { key: 'dashboard', label: 'Dashboard', href: '/admin' },
  { key: 'chat', label: 'Chat', href: '/admin/chat' },
  { key: 'pages', label: 'Pages', href: '/admin/pages' },
  { key: 'theme', label: 'Theme', href: '/admin/theme' },
  { key: 'settings', label: 'Settings', href: '/admin/settings' },
  { key: 'users', label: 'Users', href: '/admin/users', ownerOnly: true },
];

export const AdminHeader: FC<{
  siteId?: string;
  siteTitle?: string;
  userEmail?: string;
  userRole?: 'owner' | 'editor' | 'member';
  active?: NavKey;
  extraNav?: NavItem[];
}> = ({ siteId, siteTitle, userEmail, userRole, active, extraNav }) => {
  const items = NAV.filter((n) => !n.ownerOnly || userRole === 'owner');
  const extras = extraNav ?? [];
  const contentActive = extras.some((n) => n.key === active);
  return (
    <header class="app-header">
      {siteId ? (
        <button
          type="button"
          class="site-context"
          data-copy={siteId}
          title={`Copy site id: ${siteId}`}
          onclick="navigator.clipboard&&navigator.clipboard.writeText(this.dataset.copy);var c=this.querySelector('.site-context-copy');if(c){c.style.opacity='1';clearTimeout(window.__scT);window.__scT=setTimeout(function(){c.style.opacity='0'},1200);}"
        >
          <span class="site-context-title">{siteTitle || siteId}</span>
          <span class="site-context-slug">
            {siteId}
            <span class="site-context-copy">✓ copied</span>
          </span>
        </button>
      ) : null}
      <details class="nav-burger">
        <summary class="nav-burger-toggle" aria-label="Menu" title="Menu">
          ☰
        </summary>
        <nav class="top-nav" aria-label="Sections">
          {items.map((n) => (
            <a key={n.key} href={n.href} class={active === n.key ? 'active' : ''}>
              {n.label}
            </a>
          ))}
          {extras.length > 0 ? (
            <details class="nav-dd">
              <summary class={contentActive ? 'active' : ''}>Content</summary>
              <div class="nav-dd-menu">
                {extras.map((n) => (
                  <a key={n.key} href={n.href} class={active === n.key ? 'active' : ''}>
                    {n.icon ? `${n.icon} ` : ''}
                    {n.label}
                  </a>
                ))}
              </div>
            </details>
          ) : null}
          {siteId ? (
            <a
              href={`https://${siteId}.prowebstore.online`}
              target="_blank"
              rel="noopener noreferrer"
              title="Open public site"
            >
              ↗ Public
            </a>
          ) : null}
          {/* The admin is where an owner is when they are stuck — a text box and
              no menu to explore, by DECISIONS §1. Until #26 there was no route
              from here to any documentation at all. Deep-linked to the owner
              guide, not the docs root. */}
          <a
            href="https://docs.prowebstore.online/guide/"
            target="_blank"
            rel="noopener noreferrer"
            title="Guide for site owners"
          >
            ? Help
          </a>
        </nav>
      </details>
      <div class="header-meta">
        {userEmail ? (
          <a
            href="/admin/settings"
            style="display: flex; align-items: center; gap: 0.5rem; text-decoration: none;"
            title="Settings"
          >
            <div style="width: 28px; height: 28px; border-radius: 50%; background: var(--primary); color: var(--primary-on); display: flex; align-items: center; justify-content: center; font-size: 0.7rem; font-weight: 700; flex-shrink: 0;">
              {(userEmail[0] ?? '?').toUpperCase()}
            </div>
          </a>
        ) : null}
      </div>
    </header>
  );
};
