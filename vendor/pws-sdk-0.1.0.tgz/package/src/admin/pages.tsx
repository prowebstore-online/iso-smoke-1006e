/** @jsxRuntime automatic */
/** @jsxImportSource hono/jsx */
// Admin UI page components — rendered server-side via Hono JSX.
// One page per route. The shared <AdminHeader/> handles top navigation +
// active-section highlighting via the `active` prop.

import type { EntityRecord, Page as SitePage } from '@pws/shared';
import type { FC } from 'hono/jsx';
import type { SiteUser } from '../do/rpc.ts';
import { AdminHeader, AdminLayout, type NavItem, type NavKey } from './layout.tsx';

// Re-export entity view from its own module
export { AdminEntityView } from './entity-view.tsx';

// ─── Login ─────────────────────────────────────────────────────────────────

export const LoginPage: FC<{
  error?: string;
  prefillSite?: string;
  prefillEmail?: string;
  googleEnabled?: boolean;
  githubEnabled?: boolean;
  magicLinkEnabled?: boolean;
  magicLinkSent?: boolean;
}> = (props) => {
  const hasSocial = props.googleEnabled || props.githubEnabled;
  return (
    <AdminLayout title="Sign in — ProWebStore admin">
      <div class="login-shell">
        <div class="card login-card">
          <div class="login-brand">
            <div class="login-brand-name">
              prowebstore<span class="accent">.online</span>
            </div>
          </div>
          <h1>Sign in</h1>
          <p class="lede">Enter your site id to manage your website.</p>
          {props.error ? <div class="alert error">{props.error}</div> : null}
          {props.magicLinkSent && (
            <div class="alert info">
              Check your email for a sign-in link. It expires in 15 minutes.
            </div>
          )}
          <form method="post" action="/admin/login">
            <div class="field">
              <label for="site_id">Site id</label>
              <input
                type="text"
                id="site_id"
                name="site_id"
                placeholder="acme-blog"
                required
                autocomplete="off"
                autocapitalize="off"
                spellcheck={false}
                value={props.prefillSite ?? ''}
              />
            </div>
            <div class="field">
              <label for="email">Email</label>
              <input
                type="email"
                id="email"
                name="email"
                placeholder="you@example.com"
                required
                autocomplete="username"
                value={props.prefillEmail ?? ''}
              />
            </div>
            <div class="field">
              <label for="password">Password</label>
              <input
                type="password"
                id="password"
                name="password"
                required
                autocomplete="current-password"
              />
            </div>
            <div class="field">
              <button type="submit" class="btn" style="width: 100%; justify-content: center;">
                Sign in
              </button>
            </div>
          </form>
          {(hasSocial || props.magicLinkEnabled) && (
            <div style="margin-top: 1rem;">
              <div style="display: flex; align-items: center; gap: 0.75rem; margin-bottom: 1rem;">
                <hr style="flex: 1; border: 0; border-top: 1px solid var(--border);" />
                <span
                  class="muted"
                  style="font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.05em;"
                >
                  or
                </span>
                <hr style="flex: 1; border: 0; border-top: 1px solid var(--border);" />
              </div>
              <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                {props.googleEnabled && (
                  <form method="post" action="/admin/auth/google">
                    <input
                      type="hidden"
                      name="site_id"
                      class="js-site-mirror"
                      value={props.prefillSite ?? ''}
                    />
                    <button
                      type="submit"
                      class="btn btn-ghost"
                      style="width: 100%; justify-content: center;"
                    >
                      Sign in with Google
                    </button>
                  </form>
                )}
                {props.githubEnabled && (
                  <form method="post" action="/admin/auth/github">
                    <input
                      type="hidden"
                      name="site_id"
                      class="js-site-mirror"
                      value={props.prefillSite ?? ''}
                    />
                    <button
                      type="submit"
                      class="btn btn-ghost"
                      style="width: 100%; justify-content: center;"
                    >
                      Sign in with GitHub
                    </button>
                  </form>
                )}
                {props.magicLinkEnabled && (
                  <form method="post" action="/admin/auth/magic-link">
                    <input
                      type="hidden"
                      name="site_id"
                      class="js-site-mirror"
                      value={props.prefillSite ?? ''}
                    />
                    <input
                      type="hidden"
                      name="email"
                      class="js-email-mirror"
                      value={props.prefillEmail ?? ''}
                    />
                    <button
                      type="submit"
                      class="btn btn-ghost"
                      style="width: 100%; justify-content: center;"
                    >
                      Email me a sign-in link
                    </button>
                  </form>
                )}
              </div>
              <script
                // biome-ignore lint/security/noDangerouslySetInnerHtml: sync site_id + email fields
                dangerouslySetInnerHTML={{
                  __html: [
                    `var si=document.getElementById('site_id'),em=document.getElementById('email');`,
                    `function sync(){document.querySelectorAll('.js-site-mirror').forEach(function(e){e.value=si.value;});document.querySelectorAll('.js-email-mirror').forEach(function(e){e.value=em.value;});}`,
                    `si.addEventListener('input',sync);em.addEventListener('input',sync);`,
                  ].join(''),
                }}
              />
            </div>
          )}
          <p class="muted" style="font-size: 0.75rem; margin: 1.5rem 0 0; text-align: center;">
            New site?{' '}
            <a href="https://console.prowebstore.online/create">Create one in the console</a> or
            provision via CLI.
          </p>
        </div>
      </div>
    </AdminLayout>
  );
};

// ─── Shared header shape ───────────────────────────────────────────────────

interface PageContext {
  siteId: string;
  siteTitle: string;
  user: SiteUser;
  fontSize?: string;
}

function Shell({
  ctx,
  active,
  title,
  children,
  wide,
  extraNav,
  fontSize,
}: {
  ctx: PageContext;
  active: NavKey;
  title: string;
  children: unknown;
  wide?: boolean;
  extraNav?: NavItem[];
  fontSize?: string;
}) {
  const tabTitle = ctx.siteTitle ? `${title} — ${ctx.siteTitle}` : `${title} — ${ctx.siteId}`;
  return (
    <AdminLayout title={tabTitle} fontSize={fontSize ?? ctx.fontSize}>
      <AdminHeader
        extraNav={extraNav}
        siteId={ctx.siteId}
        siteTitle={ctx.siteTitle}
        userEmail={ctx.user.email}
        userRole={ctx.user.role}
        active={active}
      />
      <div class={wide ? 'container wide' : 'container'}>{children as never}</div>
    </AdminLayout>
  );
}

const tenantHostname = (siteId: string) => `${siteId}.prowebstore.online`;

// ─── Dashboard ─────────────────────────────────────────────────────────────

interface AdminViewInfo {
  id: string;
  entity_slug: string;
  label: string;
  icon: string | null;
  layout: string;
  sort_order: number;
  config: Record<string, unknown>;
}

interface DashboardProps extends PageContext {
  diag: {
    schema_v: number;
    site_v: number;
    entities: number;
    records: number;
    pages: number;
    users: number;
  };
  recentPosts: EntityRecord[];
  adminViews?: AdminViewInfo[];
}

export const DashboardPage: FC<DashboardProps> = (props) => {
  const viewNav: NavItem[] = (props.adminViews ?? []).map((v) => ({
    key: `view:${v.entity_slug}`,
    label: v.label,
    href: `/admin/records/${v.entity_slug}`,
    icon: v.icon ?? undefined,
  }));
  return (
    <Shell ctx={props} active="dashboard" title="Dashboard" extraNav={viewNav}>
      <div class="page-head">
        <div>
          <h1>{props.siteTitle || props.siteId}</h1>
          <p class="lede">
            Signed in as <strong>{props.user.email}</strong> ({props.user.role}). Use chat to make
            changes; the preview reloads as the AI edits.
          </p>
        </div>
        <div class="actions">
          <a class="btn" href="/admin/chat">
            Open chat →
          </a>
          <a
            class="btn btn-ghost"
            href={`https://${tenantHostname(props.siteId)}`}
            target="_blank"
            rel="noopener noreferrer"
          >
            ↗ Public site
          </a>
        </div>
      </div>

      <div class="stat-row" style="margin-bottom: 1.25rem;">
        <StatTile
          label="Records"
          value={props.diag.records}
          href={viewNav.length > 0 ? viewNav[0]!.href : undefined}
          accent="var(--primary)"
        />
        <StatTile
          label="Pages"
          value={props.diag.pages}
          href="/admin/pages"
          accent="var(--success)"
        />
        <StatTile label="Entities" value={props.diag.entities} accent="#60a5fa" />
        <StatTile
          label="Users"
          value={props.diag.users}
          href={props.user.role === 'owner' ? '/admin/users' : undefined}
          accent="#fbbf24"
        />
      </div>

      <div class="row" style="margin-bottom: 0;">
        <div class="grow stack">
          <div class="card">
            <h2>Site</h2>
            <dl class="stat">
              <dt>name</dt>
              <dd>{props.siteTitle || <span class="muted">(no title set)</span>}</dd>
              <dt>slug</dt>
              <dd>
                <code>{props.siteId}</code>
              </dd>
              <dt>public url</dt>
              <dd>
                <a
                  href={`https://${tenantHostname(props.siteId)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  {tenantHostname(props.siteId)}
                </a>
              </dd>
              <dt>your role</dt>
              <dd>{props.user.role}</dd>
            </dl>
            <p class="muted" style="font-size: 0.7rem; margin: 0.85rem 0 0;">
              site_v={props.diag.site_v} · schema_v={props.diag.schema_v}
            </p>
          </div>
        </div>
        <div class="grow stack" style="flex: 2 1 0;">
          <div class="card">
            <h2 style="margin:0 0 0.5rem;">Recent activity</h2>
            {props.recentPosts.length === 0 ? (
              <div class="empty-state">
                <div class="empty-state-icon">&#128203;</div>
                <div class="empty-state-text">No records yet. Use chat to create content.</div>
              </div>
            ) : (
              <ul style="list-style: none; padding: 0; margin: 0;">
                {props.recentPosts.slice(0, 5).map((r) => (
                  <li
                    key={r.id}
                    style="padding: 0.5rem 0.25rem; border-bottom: 1px solid var(--border); font-size: 0.85rem; display: flex; align-items: center; justify-content: space-between; gap: 0.5rem;"
                  >
                    <span style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                      {String(r.data.title ?? r.data.name ?? r.slug ?? r.id).slice(0, 60)}
                    </span>
                    <span class="badge" style="flex-shrink: 0;">
                      {r.entity_slug}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>
    </Shell>
  );
};

const StatTile: FC<{ label: string; value: number; href?: string; accent?: string }> = ({
  label,
  value,
  href,
  accent,
}) => {
  const inner = (
    <>
      <div class="stat-tile-value" style={accent ? `color: ${accent};` : undefined}>
        {value}
      </div>
      <div class="stat-tile-label">{label}</div>
    </>
  );
  return href ? (
    <a class="stat-tile" href={href}>
      {inner}
    </a>
  ) : (
    <div class="stat-tile">{inner}</div>
  );
};

// ─── Chat (copilot view: chat + live preview) ─────────────────────────────

export const ChatPage: FC<PageContext> = (props) => (
  <Shell ctx={props} active="chat" title="Chat" wide>
    <div class="page-head">
      <div>
        <h1>Chat</h1>
        <p class="lede">
          Tell the AI what to change on <strong>{props.siteTitle || props.siteId}</strong>. The
          preview reloads after each response.
        </p>
      </div>
    </div>
    <div class="row" style="align-items: stretch;">
      <div class="grow" style="flex: 1 1 480px; min-width: 0;">
        <ChatCard siteId={props.siteId} />
      </div>
      <div class="grow preview-col" style="flex: 2 1 640px; min-width: 0;">
        <PreviewCard siteId={props.siteId} />
      </div>
    </div>
  </Shell>
);

// Posts page removed — record management is now driven by admin_views
// stored in the DO, rendered dynamically per template.

// ─── Pages list ────────────────────────────────────────────────────────────

export const PagesPage: FC<PageContext & { pages: SitePage[] }> = (props) => (
  <Shell ctx={props} active="pages" title="Pages">
    <div class="page-head">
      <div>
        <h1>Pages</h1>
        <p class="lede">{props.pages.length} total.</p>
      </div>
      <div class="actions">
        <a class="btn" href="/admin/chat">
          + New page via chat
        </a>
      </div>
    </div>
    <div class="card">
      {props.pages.length === 0 ? (
        <div class="empty-state">
          <div class="empty-state-icon">&#128196;</div>
          <div class="empty-state-text">No pages yet.</div>
          <div class="empty-state-action">
            <a class="btn" href="/admin/chat">
              Create your first page via chat
            </a>
          </div>
        </div>
      ) : (
        <table class="table">
          <thead>
            <tr>
              <th>Slug</th>
              <th>Title</th>
              <th>Type</th>
              <th class="num">Blocks</th>
            </tr>
          </thead>
          <tbody>
            {props.pages.map((p) => (
              <tr key={p.id}>
                <td>
                  <a
                    href={`https://${tenantHostname(props.siteId)}${p.slug === '/' ? '' : p.slug}`}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <code>{p.slug}</code>
                  </a>
                </td>
                <td>{p.title}</td>
                <td class="muted">{p.page_type}</td>
                <td class="num">{p.blocks.length}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  </Shell>
);

// ─── Users list ────────────────────────────────────────────────────────────

export const UsersPage: FC<PageContext & { users: SiteUser[] }> = (props) => (
  <Shell ctx={props} active="users" title="Users">
    <div class="page-head">
      <div>
        <h1>Users</h1>
        <p class="lede">{props.users.length} on this site.</p>
      </div>
      <div class="actions">
        <a class="btn" href="/admin/chat">
          + Add user via chat
        </a>
      </div>
    </div>
    <div class="card">
      <table class="table">
        <thead>
          <tr>
            <th>Email</th>
            <th>Role</th>
            <th>Name</th>
            <th>Created</th>
          </tr>
        </thead>
        <tbody>
          {props.users.map((u) => (
            <tr key={u.id}>
              <td>
                <div style="display: flex; align-items: center; gap: 0.5rem;">
                  <div style="width: 24px; height: 24px; border-radius: 50%; background: var(--surface-2); border: 1px solid var(--border); display: flex; align-items: center; justify-content: center; font-size: 0.65rem; font-weight: 700; color: var(--muted); flex-shrink: 0;">
                    {(u.email[0] ?? '?').toUpperCase()}
                  </div>
                  {u.email}
                </div>
              </td>
              <td>
                <span class={u.role === 'owner' ? 'badge badge-primary' : 'badge'}>{u.role}</span>
              </td>
              <td class="muted">{u.display_name ?? '—'}</td>
              <td class="muted" style="font-size: 0.8rem;">
                {u.created_at}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </Shell>
);

// ─── Building blocks reused on /chat ───────────────────────────────────────

const PreviewCard: FC<{ siteId: string }> = ({ siteId }) => {
  const previewUrl = `https://${tenantHostname(siteId)}/?from=admin`;
  return (
    <div class="card" style="height: 100%;">
      <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom: 0.5rem;">
        <h2 style="margin: 0;">Live preview</h2>
        <button type="button" class="btn btn-ghost" id="reload-preview" data-base={previewUrl}>
          Reload
        </button>
      </div>
      <div
        class="preview-frame"
        style="aspect-ratio: auto; height: calc(100vh - 280px); min-height: 480px;"
      >
        <iframe id="preview-iframe" src={previewUrl} title={`${siteId} preview`} loading="lazy" />
      </div>
      <p class="muted" style="font-size: 0.75rem; margin: 0.5rem 0 0;">
        Source: <code>{tenantHostname(siteId)}</code>
      </p>
    </div>
  );
};

const ChatCard: FC<{ siteId: string }> = ({ siteId }) => (
  <div class="card chat" style="height: 100%; min-height: calc(100vh - 220px);">
    <div style="display:flex; align-items:center; justify-content:space-between;">
      <h2 style="margin: 0;">Talk to your site</h2>
      <div style="display:flex; gap: 0.5rem; align-items: center;">
        <button type="button" class="btn btn-ghost" id="chat-clear" title="Clear chat history">
          Clear
        </button>
        <span class="muted" style="font-size: 0.75rem;">
          Powered by the PWS agent
        </span>
      </div>
    </div>
    <p class="muted" style="margin: 0; font-size: 0.8rem;">
      Try: "Add a post titled 'Hello' authored by me, dated today, with a short excerpt."
    </p>
    <div id="chat-log" class="chat-log" data-site-id={siteId}>
      <p class="muted" style="margin: 0;">
        No messages yet.
      </p>
    </div>
    <form id="chat-form" class="chat-form">
      <textarea
        id="chat-input"
        aria-label="Chat message"
        placeholder="Ask the agent to change your site… (Enter to send, Shift+Enter for newline)"
        rows={3}
        required
      />
      <button type="submit" class="btn">
        Send
      </button>
    </form>
    <script
      // biome-ignore lint/security/noDangerouslySetInnerHtml: trusted inline bootstrap
      dangerouslySetInnerHTML={{
        __html: CHAT_SCRIPT.replace('__SITE_ID__', JSON.stringify(siteId)),
      }}
    />
  </div>
);

// ─── Inline chat bootstrap ─────────────────────────────────────────────────

const CHAT_SCRIPT = `
(function () {
  const SITE_ID = __SITE_ID__;
  const form = document.getElementById('chat-form');
  const input = document.getElementById('chat-input');
  const sendBtn = form.querySelector('button[type="submit"]');
  const log = document.getElementById('chat-log');
  const iframe = document.getElementById('preview-iframe');
  const reloadBtn = document.getElementById('reload-preview');
  const STORE_KEY = 'pws-chat:' + SITE_ID;

  // Persist the session id + transcript across page navigations within the
  // same browser tab. sessionStorage is per-tab and survives /admin → /chat → /posts.
  let stored = null;
  try { stored = JSON.parse(sessionStorage.getItem(STORE_KEY) || 'null'); } catch (_) {}
  let sessionId = (stored && stored.sessionId) || ('admin-' + Math.random().toString(36).slice(2, 10));
  let messages = (stored && Array.isArray(stored.messages)) ? stored.messages : [];
  let inFlight = false;

  function persist() {
    try {
      sessionStorage.setItem(STORE_KEY, JSON.stringify({ sessionId: sessionId, messages: messages }));
    } catch (_) {}
  }

  function escape(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }
  // Minimal, dependency-free markdown → safe HTML for assistant messages.
  // Input is HTML-escaped FIRST, then only structural tags are added, so agent
  // output can't inject HTML/script. Links restricted to http(s)/mailto.
  var BT = String.fromCharCode(96);
  function mdInline(s) {
    if (s.indexOf(BT) !== -1) {
      var parts = s.split(BT), rr = '';
      for (var k = 0; k < parts.length; k++) rr += (k % 2 === 1) ? '<code>' + parts[k] + '</code>' : parts[k];
      s = rr;
    }
    s = s.replace(/\\*\\*([^*]+)\\*\\*/g, '<strong>$1</strong>');
    s = s.replace(/\\*([^*]+)\\*/g, '<em>$1</em>');
    s = s.replace(/\\[([^\\]]+)\\]\\(([^)\\s]+)\\)/g, function (_m, t, u) {
      return /^(https?:|mailto:)/i.test(u) ? '<a href="' + u + '" target="_blank" rel="noopener">' + t + '</a>' : t;
    });
    return s;
  }
  function mdCells(line) {
    var raw = line.trim();
    if (raw.charAt(0) === '|') raw = raw.slice(1);
    if (raw.charAt(raw.length - 1) === '|') raw = raw.slice(0, -1);
    var cells = raw.split('|'), r = [];
    for (var k = 0; k < cells.length; k++) r.push(cells[k].trim());
    return r;
  }
  function mdIsSep(line) {
    var t = line.trim();
    return t.indexOf('-') !== -1 && /^[|:\\-\\s]+$/.test(t);
  }
  function renderMarkdown(text) {
    var lines = escape(text).split(/\\r?\\n/);
    var out = [], i = 0, listType = null;
    function closeList() { if (listType) { out.push('</' + listType + '>'); listType = null; } }
    while (i < lines.length) {
      var line = lines[i];
      var trimmed = line.replace(/^\\s+/, '');
      if (line.indexOf('|') !== -1 && i + 1 < lines.length && mdIsSep(lines[i + 1])) {
        closeList();
        var header = mdCells(line); i += 2; var rows = [];
        while (i < lines.length && lines[i].indexOf('|') !== -1 && lines[i].trim() !== '') { rows.push(mdCells(lines[i])); i++; }
        var h = '<table><thead><tr>';
        for (var c = 0; c < header.length; c++) h += '<th>' + mdInline(header[c]) + '</th>';
        h += '</tr></thead><tbody>';
        for (var r2 = 0; r2 < rows.length; r2++) { h += '<tr>'; for (var c2 = 0; c2 < header.length; c2++) h += '<td>' + mdInline(rows[r2][c2] || '') + '</td>'; h += '</tr>'; }
        h += '</tbody></table>';
        out.push(h); continue;
      }
      var hm = trimmed.match(/^(#{1,6})\\s+(.*)$/);
      if (hm) { closeList(); var lvl = Math.min(6, hm[1].length + 2); out.push('<h' + lvl + '>' + mdInline(hm[2]) + '</h' + lvl + '>'); i++; continue; }
      var tt = line.trim();
      if (tt.length >= 3 && (tt.replace(/-/g, '') === '' || tt.replace(/\\*/g, '') === '')) { closeList(); out.push('<hr>'); i++; continue; }
      var um = trimmed.match(/^[-*]\\s+(.*)$/);
      if (um) { if (listType !== 'ul') { closeList(); out.push('<ul>'); listType = 'ul'; } out.push('<li>' + mdInline(um[1]) + '</li>'); i++; continue; }
      var om = trimmed.match(/^\\d+\\.\\s+(.*)$/);
      if (om) { if (listType !== 'ol') { closeList(); out.push('<ol>'); listType = 'ol'; } out.push('<li>' + mdInline(om[1]) + '</li>'); i++; continue; }
      if (line.trim() === '') { closeList(); i++; continue; }
      closeList();
      var para = [line]; i++;
      while (i < lines.length && lines[i].trim() !== '' && lines[i].indexOf('|') === -1) {
        var pt = lines[i].replace(/^\\s+/, '');
        if (/^(#{1,6}\\s|[-*]\\s|\\d+\\.\\s)/.test(pt)) break;
        para.push(lines[i]); i++;
      }
      out.push('<p>' + mdInline(para.join(' ')) + '</p>');
    }
    closeList();
    return out.join('');
  }
  function render() {
    if (messages.length === 0) {
      log.innerHTML = '<p class="muted" style="margin:0;">No messages yet.</p>';
      return;
    }
    log.innerHTML = messages
      .map(function (m) {
        let tools = '';
        if (m.toolCalls && m.toolCalls.length) {
          tools = '<pre>' + m.toolCalls.map(function (t) {
            return (t.ok ? '✓' : '✗') + ' ' + escape(t.name) + ' — ' + escape(t.preview);
          }).join('\\n') + '</pre>';
        }
        var safeRole = escape(m.role).replace(/[^a-z]/g, '');
        var bodyHtml = m.role === 'assistant'
          ? renderMarkdown(m.text)
          : escape(m.text);
        return '<div class="chat-msg ' + safeRole + '">'
          + '<div class="chat-role">' + escape(m.role) + '</div>'
          + '<div class="chat-md">' + bodyHtml + '</div>'
          + tools
          + '</div>';
      })
      .join('');
    log.scrollTop = log.scrollHeight;
  }
  function setBusy(busy) {
    inFlight = busy;
    input.disabled = busy;
    sendBtn.disabled = busy;
    sendBtn.textContent = busy ? 'Thinking…' : 'Send';
  }
  function reloadPreview() {
    if (!iframe) return;
    const base = reloadBtn && reloadBtn.dataset.base ? reloadBtn.dataset.base : iframe.src;
    const sep = base.indexOf('?') === -1 ? '?' : '&';
    iframe.src = base + sep + 'ts=' + Date.now();
  }
  if (reloadBtn) reloadBtn.addEventListener('click', reloadPreview);

  input.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (!inFlight) form.requestSubmit();
    }
  });

  // Restore prior conversation (if any) and put the cursor in the textarea.
  render();
  setTimeout(function () { input.focus(); }, 0);

  async function submit() {
    if (inFlight) return;
    const text = input.value.trim();
    if (!text) return;
    input.value = '';
    messages.push({ role: 'user', text: text });
    messages.push({ role: 'thinking', text: '…' });
    render();
    persist();
    setBusy(true);
    try {
      const res = await fetch('/sites/' + encodeURIComponent(SITE_ID) + '/agent', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ user: text, session_id: sessionId }),
      });
      if (res.status === 401) {
        window.location.href = '/admin/login';
        return;
      }
      const data = await res.json();
      messages.pop();
      if (!res.ok) {
        const msg = (data && (data.error || (data.errors && data.errors.map(function(e){return e.message;}).join('; ')))) || ('HTTP ' + res.status);
        messages.push({ role: 'error', text: msg });
      } else {
        messages.push({
          role: 'assistant',
          text: data.assistantText || '(no response)',
          toolCalls: data.toolCalls || [],
        });
        setTimeout(reloadPreview, 800);
      }
    } catch (err) {
      messages.pop();
      messages.push({ role: 'error', text: err && err.message ? err.message : String(err) });
    } finally {
      setBusy(false);
      render();
      persist();
      input.focus();
    }
  }

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    submit();
  });

  // "Clear" button hook — wire if present.
  const clearBtn = document.getElementById('chat-clear');
  if (clearBtn) {
    clearBtn.addEventListener('click', function () {
      messages = [];
      sessionId = 'admin-' + Math.random().toString(36).slice(2, 10);
      persist();
      render();
      input.focus();
    });
  }
})();
`;

// ─── Settings / Profile ──────────────────────────────────────────────────

export const SettingsPage: FC<
  PageContext & { success?: string; currentTheme?: string; currentFontSize?: string }
> = (props) => (
  <Shell ctx={props} active="settings" title="Settings">
    <div class="max-w-2xl mx-auto">
      <h1 class="text-3xl font-bold mb-1" style="color: var(--text);">
        Settings
      </h1>
      <p class="text-sm mb-6" style="color: var(--muted);">
        Your profile and display preferences for this site.
      </p>

      {props.success && (
        <div
          class="px-4 py-3 mb-4 text-sm"
          style="background: rgba(52,211,153,0.1); border: 1px solid var(--success); color: var(--success); border-radius: var(--radius);"
        >
          Settings saved.
        </div>
      )}

      {/* Profile */}
      <div class="card mb-4">
        <h2 class="text-lg font-semibold mb-3" style="color: var(--text);">
          Profile
        </h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div>
            <div class="mb-1" style="color: var(--muted);">
              Email
            </div>
            <div class="font-medium" style="color: var(--text);">
              {props.user.email}
            </div>
          </div>
          <div>
            <div class="mb-1" style="color: var(--muted);">
              Role
            </div>
            <div class="font-medium" style="color: var(--text);">
              <span
                class="inline-block px-2 py-0.5 text-xs font-semibold"
                style={`border-radius: 999px; ${props.user.role === 'owner' ? 'background: rgba(167,139,250,0.15); color: var(--primary);' : 'background: var(--surface-2); color: var(--muted);'}`}
              >
                {props.user.role}
              </span>
            </div>
          </div>
          <div>
            <div class="mb-1" style="color: var(--muted);">
              Display name
            </div>
            <div class="font-medium" style="color: var(--text);">
              {props.user.display_name ?? <span style="color: var(--muted);">Not set</span>}
            </div>
          </div>
          <div>
            <div class="mb-1" style="color: var(--muted);">
              Site
            </div>
            <div class="font-medium" style="color: var(--text);">
              <code
                class="text-xs px-2 py-0.5"
                style="background: var(--surface-2); border-radius: 4px;"
              >
                {props.siteId}
              </code>
              <span class="text-xs ml-1" style="color: var(--muted);">
                .prowebstore.online
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Display preferences */}
      <div class="card mb-4">
        <h2 class="text-lg font-semibold mb-3" style="color: var(--text);">
          Display
        </h2>
        <form method="post" action="/admin/settings">
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label for="theme" class="block text-sm mb-1" style="color: var(--muted);">
                Theme
              </label>
              <select
                id="theme"
                name="theme"
                class="w-full px-3 py-2 text-sm"
                style="background: var(--bg); color: var(--text); border: 1px solid var(--border); border-radius: 6px;"
              >
                <option value="dark" selected={props.currentTheme === 'dark'}>
                  Dark
                </option>
                <option value="light" selected={props.currentTheme === 'light'}>
                  Light
                </option>
                <option value="system" selected={props.currentTheme === 'system'}>
                  System
                </option>
              </select>
            </div>
            <div>
              <label for="font_size" class="block text-sm mb-1" style="color: var(--muted);">
                Font size
              </label>
              <select
                id="font_size"
                name="font_size"
                class="w-full px-3 py-2 text-sm"
                style="background: var(--bg); color: var(--text); border: 1px solid var(--border); border-radius: 6px;"
              >
                <option value="xs" selected={props.currentFontSize === 'xs'}>
                  Extra small (12px)
                </option>
                <option value="small" selected={props.currentFontSize === 'small'}>
                  Small (13px)
                </option>
                <option value="normal" selected={props.currentFontSize === 'normal'}>
                  Normal (14px)
                </option>
                <option value="medium" selected={props.currentFontSize === 'medium'}>
                  Medium (15px)
                </option>
                <option value="large" selected={props.currentFontSize === 'large'}>
                  Large (16px)
                </option>
                <option value="xl" selected={props.currentFontSize === 'xl'}>
                  Extra large (18px)
                </option>
              </select>
            </div>
          </div>
          <button type="submit" class="btn mt-4 px-6 py-2 text-sm font-medium">
            Save preferences
          </button>
        </form>
      </div>

      {/* Quick links */}
      <div class="card">
        <h2 class="text-lg font-semibold mb-3" style="color: var(--text);">
          Quick links
        </h2>
        <div class="flex flex-col gap-2 text-sm">
          <a
            href={`https://${props.siteId}.prowebstore.online`}
            target="_blank"
            rel="noopener noreferrer"
            class="flex items-center gap-2"
          >
            <span style="color: var(--muted);">↗</span> View public site
          </a>
          <a
            href={`https://${props.siteId}.prowebstore.online/feed.xml`}
            target="_blank"
            rel="noopener noreferrer"
            class="flex items-center gap-2"
          >
            <span style="color: var(--muted);">↗</span> RSS feed
          </a>
          <a
            href={`https://${props.siteId}.prowebstore.online/sitemap.xml`}
            target="_blank"
            rel="noopener noreferrer"
            class="flex items-center gap-2"
          >
            <span style="color: var(--muted);">↗</span> Sitemap
          </a>
          <a href="https://console.prowebstore.online" class="flex items-center gap-2">
            <span style="color: var(--muted);">→</span> Console (manage team, create sites)
          </a>
        </div>
      </div>
    </div>
  </Shell>
);

// ─── Theme Editor ────────────────────────────────────────────────────────

const FONT_OPTIONS = [
  'Inter, system-ui, sans-serif',
  'Manrope, system-ui, sans-serif',
  'Fraunces, Georgia, serif',
  'Playfair Display, Georgia, serif',
  'Lora, Georgia, serif',
  'Merriweather, Georgia, serif',
  'DM Sans, system-ui, sans-serif',
  'Space Grotesk, system-ui, sans-serif',
  'Outfit, system-ui, sans-serif',
  'Libre Baskerville, Georgia, serif',
];

export const ThemeEditorPage: FC<
  PageContext & {
    theme: import('@pws/shared').Theme;
    success?: string | null;
    error?: string | null;
  }
> = (props) => (
  <Shell ctx={props} active="theme" title="Theme">
    <div class="max-w-2xl mx-auto">
      <h1 class="text-3xl font-bold mb-1" style="color: var(--text);">
        Theme
      </h1>
      <p class="text-sm mb-6" style="color: var(--muted);">
        Customize colors, fonts, and spacing. Changes apply to your public site immediately.
      </p>

      {props.success && (
        <div
          class="px-4 py-3 mb-4 text-sm"
          style="background: rgba(52,211,153,0.1); border: 1px solid var(--success); color: var(--success); border-radius: var(--radius);"
        >
          Theme saved. View your site to see the changes.
        </div>
      )}
      {props.error && (
        <div
          class="px-4 py-3 mb-4 text-sm"
          style="background: rgba(239,68,68,0.1); border: 1px solid #ef4444; color: #ef4444; border-radius: var(--radius);"
        >
          {props.error}
        </div>
      )}

      <form method="post" action="/admin/theme">
        <div class="card mb-4">
          <h2 class="text-lg font-semibold mb-3" style="color: var(--text);">
            Colors
          </h2>
          <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
            <div>
              <label for="primary" class="block text-sm mb-1" style="color: var(--muted);">
                Primary
              </label>
              <div class="flex items-center gap-2">
                <input
                  type="color"
                  id="primary"
                  name="primary"
                  value={props.theme.colors?.primary ?? '#1e3a5f'}
                  style="width: 40px; height: 32px; padding: 0; border: 1px solid var(--border); border-radius: 4px; cursor: pointer;"
                />
                <input
                  type="text"
                  value={props.theme.colors?.primary ?? '#1e3a5f'}
                  style="flex:1; background: var(--bg); color: var(--text); border: 1px solid var(--border); border-radius: 6px; padding: 0.4rem 0.6rem; font-family: var(--font-mono); font-size: 0.8rem;"
                  readonly
                />
              </div>
            </div>
            <div>
              <label for="accent" class="block text-sm mb-1" style="color: var(--muted);">
                Accent
              </label>
              <div class="flex items-center gap-2">
                <input
                  type="color"
                  id="accent"
                  name="accent"
                  value={props.theme.colors?.accent ?? '#c49b3c'}
                  style="width: 40px; height: 32px; padding: 0; border: 1px solid var(--border); border-radius: 4px; cursor: pointer;"
                />
                <input
                  type="text"
                  value={props.theme.colors?.accent ?? ''}
                  style="flex:1; background: var(--bg); color: var(--text); border: 1px solid var(--border); border-radius: 6px; padding: 0.4rem 0.6rem; font-family: var(--font-mono); font-size: 0.8rem;"
                  readonly
                />
              </div>
            </div>
            <div>
              <label for="background" class="block text-sm mb-1" style="color: var(--muted);">
                Background
              </label>
              <div class="flex items-center gap-2">
                <input
                  type="color"
                  id="background"
                  name="background"
                  value={props.theme.colors?.background ?? '#ffffff'}
                  style="width: 40px; height: 32px; padding: 0; border: 1px solid var(--border); border-radius: 4px; cursor: pointer;"
                />
                <input
                  type="text"
                  value={props.theme.colors?.background ?? '#ffffff'}
                  style="flex:1; background: var(--bg); color: var(--text); border: 1px solid var(--border); border-radius: 6px; padding: 0.4rem 0.6rem; font-family: var(--font-mono); font-size: 0.8rem;"
                  readonly
                />
              </div>
            </div>
            <div>
              <label for="text" class="block text-sm mb-1" style="color: var(--muted);">
                Text
              </label>
              <div class="flex items-center gap-2">
                <input
                  type="color"
                  id="text"
                  name="text"
                  value={props.theme.colors?.text ?? '#2d3748'}
                  style="width: 40px; height: 32px; padding: 0; border: 1px solid var(--border); border-radius: 4px; cursor: pointer;"
                />
                <input
                  type="text"
                  value={props.theme.colors?.text ?? '#2d3748'}
                  style="flex:1; background: var(--bg); color: var(--text); border: 1px solid var(--border); border-radius: 6px; padding: 0.4rem 0.6rem; font-family: var(--font-mono); font-size: 0.8rem;"
                  readonly
                />
              </div>
            </div>
            <div>
              <label for="heading" class="block text-sm mb-1" style="color: var(--muted);">
                Heading
              </label>
              <div class="flex items-center gap-2">
                <input
                  type="color"
                  id="heading"
                  name="heading"
                  value={props.theme.colors?.heading ?? ''}
                  style="width: 40px; height: 32px; padding: 0; border: 1px solid var(--border); border-radius: 4px; cursor: pointer;"
                />
                <input
                  type="text"
                  value={props.theme.colors?.heading ?? ''}
                  style="flex:1; background: var(--bg); color: var(--text); border: 1px solid var(--border); border-radius: 6px; padding: 0.4rem 0.6rem; font-family: var(--font-mono); font-size: 0.8rem;"
                  readonly
                />
              </div>
            </div>
            <div>
              <label for="surface" class="block text-sm mb-1" style="color: var(--muted);">
                Surface
              </label>
              <div class="flex items-center gap-2">
                <input
                  type="color"
                  id="surface"
                  name="surface"
                  value={props.theme.colors?.surface ?? '#f8fafc'}
                  style="width: 40px; height: 32px; padding: 0; border: 1px solid var(--border); border-radius: 4px; cursor: pointer;"
                />
                <input
                  type="text"
                  value={props.theme.colors?.surface ?? ''}
                  style="flex:1; background: var(--bg); color: var(--text); border: 1px solid var(--border); border-radius: 6px; padding: 0.4rem 0.6rem; font-family: var(--font-mono); font-size: 0.8rem;"
                  readonly
                />
              </div>
            </div>
          </div>
        </div>

        <div class="card mb-4">
          <h2 class="text-lg font-semibold mb-3" style="color: var(--text);">
            Typography
          </h2>
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label for="font_heading" class="block text-sm mb-1" style="color: var(--muted);">
                Heading font
              </label>
              <select
                id="font_heading"
                name="font_heading"
                class="w-full px-3 py-2 text-sm"
                style="background: var(--bg); color: var(--text); border: 1px solid var(--border); border-radius: 6px;"
              >
                {FONT_OPTIONS.map((f) => (
                  <option key={f} value={f} selected={props.theme.fonts?.heading === f}>
                    {f.split(',')[0]}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label for="font_body" class="block text-sm mb-1" style="color: var(--muted);">
                Body font
              </label>
              <select
                id="font_body"
                name="font_body"
                class="w-full px-3 py-2 text-sm"
                style="background: var(--bg); color: var(--text); border: 1px solid var(--border); border-radius: 6px;"
              >
                {FONT_OPTIONS.map((f) => (
                  <option key={f} value={f} selected={props.theme.fonts?.body === f}>
                    {f.split(',')[0]}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div class="card mb-4">
          <h2 class="text-lg font-semibold mb-3" style="color: var(--text);">
            Shape & Spacing
          </h2>
          <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label for="radius" class="block text-sm mb-1" style="color: var(--muted);">
                Border radius
              </label>
              <select
                id="radius"
                name="radius"
                class="w-full px-3 py-2 text-sm"
                style="background: var(--bg); color: var(--text); border: 1px solid var(--border); border-radius: 6px;"
              >
                {(['none', 'sm', 'md', 'lg', 'full'] as const).map((v) => (
                  <option key={v} value={v} selected={props.theme.radius === v}>
                    {v}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label for="shadow" class="block text-sm mb-1" style="color: var(--muted);">
                Shadow
              </label>
              <select
                id="shadow"
                name="shadow"
                class="w-full px-3 py-2 text-sm"
                style="background: var(--bg); color: var(--text); border: 1px solid var(--border); border-radius: 6px;"
              >
                {(['none', 'sm', 'md', 'lg'] as const).map((v) => (
                  <option key={v} value={v} selected={props.theme.shadow === v}>
                    {v}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label for="spacing" class="block text-sm mb-1" style="color: var(--muted);">
                Spacing
              </label>
              <select
                id="spacing"
                name="spacing"
                class="w-full px-3 py-2 text-sm"
                style="background: var(--bg); color: var(--text); border: 1px solid var(--border); border-radius: 6px;"
              >
                {(['compact', 'normal', 'relaxed'] as const).map((v) => (
                  <option key={v} value={v} selected={props.theme.spacing === v}>
                    {v}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <button type="submit" class="btn px-6 py-2 text-sm font-medium">
          Save theme
        </button>
      </form>
    </div>
  </Shell>
);
