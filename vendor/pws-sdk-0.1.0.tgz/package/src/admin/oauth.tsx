/** @jsxRuntime automatic */
/** @jsxImportSource hono/jsx */
// Admin OAuth routes: Google, GitHub, Magic Link.
// Extracted from routes.tsx to keep the main file focused on page routes.

import type { Hono } from 'hono';
import { sha256Hex, signTimedToken, verifyTimedToken } from '../crypto.ts';
import { magicLinkEmail, sendEmail } from '../email.ts';
import type { Env } from '../env.ts';
import { siteStub } from '../env.ts';
import { isValidSiteSlug } from '../route-mode.ts';
import { buildSessionCookie } from './cookies.ts';
import { LoginPage } from './pages.tsx';

// biome-ignore lint/suspicious/noExplicitAny: parent app supplies wider Variables
type AppEnv = { Bindings: Env; Variables: any };

const OAUTH_STATE_TTL_MS = 10 * 60 * 1000;
const MAGIC_LINK_TTL_MS = 15 * 60 * 1000;

// Security headers are applied by the admin middleware in routes.tsx.
// OAuth redirect responses only need Location + Set-Cookie.

export function mountOAuthRoutes(admin: Hono<AppEnv>) {
  // ─── Google OAuth ─────────────────────────────────────────────────────

  admin.post('/auth/google', async (c) => {
    if (!c.env.GOOGLE_CLIENT_ID || !c.env.GOOGLE_CLIENT_SECRET) {
      return c.html(<LoginPage error="Google sign-in is not configured on this instance." />, 503);
    }
    const form = await c.req.parseBody();
    const siteId = String(form.site_id ?? '')
      .trim()
      .toLowerCase();
    if (!siteId || !isValidSiteSlug(siteId)) {
      return c.html(<LoginPage error="Please enter a valid site id first." />, 400);
    }

    const state = await signTimedToken({ siteId }, c.env.GOOGLE_CLIENT_SECRET);
    const callbackUrl = `${new URL(c.req.url).origin}/admin/auth/google/callback`;
    const params = new URLSearchParams({
      client_id: c.env.GOOGLE_CLIENT_ID,
      redirect_uri: callbackUrl,
      response_type: 'code',
      scope: 'openid email',
      state,
      prompt: 'select_account',
    });
    return c.redirect(`https://accounts.google.com/o/oauth2/v2/auth?${params}`, 302);
  });

  admin.get('/auth/google/callback', async (c) => {
    if (!c.env.GOOGLE_CLIENT_ID || !c.env.GOOGLE_CLIENT_SECRET) {
      return c.html(<LoginPage error="Google sign-in is not configured." />, 503);
    }
    const code = c.req.query('code');
    const state = c.req.query('state');
    const error = c.req.query('error');
    if (error) {
      return c.html(<LoginPage error={`Google sign-in was cancelled or failed: ${error}`} />, 400);
    }
    if (!code || !state) {
      return c.html(<LoginPage error="Invalid OAuth callback (missing code or state)." />, 400);
    }

    const parsed = await verifyTimedToken<{ siteId: string }>(
      state,
      c.env.GOOGLE_CLIENT_SECRET,
      OAUTH_STATE_TTL_MS,
    );
    if (!parsed?.siteId) {
      return c.html(<LoginPage error="Invalid or expired OAuth state. Please try again." />, 400);
    }
    const siteId = parsed.siteId;

    const callbackUrl = `${new URL(c.req.url).origin}/admin/auth/google/callback`;
    const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code,
        client_id: c.env.GOOGLE_CLIENT_ID,
        client_secret: c.env.GOOGLE_CLIENT_SECRET,
        redirect_uri: callbackUrl,
        grant_type: 'authorization_code',
      }),
    });
    if (!tokenRes.ok) {
      return c.html(
        <LoginPage error="Failed to exchange Google auth code." prefillSite={siteId} />,
        502,
      );
    }
    const tokens = (await tokenRes.json()) as { id_token?: string };
    if (!tokens.id_token) {
      return c.html(
        <LoginPage error="Google did not return an identity token." prefillSite={siteId} />,
        502,
      );
    }

    // id_token payload is base64url — normalize before atob() (which rejects -/_).
    const jwtBody = tokens.id_token.split('.')[1]!.replace(/-/g, '+').replace(/_/g, '/');
    const payload = JSON.parse(atob(jwtBody)) as {
      email?: string;
      email_verified?: boolean;
    };
    if (!payload.email || !payload.email_verified) {
      return c.html(
        <LoginPage error="Google account email is not verified." prefillSite={siteId} />,
        400,
      );
    }

    const result = await siteStub(c.env, siteId).authenticateByEmail(payload.email);
    if (!result) {
      return c.html(
        <LoginPage
          error={`No user with email ${payload.email} on site "${siteId}". Ask the site owner to add you.`}
          prefillSite={siteId}
          prefillEmail={payload.email}
        />,
        401,
      );
    }

    const cookie = buildSessionCookie(siteId, result.token, result.expires_at);
    return new Response(null, {
      status: 302,
      headers: { Location: '/admin', 'Set-Cookie': cookie },
    });
  });

  // ─── GitHub OAuth ────────────────────────────────────────────────────

  admin.post('/auth/github', async (c) => {
    if (!c.env.GITHUB_CLIENT_ID || !c.env.GITHUB_CLIENT_SECRET) {
      return c.html(<LoginPage error="GitHub sign-in is not configured on this instance." />, 503);
    }
    const form = await c.req.parseBody();
    const siteId = String(form.site_id ?? '')
      .trim()
      .toLowerCase();
    if (!siteId || !isValidSiteSlug(siteId)) {
      return c.html(<LoginPage error="Please enter a valid site id first." />, 400);
    }

    const state = await signTimedToken({ siteId }, c.env.GITHUB_CLIENT_SECRET);
    const callbackUrl = `${new URL(c.req.url).origin}/admin/auth/github/callback`;
    const params = new URLSearchParams({
      client_id: c.env.GITHUB_CLIENT_ID,
      redirect_uri: callbackUrl,
      scope: 'user:email',
      state,
    });
    return c.redirect(`https://github.com/login/oauth/authorize?${params}`, 302);
  });

  admin.get('/auth/github/callback', async (c) => {
    if (!c.env.GITHUB_CLIENT_ID || !c.env.GITHUB_CLIENT_SECRET) {
      return c.html(<LoginPage error="GitHub sign-in is not configured." />, 503);
    }
    const code = c.req.query('code');
    const state = c.req.query('state');
    const error = c.req.query('error');
    if (error) {
      return c.html(<LoginPage error={`GitHub sign-in was cancelled or failed: ${error}`} />, 400);
    }
    if (!code || !state) {
      return c.html(<LoginPage error="Invalid OAuth callback (missing code or state)." />, 400);
    }

    const parsed = await verifyTimedToken<{ siteId: string }>(
      state,
      c.env.GITHUB_CLIENT_SECRET,
      OAUTH_STATE_TTL_MS,
    );
    if (!parsed?.siteId) {
      return c.html(<LoginPage error="Invalid or expired OAuth state. Please try again." />, 400);
    }
    const siteId = parsed.siteId;

    const tokenRes = await fetch('https://github.com/login/oauth/access_token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({
        client_id: c.env.GITHUB_CLIENT_ID,
        client_secret: c.env.GITHUB_CLIENT_SECRET,
        code,
      }),
    });
    if (!tokenRes.ok) {
      return c.html(
        <LoginPage error="Failed to exchange GitHub auth code." prefillSite={siteId} />,
        502,
      );
    }
    const tokenData = (await tokenRes.json()) as { access_token?: string; error?: string };
    if (!tokenData.access_token) {
      return c.html(
        <LoginPage
          error={`GitHub token exchange failed: ${tokenData.error ?? 'unknown'}`}
          prefillSite={siteId}
        />,
        502,
      );
    }

    const emailRes = await fetch('https://api.github.com/user/emails', {
      headers: {
        Authorization: `Bearer ${tokenData.access_token}`,
        Accept: 'application/vnd.github+json',
        'User-Agent': 'prowebstore-admin',
      },
    });
    if (!emailRes.ok) {
      return c.html(<LoginPage error="Failed to fetch GitHub email." prefillSite={siteId} />, 502);
    }
    const emails = (await emailRes.json()) as Array<{
      email: string;
      primary: boolean;
      verified: boolean;
    }>;
    const primary = emails.find((e) => e.primary && e.verified);
    if (!primary) {
      return c.html(
        <LoginPage
          error="No verified primary email on your GitHub account."
          prefillSite={siteId}
        />,
        400,
      );
    }

    const result = await siteStub(c.env, siteId).authenticateByEmail(primary.email);
    if (!result) {
      return c.html(
        <LoginPage
          error={`No user with email ${primary.email} on site "${siteId}". Ask the site owner to add you.`}
          prefillSite={siteId}
          prefillEmail={primary.email}
        />,
        401,
      );
    }

    const cookie = buildSessionCookie(siteId, result.token, result.expires_at);
    return new Response(null, {
      status: 302,
      headers: { Location: '/admin', 'Set-Cookie': cookie },
    });
  });

  // ─── Magic Link ──────────────────────────────────────────────────────

  admin.post('/auth/magic-link', async (c) => {
    if (!c.env.MAGIC_LINK_SECRET) {
      return c.html(<LoginPage error="Magic link sign-in is not configured." />, 503);
    }
    const form = await c.req.parseBody();
    const siteId = String(form.site_id ?? '')
      .trim()
      .toLowerCase();
    const email = String(form.email ?? '')
      .trim()
      .toLowerCase();
    if (!siteId || !isValidSiteSlug(siteId) || !email) {
      return c.html(<LoginPage error="Site id and email are required." />, 400);
    }

    if (c.env.AUTH_RATE_LIMIT) {
      const ip = c.req.header('cf-connecting-ip') ?? c.req.header('x-forwarded-for') ?? 'unknown';
      const key = `magic:${siteId}:${ip}`;
      const { success } = await c.env.AUTH_RATE_LIMIT.limit({ key });
      if (!success) {
        return c.html(
          <LoginPage
            error="Too many requests. Try again in 60 seconds."
            prefillSite={siteId}
            prefillEmail={email}
          />,
          429,
        );
      }
    }

    const user = await siteStub(c.env, siteId).getUserByEmail(email);
    if (user && c.env.RESEND_API_KEY) {
      const token = await signTimedToken({ siteId, email }, c.env.MAGIC_LINK_SECRET);
      const origin = new URL(c.req.url).origin;
      const verifyUrl = `${origin}/admin/auth/magic-link/verify?token=${encodeURIComponent(token)}`;
      await sendEmail(
        {
          apiKey: c.env.RESEND_API_KEY,
          from: c.env.EMAIL_FROM ?? 'ProWebStore <noreply@prowebstore.online>',
        },
        { ...magicLinkEmail(siteId, verifyUrl), to: email },
      ).catch((e) => console.warn('[magic-link] email failed', e instanceof Error ? e.message : e));
    }

    return c.html(
      <LoginPage error={undefined} prefillSite={siteId} prefillEmail={email} magicLinkSent />,
    );
  });

  admin.get('/auth/magic-link/verify', async (c) => {
    if (!c.env.MAGIC_LINK_SECRET) {
      return c.html(<LoginPage error="Magic link sign-in is not configured." />, 503);
    }
    const token = c.req.query('token');
    if (!token) {
      return c.html(<LoginPage error="Invalid magic link (missing token)." />, 400);
    }

    const parsed = await verifyTimedToken<{ siteId: string; email: string }>(
      token,
      c.env.MAGIC_LINK_SECRET,
      MAGIC_LINK_TTL_MS,
    );
    if (!parsed?.siteId || !parsed?.email) {
      return c.html(
        <LoginPage error="Invalid or expired magic link. Please request a new one." />,
        400,
      );
    }

    // Enforce single use: the token is a stateless HMAC, so without this a leaked
    // link (email forwarding, browser history, Referer) could mint a fresh admin
    // session on every hit within the TTL. consumeOnce returns false on replay.
    const tokenHash = await sha256Hex(token);
    const fresh = await siteStub(c.env, parsed.siteId).consumeOnce(
      `magic:${tokenHash}`,
      Date.now() + MAGIC_LINK_TTL_MS,
    );
    if (!fresh) {
      return c.html(
        <LoginPage error="This magic link was already used. Please request a new one." />,
        400,
      );
    }

    const result = await siteStub(c.env, parsed.siteId).authenticateByEmail(parsed.email);
    if (!result) {
      return c.html(
        <LoginPage
          error={`No user with email ${parsed.email} on site "${parsed.siteId}".`}
          prefillSite={parsed.siteId}
          prefillEmail={parsed.email}
        />,
        401,
      );
    }

    const cookie = buildSessionCookie(parsed.siteId, result.token, result.expires_at);
    return new Response(null, {
      status: 302,
      headers: { Location: '/admin', 'Set-Cookie': cookie },
    });
  });
}
