// Cookie helpers for the admin UI.
// Session cookie value is `{siteId}:{token}` — the siteId scopes the cookie to
// a specific tenant, so a stolen cookie can't be replayed against a different
// site (server checks siteId-match before honouring the token).

export const SESSION_COOKIE = 'pws_session';

export interface ParsedSession {
  siteId: string;
  token: string;
}

export function parseSessionCookie(header: string | null | undefined): ParsedSession | null {
  if (!header) return null;
  // Find our cookie. RFC 6265 allows cookies separated by `; `.
  for (const part of header.split(/;\s*/)) {
    const eq = part.indexOf('=');
    if (eq === -1) continue;
    const name = part.slice(0, eq).trim();
    if (name !== SESSION_COOKIE) continue;
    let value: string;
    try {
      value = decodeURIComponent(part.slice(eq + 1).trim());
    } catch {
      return null; // Malformed percent-encoding
    }
    const colon = value.indexOf(':');
    if (colon === -1) return null;
    const siteId = value.slice(0, colon);
    const token = value.slice(colon + 1);
    if (!siteId || token.length !== 64) return null;
    return { siteId, token };
  }
  return null;
}

/**
 * Build a Set-Cookie header for the admin session.
 * - httpOnly:  JS on the page can't read the token
 * - secure:    cookie only sent over HTTPS (false outside production for local dev)
 * - sameSite=Lax: blocks CSRF on cross-site POSTs while still working for normal nav
 * - path=/:    available to both /admin/* and /sites/* on the same host
 */
export function buildSessionCookie(
  siteId: string,
  token: string,
  expiresAt: number,
  opts: { secure?: boolean } = {},
): string {
  const value = encodeURIComponent(`${siteId}:${token}`);
  const maxAge = Math.max(0, Math.floor((expiresAt - Date.now()) / 1000));
  const parts = [
    `${SESSION_COOKIE}=${value}`,
    'Path=/',
    `Max-Age=${maxAge}`,
    'HttpOnly',
    'SameSite=Lax',
  ];
  if (opts.secure !== false) parts.push('Secure');
  return parts.join('; ');
}

/** Empty cookie with Max-Age=0 to clear it. */
export function clearSessionCookie(opts: { secure?: boolean } = {}): string {
  const parts = [`${SESSION_COOKIE}=`, 'Path=/', 'Max-Age=0', 'HttpOnly', 'SameSite=Lax'];
  if (opts.secure !== false) parts.push('Secure');
  return parts.join('; ');
}
