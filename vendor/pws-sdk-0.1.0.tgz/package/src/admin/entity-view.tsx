/** @jsxRuntime automatic */
/** @jsxImportSource hono/jsx */
// Dynamic entity view renderer — table, pipeline, cards layouts.
// Driven by admin_views config stored in the SiteDO.

import type { EntityRecord, EntitySchema } from '@pws/shared';
import type { FC } from 'hono/jsx';
import type { SiteUser } from '../do/rpc.ts';
import { AdminHeader, AdminLayout, type NavItem } from './layout.tsx';

export interface AdminViewConfig {
  id: string;
  entity_slug: string;
  label: string;
  icon: string | null;
  layout: string;
  sort_order: number;
  config: Record<string, unknown>;
}

export const AdminEntityView: FC<{
  siteId: string;
  siteTitle: string;
  user: SiteUser;
  schema: EntitySchema;
  records: EntityRecord[];
  view: AdminViewConfig;
  allViews: AdminViewConfig[];
}> = (props) => {
  const viewNav: NavItem[] = props.allViews.map((v) => ({
    key: `view:${v.entity_slug}`,
    label: v.label,
    href: `/admin/records/${v.entity_slug}`,
    icon: v.icon ?? undefined,
  }));

  const activeKey = `view:${props.view.entity_slug}`;

  return (
    <AdminLayout title={`${props.view.label} — ${props.siteTitle}`}>
      <AdminHeader
        siteId={props.siteId}
        siteTitle={props.siteTitle}
        userEmail={props.user.email}
        userRole={props.user.role}
        active={activeKey}
        extraNav={viewNav}
      />
      <div class="container" style="padding-top: 1.5rem;">
        <div style="display: flex; align-items: flex-end; justify-content: space-between; margin-bottom: 1.25rem;">
          <div>
            <h1 style="margin: 0; font-size: 1.5rem;">
              {props.view.icon && <span style="margin-right: 0.5rem;">{props.view.icon}</span>}
              {props.view.label}
            </h1>
            <p class="muted" style="margin: 0.25rem 0 0; font-size: 0.85rem;">
              {props.records.length} record{props.records.length === 1 ? '' : 's'}
            </p>
          </div>
        </div>

        {renderViewLayout(props.view, props.schema, props.records)}
      </div>
    </AdminLayout>
  );
};

function renderViewLayout(view: AdminViewConfig, schema: EntitySchema, records: EntityRecord[]) {
  switch (view.layout) {
    case 'pipeline':
      return renderPipelineView(view, schema, records);
    case 'cards':
      return renderCardsView(view, schema, records);
    default:
      return renderTableView(view, schema, records);
  }
}

function renderTableView(view: AdminViewConfig, schema: EntitySchema, records: EntityRecord[]) {
  const columns = (view.config.columns as string[]) ?? schema.fields.slice(0, 5).map((f) => f.slug);
  const fieldsBySlug = new Map(schema.fields.map((f) => [f.slug, f]));

  if (records.length === 0) {
    return (
      <div class="card">
        <div class="empty-state">
          <div class="empty-state-icon">&#128451;</div>
          <div class="empty-state-text">No {view.label.toLowerCase()} yet.</div>
        </div>
      </div>
    );
  }

  return (
    <div class="card" style="overflow: hidden; padding: 0;">
      <div style="overflow-x: auto;">
        <table class="table">
          <thead>
            <tr>
              {columns.map((slug) => (
                <th key={slug}>{fieldsBySlug.get(slug)?.name ?? slug}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {records.map((r) => (
              <tr key={r.id}>
                {columns.map((slug, i) => (
                  <td key={slug} style={i === 0 ? 'font-weight: 500;' : undefined}>
                    {formatVal(r.data[slug])}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function renderPipelineView(view: AdminViewConfig, _schema: EntitySchema, records: EntityRecord[]) {
  const stages = (view.config.stages as string[]) ?? ['Active', 'Pending', 'Done'];
  const stageField = (view.config.stage_field as string) ?? 'status';
  const cardFields = (view.config.card_fields as string[]) ?? ['title'];

  const byStage = new Map<string, EntityRecord[]>();
  for (const stage of stages) byStage.set(stage, []);
  for (const r of records) {
    const val = String(r.data[stageField] ?? '');
    const bucket = byStage.get(val) ?? byStage.get(stages[0]!)!;
    bucket.push(r);
  }

  return (
    <div style="display: flex; gap: 0.75rem; overflow-x: auto; padding-bottom: 1rem;">
      {stages.map((stage) => {
        const items = byStage.get(stage) ?? [];
        return (
          <div key={stage} style="flex: 1; min-width: 240px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.75rem; padding: 0.5rem 0.75rem; background: var(--surface); border: 1px solid var(--border); border-radius: 8px;">
              <span style="font-weight: 600; font-size: 0.85rem;">{stage}</span>
              <span class="badge">{items.length}</span>
            </div>
            <div style="display: flex; flex-direction: column; gap: 0.5rem; min-height: 60px;">
              {items.map((r) => (
                <div
                  key={r.id}
                  class="card"
                  style="padding: 0.75rem; font-size: 0.85rem; transition: border-color 0.12s; cursor: default;"
                >
                  {cardFields.map((f, i) => (
                    <div
                      key={f}
                      style={
                        i === 0
                          ? 'font-weight: 600;'
                          : 'color: var(--muted); font-size: 0.8rem; margin-top: 0.25rem;'
                      }
                    >
                      {formatVal(r.data[f])}
                    </div>
                  ))}
                </div>
              ))}
              {items.length === 0 && (
                <div style="text-align: center; padding: 1.5rem 0.5rem; border: 1px dashed var(--border); border-radius: 8px;">
                  <span class="muted" style="font-size: 0.8rem;">
                    Empty
                  </span>
                </div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function renderCardsView(view: AdminViewConfig, _schema: EntitySchema, records: EntityRecord[]) {
  const titleField = (view.config.title_field as string) ?? 'name';
  const subtitleField = (view.config.subtitle_field as string) ?? '';
  const imageField = (view.config.image_field as string) ?? '';

  if (records.length === 0) {
    return (
      <div class="card">
        <div class="empty-state">
          <div class="empty-state-icon">&#127793;</div>
          <div class="empty-state-text">No {view.label.toLowerCase()} yet.</div>
        </div>
      </div>
    );
  }

  return (
    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(15rem, 1fr)); gap: 0.75rem;">
      {records.map((r) => {
        const img = imageField && r.data[imageField];
        const hasAsset =
          img &&
          typeof img === 'object' &&
          'asset_id' in (img as unknown as Record<string, unknown>);
        return (
          <div
            key={r.id}
            class="card"
            style="padding: 0; transition: border-color 0.12s, transform 0.12s; cursor: default;"
          >
            {hasAsset ? (
              <img
                src={`/_/img/${(img as { asset_id: string }).asset_id}`}
                alt=""
                style="width: 100%; height: 140px; object-fit: cover; border-radius: var(--radius) var(--radius) 0 0;"
                loading="lazy"
              />
            ) : imageField ? (
              <div style="width: 100%; height: 80px; background: linear-gradient(135deg, var(--surface-2), var(--surface)); border-radius: var(--radius) var(--radius) 0 0; display: flex; align-items: center; justify-content: center;">
                <span style="font-size: 1.5rem; opacity: 0.2;">&#128247;</span>
              </div>
            ) : null}
            <div style="padding: 0.85rem;">
              <div style="font-weight: 600; font-size: 0.9rem;">
                {formatVal(r.data[titleField])}
              </div>
              {subtitleField && r.data[subtitleField] != null && (
                <div class="muted" style="font-size: 0.8rem; margin-top: 0.3rem;">
                  {formatVal(r.data[subtitleField])}
                </div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function formatVal(v: unknown): string {
  if (v === null || v === undefined) return '';
  if (typeof v === 'boolean') return v ? 'Yes' : 'No';
  if (typeof v === 'number') return v.toLocaleString();
  if (Array.isArray(v)) return v.join(', ');
  return String(v).slice(0, 100);
}
