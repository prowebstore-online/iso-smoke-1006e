// Form submission operations extracted from SiteDO.

const MAX_SUBMISSIONS = 10_000;

export function addSubmission(
  sql: SqlStorage,
  input: { id: string; form_id: string; data: Record<string, string>; ip?: string },
): { ok: boolean; id?: string; error?: string } {
  sql.exec(
    `INSERT INTO submissions (id, form_id, data_json, ip) VALUES (?, ?, ?, ?)`,
    input.id,
    input.form_id,
    JSON.stringify(input.data),
    input.ip ?? null,
  );
  // Cap storage FIFO (evict oldest by insertion order) rather than hard-rejecting
  // at the cap — a one-time flood of MAX_SUBMISSIONS would otherwise reject every
  // legitimate submission afterwards, killing the contact form permanently.
  sql.exec(
    `DELETE FROM submissions WHERE rowid NOT IN (
       SELECT rowid FROM submissions ORDER BY rowid DESC LIMIT ?
     )`,
    MAX_SUBMISSIONS,
  );
  return { ok: true, id: input.id };
}

export function listSubmissions(
  sql: SqlStorage,
  form_id?: string,
  opts?: { limit?: number; offset?: number },
): Array<{ id: string; form_id: string; data: Record<string, string>; created_at: string }> {
  const limit = opts?.limit ?? 50;
  const offset = opts?.offset ?? 0;
  const rows = form_id
    ? sql
        .exec<{ id: string; form_id: string; data_json: string; created_at: string }>(
          `SELECT id, form_id, data_json, created_at FROM submissions WHERE form_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?`,
          form_id,
          limit,
          offset,
        )
        .toArray()
    : sql
        .exec<{ id: string; form_id: string; data_json: string; created_at: string }>(
          `SELECT id, form_id, data_json, created_at FROM submissions ORDER BY created_at DESC LIMIT ? OFFSET ?`,
          limit,
          offset,
        )
        .toArray();
  return rows.map((r) => ({
    id: r.id,
    form_id: r.form_id,
    data: JSON.parse(r.data_json),
    created_at: r.created_at,
  }));
}

export function countSubmissions(sql: SqlStorage): number {
  const rows = sql.exec<{ c: number }>(`SELECT COUNT(*) as c FROM submissions`).toArray();
  return rows[0]?.c ?? 0;
}
