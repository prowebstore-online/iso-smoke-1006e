// RPC interface for SiteDO. Defined separately from the class to break
// the circular type chain (Env ↔ SiteDO ↔ Env). Includes only the methods
// the Worker calls via the stub.

import type {
  AnalyticsConfig,
  Block,
  EntityRecord,
  EntitySchema,
  FooterConfig,
  NavConfig,
  NavPage,
  Page,
  RecordData,
  SeoConfig,
  SiteConfig,
  TemplateBundle,
  Theme,
} from '@pws/shared';

export interface SiteSnapshot {
  config: SiteConfig;
  theme: Theme;
  nav: NavConfig;
  footer: FooterConfig;
  analytics: AnalyticsConfig;
  pages: NavPage[];
}

export type UserRole = 'owner' | 'editor' | 'member';

export interface SiteUser {
  id: string;
  email: string;
  role: UserRole;
  display_name: string | null;
  created_at: string;
  updated_at: string;
}

export interface CreateSessionResult {
  token: string;
  expires_at: number;
  user: SiteUser;
}

export interface SiteRpc {
  // Schemas
  defineEntity(input: {
    slug: string;
    name: string;
    name_plural: string;
    icon?: string;
    fields: import('@pws/shared').FieldDef[];
    source_template?: string;
    system_managed?: boolean;
    public_writable?: boolean;
  }): Promise<EntitySchema>;
  updateEntityFields(slug: string, fields: import('@pws/shared').FieldDef[]): Promise<EntitySchema>;
  evolveEntityFields(
    slug: string,
    changes: import('@pws/shared').FieldDef[],
  ): Promise<
    | { ok: true; schema: EntitySchema; added: string[]; updated: string[] }
    | { ok: false; error: string }
  >;
  listSchemas(): Promise<EntitySchema[]>;
  getSchema(slug: string): Promise<EntitySchema | null>;

  // Records
  addRecord(input: {
    entity_slug: string;
    data: RecordData;
    slug?: string;
    created_by?: string;
  }): Promise<
    | { ok: true; record: EntityRecord }
    | { ok: false; errors: Array<{ path: string; message: string; code: string }> }
  >;
  updateRecord(
    entitySlug: string,
    id: string,
    data: RecordData,
  ): Promise<
    | { ok: true; record: EntityRecord }
    | { ok: false; errors: Array<{ path: string; message: string; code: string }> }
  >;
  getRecord(entitySlug: string, id: string): Promise<EntityRecord | null>;
  getRecordById(id: string): Promise<EntityRecord | null>;
  getRecordBySlug(entitySlug: string, recordSlug: string): Promise<EntityRecord | null>;
  /** Atomically claim a status transition (race-free inside the DO). Returns
   *  whether THIS call made the from→to transition. See SiteDO. */
  claimStatusTransition(
    entitySlug: string,
    id: string,
    from: string,
    to: string,
    extra?: Record<string, unknown>,
  ): Promise<{ transitioned: boolean; rejected?: boolean }>;
  /** Single-use guard for one-time tokens: true only the first time `key` is
   *  seen (before `expiresAtMs`), false on replay. See SiteDO.consumeOnce. */
  consumeOnce(key: string, expiresAtMs: number): Promise<boolean>;
  /** Atomically reserve stock for a checkout (race-free inside the DO). Returns
   *  the granted qty + server-trusted price/name per line. See SiteDO. */
  reserveStock(
    entitySlug: string,
    requests: Array<{ id: string; qty: number }>,
  ): Promise<Array<{ id: string; granted: number; price: number; name: string }>>;
  /** Inverse of reserveStock — add quantities back (refund / cancellation). */
  releaseStock(
    entitySlug: string,
    requests: Array<{ id: string; qty: number }>,
  ): Promise<Array<{ id: string; released: number }>>;
  /** Find the first record of an entity whose field equals a value (e.g. order by payment_ref). */
  getRecordByField(
    entitySlug: string,
    fieldSlug: string,
    value: string,
  ): Promise<EntityRecord | null>;
  listRecords(
    entitySlug: string,
    opts?: { limit?: number; offset?: number; sort?: string },
  ): Promise<EntityRecord[]>;
  searchRecords(
    entitySlug: string,
    query: string,
    opts?: { limit?: number },
  ): Promise<EntityRecord[]>;
  countRecords(entitySlug: string): Promise<number>;
  removeRecord(entitySlug: string, id: string): Promise<{ ok: boolean; removed: boolean }>;

  // Pages
  upsertPage(input: {
    slug: string;
    title: string;
    page_type: string;
    blocks: Block[];
    seo?: SeoConfig | null;
    show_in_nav?: boolean;
    nav_label?: string | null;
    nav_order?: number;
    auth_required?: boolean;
  }): Promise<
    | { ok: true; page: Page }
    | { ok: false; errors: Array<{ path: string; message: string; code: string }> }
  >;
  getPage(slug: string): Promise<Page | null>;
  listPages(): Promise<Page[]>;
  removePage(slug: string): Promise<{ ok: boolean; error?: string }>;
  listPageRevisions(
    slug: string,
    limit?: number,
  ): Promise<
    Array<{
      id: number;
      slug: string;
      title: string;
      blocks: unknown[];
      seo: unknown;
      created_at: string;
      created_by: string | null;
    }>
  >;
  restorePageRevision(
    slug: string,
    revisionId: number,
  ): Promise<{ ok: true; page: Page } | { ok: false; error: string }>;

  // Translations
  setTranslation(
    locale: string,
    key: string,
    value: string,
    source?: string,
  ): Promise<{ ok: boolean }>;
  deleteTranslation(locale: string, key: string): Promise<{ ok: boolean }>;
  getTranslations(locale: string): Promise<Record<string, string>>;
  listTranslationLocales(): Promise<Array<{ locale: string; count: number }>>;
  listTranslationKeys(
    locale: string,
  ): Promise<Array<{ key: string; value: string; source: string; updated_at: string }>>;

  // Site meta + snapshot
  setMeta(
    key: 'config' | 'theme' | 'nav' | 'footer' | 'analytics' | 'webhooks',
    value: unknown,
  ): Promise<
    { ok: true } | { ok: false; errors: Array<{ path: string; message: string; code: string }> }
  >;
  siteSnapshot(): Promise<SiteSnapshot>;

  // Site content version (bumped on every mutation; drives KV cache key)
  getVersion(): Promise<number>;

  // Users
  createUser(input: {
    email: string;
    password: string;
    role: UserRole;
    display_name?: string;
  }): Promise<SiteUser>;
  listUsers(): Promise<SiteUser[]>;
  getUserById(id: string): Promise<SiteUser | null>;
  getUserByEmail(email: string): Promise<SiteUser | null>;
  removeUser(id: string): Promise<{ ok: boolean; removed: boolean }>;

  // Sessions
  authenticate(email: string, password: string): Promise<CreateSessionResult | null>;
  /** Issue a session for a verified external identity (Google OAuth). Returns null if email not found. */
  authenticateByEmail(email: string): Promise<CreateSessionResult | null>;
  resolveSession(token: string): Promise<SiteUser | null>;
  revokeSession(token: string): Promise<{ ok: true; revoked: boolean }>;
  revokeUserSessions(userId: string): Promise<{ ok: true; revoked: number }>;

  // Submissions
  addSubmission(input: {
    id: string;
    form_id: string;
    data: Record<string, string>;
    ip?: string;
  }): Promise<{ ok: boolean; id?: string; error?: string }>;
  listSubmissions(
    form_id?: string,
    opts?: { limit?: number; offset?: number },
  ): Promise<
    Array<{ id: string; form_id: string; data: Record<string, string>; created_at: string }>
  >;
  countSubmissions(): Promise<number>;

  // Templates
  applyTemplate(bundle: TemplateBundle): Promise<{
    schemas: number;
    records: number;
    pages: number;
  }>;

  // Admin Views
  defineAdminView(input: {
    entity_slug: string;
    label: string;
    icon?: string;
    layout?: string;
    sort_order?: number;
    config?: Record<string, unknown>;
  }): Promise<{ ok: true; id: string }>;
  listAdminViews(): Promise<
    Array<{
      id: string;
      entity_slug: string;
      label: string;
      icon: string | null;
      layout: string;
      sort_order: number;
      config: Record<string, unknown>;
    }>
  >;
  updateAdminView(
    id: string,
    updates: {
      label?: string;
      icon?: string;
      layout?: string;
      sort_order?: number;
      config?: Record<string, unknown>;
    },
  ): Promise<{ ok: boolean }>;
  removeAdminView(id: string): Promise<{ ok: boolean }>;
  addAdminWidget(input: {
    widget_type: string;
    label: string;
    config?: Record<string, unknown>;
    sort_order?: number;
  }): Promise<{ ok: true; id: string }>;
  listAdminWidgets(): Promise<
    Array<{
      id: string;
      widget_type: string;
      label: string;
      config: Record<string, unknown>;
      sort_order: number;
    }>
  >;

  // Diagnostics
  diagnostics(): Promise<{
    schema_v: number;
    site_v: number;
    entities: number;
    records: number;
    pages: number;
    users: number;
  }>;
}

export interface SessionStats {
  message_count: number;
  created_at: string | null;
  updated_at: string | null;
}

export interface SessionRpc {
  setMessages(
    messages: import('@anthropic-ai/sdk/resources/messages').MessageParam[],
  ): Promise<{ ok: true; count: number }>;
  appendMessages(
    messages: import('@anthropic-ai/sdk/resources/messages').MessageParam[],
  ): Promise<{ ok: true; appended: number; total: number }>;
  getMessages(): Promise<import('@anthropic-ai/sdk/resources/messages').MessageParam[]>;
  reset(): Promise<{ ok: true; cleared: number }>;
  stats(): Promise<SessionStats>;
}
