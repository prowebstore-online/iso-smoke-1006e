// Admin view + widget operations extracted from SiteDO.

interface AdminViewRow extends Record<string, SqlStorageValue> {
  id: string;
  entity_slug: string;
  label: string;
  icon: string | null;
  layout: string;
  sort_order: number;
  config_json: string;
}

export interface AdminView {
  id: string;
  entity_slug: string;
  label: string;
  icon: string | null;
  layout: string;
  sort_order: number;
  config: Record<string, unknown>;
}

export interface AdminWidget {
  id: string;
  widget_type: string;
  label: string;
  config: Record<string, unknown>;
  sort_order: number;
}

export function defineAdminView(
  sql: SqlStorage,
  input: {
    entity_slug: string;
    label: string;
    icon?: string;
    layout?: string;
    sort_order?: number;
    config?: Record<string, unknown>;
  },
): { ok: true; id: string } {
  const id = crypto.randomUUID();
  const layout = input.layout ?? 'table';
  if (!['table', 'cards', 'pipeline', 'calendar', 'list'].includes(layout)) {
    throw new Error(
      `Invalid layout '${layout}'. Must be table, cards, pipeline, calendar, or list.`,
    );
  }
  sql.exec(
    `INSERT INTO admin_views (id, entity_slug, label, icon, layout, sort_order, config_json)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    id,
    input.entity_slug,
    input.label,
    input.icon ?? null,
    layout,
    input.sort_order ?? 0,
    JSON.stringify(input.config ?? {}),
  );
  return { ok: true, id };
}

export function listAdminViews(sql: SqlStorage): AdminView[] {
  const rows = sql
    .exec<AdminViewRow>(`SELECT * FROM admin_views ORDER BY sort_order ASC, label ASC`)
    .toArray();
  return rows.map((r) => ({
    id: r.id,
    entity_slug: r.entity_slug,
    label: r.label,
    icon: r.icon,
    layout: r.layout,
    sort_order: r.sort_order,
    config: JSON.parse(r.config_json) as Record<string, unknown>,
  }));
}

export function updateAdminView(
  sql: SqlStorage,
  id: string,
  updates: {
    label?: string;
    icon?: string;
    layout?: string;
    sort_order?: number;
    config?: Record<string, unknown>;
  },
): { ok: boolean } {
  const sets: string[] = [];
  const vals: unknown[] = [];
  if (updates.label !== undefined) {
    sets.push('label = ?');
    vals.push(updates.label);
  }
  if (updates.icon !== undefined) {
    sets.push('icon = ?');
    vals.push(updates.icon);
  }
  if (updates.layout !== undefined) {
    if (!['table', 'cards', 'pipeline', 'calendar', 'list'].includes(updates.layout)) {
      throw new Error(`Invalid layout '${updates.layout}'.`);
    }
    sets.push('layout = ?');
    vals.push(updates.layout);
  }
  if (updates.sort_order !== undefined) {
    sets.push('sort_order = ?');
    vals.push(updates.sort_order);
  }
  if (updates.config !== undefined) {
    sets.push('config_json = ?');
    vals.push(JSON.stringify(updates.config));
  }
  if (sets.length === 0) return { ok: true };
  sets.push("updated_at = datetime('now')");
  vals.push(id);
  sql.exec(`UPDATE admin_views SET ${sets.join(', ')} WHERE id = ?`, ...vals);
  return { ok: true };
}

export function removeAdminView(sql: SqlStorage, id: string): { ok: boolean } {
  sql.exec(`DELETE FROM admin_views WHERE id = ?`, id);
  return { ok: true };
}

export function addAdminWidget(
  sql: SqlStorage,
  input: {
    widget_type: string;
    label: string;
    config?: Record<string, unknown>;
    sort_order?: number;
  },
): { ok: true; id: string } {
  const id = crypto.randomUUID();
  if (!['stat', 'recent', 'inbox'].includes(input.widget_type)) {
    throw new Error(`Invalid widget_type '${input.widget_type}'.`);
  }
  sql.exec(
    `INSERT INTO admin_widgets (id, widget_type, label, config_json, sort_order)
     VALUES (?, ?, ?, ?, ?)`,
    id,
    input.widget_type,
    input.label,
    JSON.stringify(input.config ?? {}),
    input.sort_order ?? 0,
  );
  return { ok: true, id };
}

export function listAdminWidgets(sql: SqlStorage): AdminWidget[] {
  const rows = sql
    .exec<{
      id: string;
      widget_type: string;
      label: string;
      config_json: string;
      sort_order: number;
    }>(`SELECT * FROM admin_widgets ORDER BY sort_order ASC`)
    .toArray();
  return rows.map((r) => ({
    id: r.id,
    widget_type: r.widget_type,
    label: r.label,
    config: JSON.parse(r.config_json) as Record<string, unknown>,
    sort_order: r.sort_order,
  }));
}
