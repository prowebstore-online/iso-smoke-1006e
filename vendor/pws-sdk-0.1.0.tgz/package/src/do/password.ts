// Password hashing for SiteDO users.
// Uses WebCrypto PBKDF2-SHA256 (Workers-native, no deps, FIPS-approved).
// Stored format: pbkdf2$sha256$<iterations>$<saltB64>$<hashB64>
//
// Argon2id would be stronger but requires WASM in Workers. PBKDF2 at 100k
// iterations gives ~80ms hash on a Worker isolate — fine for login latency
// and slow enough to make offline brute-force costly. Bump iterations on a
// future schema migration if needed.

const ITERATIONS = 100_000;
const SALT_BYTES = 16;
const HASH_BYTES = 32; // 256 bits — matches SHA-256 output

export async function hashPassword(password: string): Promise<string> {
  const salt = crypto.getRandomValues(new Uint8Array(SALT_BYTES));
  const hash = await pbkdf2(password, salt, ITERATIONS, HASH_BYTES);
  return `pbkdf2$sha256$${ITERATIONS}$${b64encode(salt)}$${b64encode(hash)}`;
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const parts = stored.split('$');
  if (parts.length !== 5 || parts[0] !== 'pbkdf2' || parts[1] !== 'sha256') return false;
  const iterations = Number(parts[2]);
  if (!Number.isInteger(iterations) || iterations < 1000) return false;
  const salt = b64decode(parts[3] ?? '');
  const expected = b64decode(parts[4] ?? '');
  const actual = await pbkdf2(password, salt, iterations, expected.length);
  return constantTimeEqualsBytes(actual, expected);
}

async function pbkdf2(
  password: string,
  salt: Uint8Array,
  iterations: number,
  outBytes: number,
): Promise<Uint8Array> {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey(
    'raw',
    enc.encode(password),
    { name: 'PBKDF2' },
    false,
    ['deriveBits'],
  );
  const bits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt, iterations, hash: 'SHA-256' },
    key,
    outBytes * 8,
  );
  return new Uint8Array(bits);
}

/** Constant-time byte comparison; assumes equal length. */
function constantTimeEqualsBytes(a: Uint8Array, b: Uint8Array): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= (a[i] ?? 0) ^ (b[i] ?? 0);
  return diff === 0;
}

function b64encode(bytes: Uint8Array): string {
  let s = '';
  for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i] ?? 0);
  return btoa(s);
}

function b64decode(s: string): Uint8Array {
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

// ─── Session token utilities ────────────────────────────────────────────────

const TOKEN_BYTES = 32;

/** Generate a fresh, opaque session token (64-char hex, 256 bits of entropy). */
export function generateSessionToken(): string {
  const bytes = crypto.getRandomValues(new Uint8Array(TOKEN_BYTES));
  return Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('');
}

/** SHA-256 of a token, hex-encoded. Stored in the DB; lookup keyed on this. */
export async function hashSessionToken(token: string): Promise<string> {
  const enc = new TextEncoder();
  const digest = await crypto.subtle.digest('SHA-256', enc.encode(token));
  const bytes = new Uint8Array(digest);
  return Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('');
}
