// Page operations extracted from SiteDO.

import type { Block, NavPage, Page, SeoConfig } from '@pws/shared';
import { validateBlocks } from '@pws/shared';

interface PageRow extends Record<string, SqlStorageValue> {
  id: string;
  slug: string;
  title: string;
  page_type: string;
  blocks_json: string;
  seo_json: string | null;
  show_in_nav: number;
  nav_label: string | null;
  nav_order: number;
  auth_required: number;
  created_at: string;
  updated_at: string;
}

export interface UpsertPageInput {
  slug: string;
  title: string;
  page_type: string;
  blocks: Block[];
  seo?: SeoConfig | null;
  show_in_nav?: boolean;
  nav_label?: string | null;
  nav_order?: number;
  auth_required?: boolean;
}

export interface UpsertPageResult {
  ok: true;
  page: Page;
}

export interface ValidationFailure {
  ok: false;
  errors: Array<{ path: string; message: string; code: string }>;
}

export function upsertPage(
  sql: SqlStorage,
  input: UpsertPageInput,
): UpsertPageResult | ValidationFailure {
  if (input.slug !== '/' && !/^\/[a-z0-9][a-z0-9\-/]*$/.test(input.slug)) {
    return {
      ok: false,
      errors: [
        {
          path: 'slug',
          message:
            'Page slug must start with / and contain only lowercase letters, digits, hyphens, and forward slashes.',
          code: 'invalid_slug',
        },
      ],
    };
  }
  if (input.slug.includes('..') || input.slug.includes('//')) {
    return {
      ok: false,
      errors: [
        { path: 'slug', message: 'Page slug must not contain .. or //.', code: 'invalid_slug' },
      ],
    };
  }
  if (!input.title || input.title.length > 200) {
    return {
      ok: false,
      errors: [
        {
          path: 'title',
          message: 'Page title is required and must be ≤ 200 characters.',
          code: 'invalid_title',
        },
      ],
    };
  }

  const blockValidation = validateBlocks(input.blocks);
  if (!blockValidation.ok) {
    return { ok: false, errors: blockValidation.errors };
  }

  const existing = sql.exec<PageRow>(`SELECT * FROM pages WHERE slug = ?`, input.slug).toArray();
  const id = existing[0]?.id ?? crypto.randomUUID();
  const blocksJson = JSON.stringify(blockValidation.blocks);
  const seoJson = input.seo ? JSON.stringify(input.seo) : null;
  const showInNav = input.show_in_nav === false ? 0 : 1;
  const navOrder = input.nav_order ?? 0;
  const navLabel = input.nav_label ?? null;
  // Preserve auth_required when the caller omits it. This is a full-row UPDATE,
  // but auth_required is an access-control flag: MCP upsert_page and the client
  // SDK don't send it, so treating "omitted" as false would silently turn a
  // members-only page public on an ordinary content edit. Explicit true/false
  // still sets it.
  const authRequired =
    input.auth_required === undefined
      ? (existing[0]?.auth_required ?? 0)
      : input.auth_required
        ? 1
        : 0;

  if (existing[0]) {
    sql.exec(
      `UPDATE pages SET title=?, page_type=?, blocks_json=?, seo_json=?,
        show_in_nav=?, nav_label=?, nav_order=?, auth_required=?, updated_at=datetime('now')
       WHERE id=?`,
      input.title,
      input.page_type,
      blocksJson,
      seoJson,
      showInNav,
      navLabel,
      navOrder,
      authRequired,
      id,
    );
  } else {
    sql.exec(
      `INSERT INTO pages
        (id, slug, title, page_type, blocks_json, seo_json, show_in_nav, nav_label, nav_order, auth_required)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      id,
      input.slug,
      input.title,
      input.page_type,
      blocksJson,
      seoJson,
      showInNav,
      navLabel,
      navOrder,
      authRequired,
    );
  }

  const page = getPage(sql, input.slug);
  if (!page) throw new Error('page not found after upsert');
  return { ok: true, page };
}

export function getPage(sql: SqlStorage, slug: string): Page | null {
  const rows = sql.exec<PageRow>(`SELECT * FROM pages WHERE slug = ?`, slug).toArray();
  return rows[0] ? rowToPage(rows[0]) : null;
}

export function listPages(sql: SqlStorage): Page[] {
  const rows = sql.exec<PageRow>(`SELECT * FROM pages ORDER BY nav_order ASC, slug ASC`).toArray();
  return rows.map(rowToPage);
}

/** Lightweight page list for navigation — skips blocks/seo deserialization. */
export function listNavPages(sql: SqlStorage): NavPage[] {
  const rows = sql
    .exec<PageRow>(
      `SELECT id, slug, title, page_type, show_in_nav, nav_label, nav_order, auth_required, created_at, updated_at FROM pages ORDER BY nav_order ASC, slug ASC`,
    )
    .toArray();
  return rows.map((r) => ({
    id: r.id,
    slug: r.slug,
    title: r.title,
    page_type: r.page_type,
    show_in_nav: r.show_in_nav === 1,
    nav_label: r.nav_label ?? null,
    nav_order: r.nav_order,
    auth_required: r.auth_required === 1,
    created_at: r.created_at,
    updated_at: r.updated_at,
  }));
}

/**
 * Delete a page, and say whether one was actually there.
 *
 * This used to return `{ ok: true }` unconditionally. That is what made #39
 * invisible: the API was addressing `/` for every slug, so seven deletes aimed
 * at seven different pages removed exactly one page and still reported seven
 * successes. A delete that matched nothing must say so — it is the cheapest
 * check that turns a misaddressed write into a visible failure.
 */
export function removePage(sql: SqlStorage, slug: string): { ok: boolean; error?: string } {
  const existing = sql.exec(`SELECT id FROM pages WHERE slug = ?`, slug).toArray();
  if (existing.length === 0) return { ok: false, error: `Page '${slug}' not found.` };
  sql.exec(`DELETE FROM pages WHERE slug = ?`, slug);
  return { ok: true };
}

function rowToPage(row: PageRow): Page {
  return {
    id: row.id,
    slug: row.slug,
    title: row.title,
    page_type: row.page_type,
    blocks: JSON.parse(row.blocks_json) as Block[],
    seo: row.seo_json ? (JSON.parse(row.seo_json) as SeoConfig) : null,
    show_in_nav: row.show_in_nav === 1,
    nav_label: row.nav_label,
    nav_order: row.nav_order,
    auth_required: row.auth_required === 1,
    created_at: row.created_at,
    updated_at: row.updated_at,
  };
}
