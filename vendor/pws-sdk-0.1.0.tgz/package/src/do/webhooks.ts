// Webhook notifications — fire HTTP callbacks when content changes.
// Stored in site_meta as key 'webhooks'.
// Format: { url: string, events: string[], secret?: string }[]

import { isPrivateHost } from '../media.ts';

export interface WebhookConfig {
  url: string;
  events: string[]; // 'page.updated', 'record.created', 'record.updated', 'record.deleted', 'entity.created', 'member.registered'
  secret?: string;
}

export interface WebhookPayload {
  event: string;
  site_id: string;
  timestamp: string;
  data: Record<string, unknown>;
}

export async function fireWebhooks(
  webhooks: WebhookConfig[],
  event: string,
  siteId: string,
  data: Record<string, unknown>,
): Promise<void> {
  const matching = webhooks.filter((w) => w.events.includes(event) || w.events.includes('*'));
  if (matching.length === 0) return;

  const payload: WebhookPayload = {
    event,
    site_id: siteId,
    timestamp: new Date().toISOString(),
    data,
  };
  const body = JSON.stringify(payload);

  await Promise.allSettled(
    matching.map(async (wh) => {
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        'User-Agent': 'pws-webhook/1.0',
      };
      if (wh.secret) {
        // HMAC signature for webhook verification
        const encoder = new TextEncoder();
        const key = await crypto.subtle.importKey(
          'raw',
          encoder.encode(wh.secret),
          { name: 'HMAC', hash: 'SHA-256' },
          false,
          ['sign'],
        );
        const sig = await crypto.subtle.sign('HMAC', key, encoder.encode(body));
        headers['X-Webhook-Signature'] = Array.from(new Uint8Array(sig))
          .map((b) => b.toString(16).padStart(2, '0'))
          .join('');
      }
      try {
        const parsed = new URL(wh.url);
        // Block non-HTTPS and private/internal targets (SSRF prevention). Reuse
        // the media isPrivateHost helper — the previous inline check both missed
        // ranges (IPv6 ULA/link-local, 100.64/10) AND over-blocked with a bare
        // `172.2` prefix that rejected legitimate public 172.2x.x.x hosts.
        if (parsed.protocol !== 'https:') return;
        if (isPrivateHost(parsed.hostname)) return;
        await fetch(wh.url, { method: 'POST', headers, body, redirect: 'error' });
      } catch {
        // Fire-and-forget — webhook failures don't block the operation
      }
    }),
  );
}
