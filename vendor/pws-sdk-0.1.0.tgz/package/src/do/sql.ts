// Per-site SQLite schema, applied inside SiteDO.
// Each statement is idempotent (`IF NOT EXISTS`); the runner walks
// `do_meta.schema_v` forward to support future structural migrations.

export const DO_SCHEMA_VERSION = 8;

export const DO_SCHEMA_STATEMENTS_V1 = [
  // DO-internal version tracking.
  `CREATE TABLE IF NOT EXISTS do_meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  )`,

  // Entity schemas (one row per entity type).
  `CREATE TABLE IF NOT EXISTS schemas (
    slug TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    name_plural TEXT NOT NULL,
    icon TEXT,
    fields_json TEXT NOT NULL,
    source_template TEXT,
    version INTEGER NOT NULL DEFAULT 1,
    system_managed INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
  )`,

  // All entity records share one table — keeps DDL out of the hot path.
  `CREATE TABLE IF NOT EXISTS records (
    id TEXT PRIMARY KEY,
    entity_slug TEXT NOT NULL,
    slug TEXT,
    data_json TEXT NOT NULL,
    search_text TEXT,
    schema_version INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'live',
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now')),
    created_by TEXT,
    FOREIGN KEY (entity_slug) REFERENCES schemas(slug) ON DELETE CASCADE
  )`,
  `CREATE INDEX IF NOT EXISTS idx_records_entity ON records(entity_slug, status)`,
  `CREATE UNIQUE INDEX IF NOT EXISTS idx_records_slug
    ON records(entity_slug, slug) WHERE slug IS NOT NULL`,
  `CREATE INDEX IF NOT EXISTS idx_records_updated ON records(updated_at DESC)`,

  // Reference graph (denormalized for fast reverse lookup).
  `CREATE TABLE IF NOT EXISTS refs (
    source_entity TEXT NOT NULL,
    source_id TEXT NOT NULL,
    source_field TEXT NOT NULL,
    target_entity TEXT NOT NULL,
    target_id TEXT NOT NULL,
    PRIMARY KEY (source_entity, source_id, source_field, target_id)
  )`,
  `CREATE INDEX IF NOT EXISTS idx_refs_target ON refs(target_entity, target_id)`,

  // Schema migration log (audit + in-flight tracking).
  `CREATE TABLE IF NOT EXISTS schema_migrations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    entity_slug TEXT NOT NULL,
    from_version INTEGER NOT NULL,
    to_version INTEGER NOT NULL,
    diff_json TEXT NOT NULL,
    strategy_json TEXT,
    status TEXT NOT NULL,
    records_total INTEGER,
    records_done INTEGER NOT NULL DEFAULT 0,
    applied_at TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    initiated_by TEXT
  )`,

  // Pages — ordered blocks under a slug.
  `CREATE TABLE IF NOT EXISTS pages (
    id TEXT PRIMARY KEY,
    slug TEXT NOT NULL UNIQUE,
    title TEXT NOT NULL,
    page_type TEXT NOT NULL,
    blocks_json TEXT NOT NULL,
    seo_json TEXT,
    show_in_nav INTEGER NOT NULL DEFAULT 1,
    nav_label TEXT,
    nav_order INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
  )`,
  `CREATE INDEX IF NOT EXISTS idx_pages_nav ON pages(show_in_nav, nav_order)`,

  // Site-level config + theme + nav + footer (single-row k/v store).
  `CREATE TABLE IF NOT EXISTS site_meta (
    key TEXT PRIMARY KEY,
    value_json TEXT NOT NULL,
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
  )`,
];

// v2 — multi-user auth. Per-site users (owner, editor) and opaque session
// tokens. Tokens are stored as SHA-256 hashes so a DB leak never exposes
// usable bearer credentials.
export const DO_SCHEMA_STATEMENTS_V2 = [
  `CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('owner', 'editor')),
    display_name TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
  )`,
  `CREATE INDEX IF NOT EXISTS idx_users_email ON users(email)`,

  `CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    expires_at INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    last_used_at TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  )`,
  `CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id)`,
  `CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions(expires_at)`,
];

// v3 — form submissions. Public visitors submit contact forms; stored per-site.
export const DO_SCHEMA_STATEMENTS_V3 = [
  `CREATE TABLE IF NOT EXISTS submissions (
    id TEXT PRIMARY KEY,
    form_id TEXT NOT NULL,
    data_json TEXT NOT NULL,
    ip TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  )`,
  `CREATE INDEX IF NOT EXISTS idx_submissions_form ON submissions(form_id, created_at DESC)`,
];

// v4 — entity-bound forms. Schemas gain public_writable flag for form submissions.
export const DO_SCHEMA_STATEMENTS_V4 = [
  `ALTER TABLE schemas ADD COLUMN public_writable INTEGER NOT NULL DEFAULT 0`,
];

// v5 — admin views + dashboard widgets. AI-evolvable admin portal.
export const DO_SCHEMA_STATEMENTS_V5 = [
  `CREATE TABLE IF NOT EXISTS admin_views (
    id TEXT PRIMARY KEY,
    entity_slug TEXT NOT NULL,
    label TEXT NOT NULL,
    icon TEXT,
    layout TEXT NOT NULL DEFAULT 'table',
    sort_order INTEGER NOT NULL DEFAULT 0,
    config_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (entity_slug) REFERENCES schemas(slug) ON DELETE CASCADE
  )`,
  `CREATE INDEX IF NOT EXISTS idx_admin_views_entity ON admin_views(entity_slug)`,
  `CREATE TABLE IF NOT EXISTS admin_widgets (
    id TEXT PRIMARY KEY,
    widget_type TEXT NOT NULL,
    label TEXT NOT NULL,
    config_json TEXT NOT NULL DEFAULT '{}',
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  )`,
];

// v6 — member auth. Rebuild users table to widen CHECK constraint
// (SQLite enforces CHECK on INSERT — can't just ALTER it).
// Add auth_required column to pages for member-gated content.
export const DO_SCHEMA_STATEMENTS_V6 = [
  `ALTER TABLE pages ADD COLUMN auth_required INTEGER NOT NULL DEFAULT 0`,
  // Rebuild users table with widened role CHECK
  `CREATE TABLE IF NOT EXISTS users_v6 (
    id TEXT PRIMARY KEY,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('owner', 'editor', 'member')),
    display_name TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
  )`,
  `INSERT OR IGNORE INTO users_v6 SELECT * FROM users`,
  `DROP TABLE users`,
  `ALTER TABLE users_v6 RENAME TO users`,
  `CREATE INDEX IF NOT EXISTS idx_users_email ON users(email)`,
  // Rebuild sessions FK (old FK pointed to dropped table)
  `CREATE TABLE IF NOT EXISTS sessions_v6 (
    token_hash TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    expires_at INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    last_used_at TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  )`,
  `INSERT OR IGNORE INTO sessions_v6 SELECT * FROM sessions`,
  `DROP TABLE sessions`,
  `ALTER TABLE sessions_v6 RENAME TO sessions`,
  `CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id)`,
  `CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions(expires_at)`,
];

// v7 — content versioning (page revision history).
export const DO_SCHEMA_STATEMENTS_V7 = [
  `CREATE TABLE IF NOT EXISTS page_revisions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    page_slug TEXT NOT NULL,
    blocks_json TEXT NOT NULL,
    seo_json TEXT,
    title TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    created_by TEXT
  )`,
  `CREATE INDEX IF NOT EXISTS idx_page_revisions_slug ON page_revisions(page_slug, id DESC)`,
];

// v8 — translations table for multilingual content.
// Key format: "page:/about:hero-1:heading" or "nav:home" or "config:title"
export const DO_SCHEMA_STATEMENTS_V8 = [
  `CREATE TABLE IF NOT EXISTS translations (
    locale TEXT NOT NULL,
    key TEXT NOT NULL,
    value TEXT NOT NULL,
    source TEXT NOT NULL DEFAULT 'manual',
    updated_at TEXT NOT NULL DEFAULT (datetime('now')),
    PRIMARY KEY (locale, key)
  )`,
  `CREATE INDEX IF NOT EXISTS idx_translations_locale ON translations(locale)`,
];
