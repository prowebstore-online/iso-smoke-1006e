// User + session operations extracted from SiteDO.

import {
  generateSessionToken,
  hashPassword,
  hashSessionToken,
  verifyPassword,
} from './password.ts';

export type UserRole = 'owner' | 'editor' | 'member';

export interface SiteUser {
  id: string;
  email: string;
  role: UserRole;
  display_name: string | null;
  created_at: string;
  updated_at: string;
}

export interface CreateUserInput {
  email: string;
  password: string;
  role: UserRole;
  display_name?: string;
}

export interface CreateSessionResult {
  token: string;
  expires_at: number;
  user: SiteUser;
}

interface UserRow extends Record<string, SqlStorageValue> {
  id: string;
  email: string;
  password_hash: string;
  role: string;
  display_name: string | null;
  created_at: string;
  updated_at: string;
}

const SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000;

export async function createUser(sql: SqlStorage, input: CreateUserInput): Promise<SiteUser> {
  const email = normalizeEmail(input.email);
  if (!isValidEmail(email)) throw new Error('invalid email');
  if (input.password.length < 8) throw new Error('password must be at least 8 characters');
  if (input.role !== 'owner' && input.role !== 'editor' && input.role !== 'member') {
    throw new Error(`invalid role '${input.role}': must be 'owner', 'editor', or 'member'`);
  }
  const id = crypto.randomUUID();
  const passwordHash = await hashPassword(input.password);
  try {
    sql.exec(
      `INSERT INTO users (id, email, password_hash, role, display_name) VALUES (?, ?, ?, ?, ?)`,
      id,
      email,
      passwordHash,
      input.role,
      input.display_name ?? null,
    );
  } catch (err) {
    const msg = (err as Error).message;
    if (/UNIQUE|constraint/i.test(msg)) {
      throw new Error(`a user with email '${email}' already exists`);
    }
    throw err;
  }
  const user = getUserByEmail(sql, email);
  if (!user) throw new Error('user not found after insert');
  return user;
}

export function listUsers(sql: SqlStorage): SiteUser[] {
  const rows = sql.exec<UserRow>(`SELECT * FROM users ORDER BY created_at ASC`).toArray();
  return rows.map(rowToUser);
}

export function getUserById(sql: SqlStorage, id: string): SiteUser | null {
  const rows = sql.exec<UserRow>(`SELECT * FROM users WHERE id = ?`, id).toArray();
  return rows[0] ? rowToUser(rows[0]) : null;
}

export function getUserByEmail(sql: SqlStorage, email: string): SiteUser | null {
  const rows = sql
    .exec<UserRow>(`SELECT * FROM users WHERE email = ?`, normalizeEmail(email))
    .toArray();
  return rows[0] ? rowToUser(rows[0]) : null;
}

export function removeUser(sql: SqlStorage, id: string): { ok: boolean; removed: boolean } {
  const rows = sql.exec<UserRow>(`SELECT * FROM users WHERE id = ?`, id).toArray();
  if (rows.length === 0) return { ok: true, removed: false };
  sql.exec(`DELETE FROM users WHERE id = ?`, id);
  return { ok: true, removed: true };
}

export async function authenticate(
  sql: SqlStorage,
  email: string,
  password: string,
): Promise<CreateSessionResult | null> {
  const normEmail = normalizeEmail(email);
  const rows = sql.exec<UserRow>(`SELECT * FROM users WHERE email = ?`, normEmail).toArray();
  const row = rows[0];
  const dummyHash =
    'pbkdf2$sha256$100000$AAAAAAAAAAAAAAAAAAAAAA==$AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=';
  const ok = await verifyPassword(password, row?.password_hash ?? dummyHash);
  if (!row || !ok) return null;
  return issueSession(sql, rowToUser(row));
}

export async function authenticateByEmail(
  sql: SqlStorage,
  email: string,
): Promise<CreateSessionResult | null> {
  const user = getUserByEmail(sql, email);
  if (!user) return null;
  return issueSession(sql, user);
}

export async function resolveSession(sql: SqlStorage, token: string): Promise<SiteUser | null> {
  if (!token || token.length !== 64) return null;
  const tokenHash = await hashSessionToken(token);
  const rows = sql
    .exec<{ user_id: string; expires_at: number }>(
      `SELECT user_id, expires_at FROM sessions WHERE token_hash = ?`,
      tokenHash,
    )
    .toArray();
  const session = rows[0];
  if (!session) return null;
  if (session.expires_at < Date.now()) {
    sql.exec(`DELETE FROM sessions WHERE token_hash = ?`, tokenHash);
    return null;
  }
  sql.exec(`UPDATE sessions SET last_used_at = datetime('now') WHERE token_hash = ?`, tokenHash);
  return getUserById(sql, session.user_id);
}

export async function revokeSession(
  sql: SqlStorage,
  token: string,
): Promise<{ ok: true; revoked: boolean }> {
  if (!token || token.length !== 64) return { ok: true, revoked: false };
  const tokenHash = await hashSessionToken(token);
  const before = sql
    .exec<{ c: number }>(`SELECT COUNT(*) as c FROM sessions WHERE token_hash = ?`, tokenHash)
    .toArray();
  sql.exec(`DELETE FROM sessions WHERE token_hash = ?`, tokenHash);
  return { ok: true, revoked: (before[0]?.c ?? 0) > 0 };
}

export function revokeUserSessions(sql: SqlStorage, userId: string): { ok: true; revoked: number } {
  const before = sql
    .exec<{ c: number }>(`SELECT COUNT(*) as c FROM sessions WHERE user_id = ?`, userId)
    .toArray();
  sql.exec(`DELETE FROM sessions WHERE user_id = ?`, userId);
  return { ok: true, revoked: before[0]?.c ?? 0 };
}

async function issueSession(sql: SqlStorage, user: SiteUser): Promise<CreateSessionResult> {
  sql.exec(`DELETE FROM sessions WHERE expires_at < ?`, Date.now());
  const token = generateSessionToken();
  const tokenHash = await hashSessionToken(token);
  const expiresAt = Date.now() + SESSION_TTL_MS;
  sql.exec(
    `INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?, ?, ?)`,
    tokenHash,
    user.id,
    expiresAt,
  );
  return { token, expires_at: expiresAt, user };
}

function normalizeEmail(email: string): string {
  return email.trim().toLowerCase();
}

function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

const VALID_ROLES: Record<string, UserRole> = {
  owner: 'owner',
  editor: 'editor',
  member: 'member',
};

function rowToUser(row: UserRow): SiteUser {
  return {
    id: row.id,
    email: row.email,
    role: VALID_ROLES[row.role] ?? 'member',
    display_name: row.display_name,
    created_at: row.created_at,
    updated_at: row.updated_at,
  };
}
