// SiteDO: per-site source of truth.
// One DO instance per site_id, single-writer, transactional.
// Delegates to focused sub-modules; this file is the RPC facade.

import { DurableObject } from 'cloudflare:workers';
import { DEFAULT_THEME, evolveFields } from '@pws/shared';
import type { Page, TemplateBundle } from '@pws/shared';
import * as adminViews from './admin-views.ts';
import * as auth from './auth.ts';
import { CONTENT_MIGRATION_VERSION, runContentMigrations } from './content-migrations.ts';
import * as meta from './meta.ts';
import * as pages from './pages.ts';
import * as records from './records.ts';
import * as schemas from './schemas.ts';
import {
  DO_SCHEMA_STATEMENTS_V1,
  DO_SCHEMA_STATEMENTS_V2,
  DO_SCHEMA_STATEMENTS_V3,
  DO_SCHEMA_STATEMENTS_V4,
  DO_SCHEMA_STATEMENTS_V5,
  DO_SCHEMA_STATEMENTS_V6,
  DO_SCHEMA_STATEMENTS_V7,
  DO_SCHEMA_STATEMENTS_V8,
  DO_SCHEMA_VERSION,
} from './sql.ts';
import * as submissions from './submissions.ts';
import { type WebhookConfig, fireWebhooks } from './webhooks.ts';

// Re-export types used by other modules.
export type { SiteUser, UserRole, CreateUserInput, CreateSessionResult } from './auth.ts';
export type { DefineEntityInput } from './schemas.ts';
export type { AddRecordInput, AddRecordResult, ValidationFailure } from './records.ts';
export type { UpsertPageInput, UpsertPageResult } from './pages.ts';
export type { SiteSnapshot } from './meta.ts';

export class SiteDO extends DurableObject {
  private sql: SqlStorage;
  private storage: DurableObjectStorage;
  private _snapshotCache: import('./meta.ts').SiteSnapshot | null = null;

  constructor(state: DurableObjectState, env: never) {
    super(state, env);
    this.sql = state.storage.sql;
    this.storage = state.storage;
    this.bootstrap();
  }

  // ---- Bootstrap & migrations ----

  private bootstrap() {
    const currentVersion = this.getDoSchemaVersion();
    if (currentVersion < DO_SCHEMA_VERSION) {
      // Run all pending migrations ATOMICALLY. Several blocks contain
      // non-idempotent, destructive DDL (V4/V6 ADD COLUMN, V6 DROP TABLE users +
      // RENAME). Without a transaction, a throw partway through leaves the schema
      // half-applied while schema_v stays put, so every subsequent boot replays
      // the same non-idempotent DDL, throws, and the DO becomes permanently
      // unbootable. transactionSync rolls the whole batch back on failure, so the
      // next boot retries cleanly from the same version.
      this.storage.transactionSync(() => {
        if (currentVersion < 1) for (const stmt of DO_SCHEMA_STATEMENTS_V1) this.sql.exec(stmt);
        if (currentVersion < 2) for (const stmt of DO_SCHEMA_STATEMENTS_V2) this.sql.exec(stmt);
        if (currentVersion < 3) for (const stmt of DO_SCHEMA_STATEMENTS_V3) this.sql.exec(stmt);
        if (currentVersion < 4) for (const stmt of DO_SCHEMA_STATEMENTS_V4) this.sql.exec(stmt);
        if (currentVersion < 5) for (const stmt of DO_SCHEMA_STATEMENTS_V5) this.sql.exec(stmt);
        if (currentVersion < 6) for (const stmt of DO_SCHEMA_STATEMENTS_V6) this.sql.exec(stmt);
        if (currentVersion < 7) for (const stmt of DO_SCHEMA_STATEMENTS_V7) this.sql.exec(stmt);
        if (currentVersion < 8) for (const stmt of DO_SCHEMA_STATEMENTS_V8) this.sql.exec(stmt);
        this.setDoSchemaVersion(DO_SCHEMA_VERSION);
      });
    }
    // Content migrations (user schemas/records) — backfill template changes onto
    // already-provisioned sites. Idempotent + version-gated; wrapped atomically
    // for the same partial-replay safety as the schema migrations above.
    const contentFrom = this.getContentMigVersion();
    if (contentFrom < CONTENT_MIGRATION_VERSION) {
      this.storage.transactionSync(() => {
        runContentMigrations(this.sql, contentFrom);
        this.setContentMigVersion(CONTENT_MIGRATION_VERSION);
      });
    }
  }

  private getContentMigVersion(): number {
    try {
      const row = this.sql
        .exec<{ value: string }>(`SELECT value FROM do_meta WHERE key = 'content_mig_v'`)
        .toArray();
      return row[0] ? Number(row[0].value) : 0;
    } catch {
      return 0;
    }
  }

  private setContentMigVersion(v: number) {
    this.sql.exec(
      `INSERT INTO do_meta (key, value) VALUES ('content_mig_v', ?)
       ON CONFLICT(key) DO UPDATE SET value = excluded.value`,
      String(v),
    );
  }

  private getDoSchemaVersion(): number {
    try {
      const row = this.sql
        .exec<{ value: string }>(`SELECT value FROM do_meta WHERE key = 'schema_v'`)
        .toArray();
      return row[0] ? Number(row[0].value) : 0;
    } catch {
      return 0;
    }
  }

  private setDoSchemaVersion(v: number) {
    this.sql.exec(
      `INSERT INTO do_meta (key, value) VALUES ('schema_v', ?)
       ON CONFLICT(key) DO UPDATE SET value = excluded.value`,
      String(v),
    );
  }

  /**
   * Single-use guard for one-time tokens (e.g. magic-link sign-in). Records
   * `key` with its expiry in do_meta and returns true only the FIRST time it's
   * seen; subsequent calls return false. Runs synchronously inside the DO, so
   * two concurrent replays can't both win. Expired markers are pruned lazily.
   */
  consumeOnce(key: string, expiresAtMs: number): boolean {
    const now = Date.now();
    this.sql.exec(
      `DELETE FROM do_meta WHERE key LIKE 'once:%' AND CAST(value AS INTEGER) < ?`,
      now,
    );
    const metaKey = `once:${key}`;
    const existing = this.sql
      .exec<{ value: string }>(`SELECT value FROM do_meta WHERE key = ?`, metaKey)
      .toArray();
    if (existing.length > 0) return false;
    this.sql.exec(`INSERT INTO do_meta (key, value) VALUES (?, ?)`, metaKey, String(expiresAtMs));
    return true;
  }

  // ---- Site content version ----

  getVersion(): number {
    const rows = this.sql
      .exec<{ value: string }>(`SELECT value FROM do_meta WHERE key = 'site_v'`)
      .toArray();
    return rows[0] ? Number(rows[0].value) : 0;
  }

  private bumpVersion(): number {
    const next = this.getVersion() + 1;
    this.sql.exec(
      `INSERT INTO do_meta (key, value) VALUES ('site_v', ?)
       ON CONFLICT(key) DO UPDATE SET value = excluded.value`,
      String(next),
    );
    this._snapshotCache = null;
    return next;
  }

  // ---- Webhooks ----

  private getWebhookConfigs(): WebhookConfig[] {
    try {
      const row = this.sql
        .exec<{ value_json: string }>(`SELECT value_json FROM site_meta WHERE key = 'webhooks'`)
        .toArray();
      return row[0] ? (JSON.parse(row[0].value_json) as WebhookConfig[]) : [];
    } catch {
      return [];
    }
  }

  private fire(event: string, data: Record<string, unknown>): void {
    const configs = this.getWebhookConfigs();
    if (configs.length > 0) {
      // Fire-and-forget — don't await, don't block the operation
      fireWebhooks(configs, event, this.getSiteId(), data).catch(() => {});
    }
  }

  private getSiteId(): string {
    try {
      const row = this.sql
        .exec<{ value: string }>(`SELECT value FROM do_meta WHERE key = 'site_id'`)
        .toArray();
      return row[0]?.value ?? 'unknown';
    } catch {
      return 'unknown';
    }
  }

  // ---- Schema operations ----

  defineEntity(input: schemas.DefineEntityInput) {
    const result = schemas.defineEntity(this.sql, input);
    this.bumpVersion();
    this.fire('entity.created', { slug: input.slug, name: input.name });
    return result;
  }
  updateEntityFields(slug: string, fields: import('@pws/shared').FieldDef[]) {
    const result = schemas.updateEntityFields(this.sql, slug, fields);
    this.bumpVersion();
    return result;
  }
  /** Additive schema evolution (#47): fold `changes` into the entity's current
   *  fields — see `evolveFields` for what is refused — and write the result.
   *  Read and write happen inside the DO so two concurrent edits cannot each
   *  write back a field list missing the other's field. */
  evolveEntityFields(slug: string, changes: import('@pws/shared').FieldDef[]) {
    const current = schemas.getSchema(this.sql, slug);
    if (!current) return { ok: false as const, error: `entity '${slug}' not found` };
    const merged = evolveFields(current.fields, changes);
    if (!merged.ok) return merged;
    const schema = this.updateEntityFields(slug, merged.fields);
    return { ok: true as const, schema, added: merged.added, updated: merged.updated };
  }
  listSchemas() {
    return schemas.listSchemas(this.sql);
  }
  getSchema(slug: string) {
    return schemas.getSchema(this.sql, slug);
  }

  // ---- Record operations ----

  addRecord(input: records.AddRecordInput) {
    const result = records.addRecord(this.sql, input);
    if (result.ok) {
      this.bumpVersion();
      this.fire('record.created', { entity: input.entity_slug, id: result.record?.id });
    }
    return result;
  }
  getRecord(entitySlug: string, id: string) {
    return records.getRecord(this.sql, entitySlug, id);
  }
  getRecordById(id: string) {
    return records.getRecordById(this.sql, id);
  }
  getRecordBySlug(entitySlug: string, recordSlug: string) {
    return records.getRecordBySlug(this.sql, entitySlug, recordSlug);
  }
  listRecords(entitySlug: string, opts?: { limit?: number; offset?: number; sort?: string }) {
    return records.listRecords(this.sql, entitySlug, opts);
  }
  searchRecords(entitySlug: string, query: string, opts?: { limit?: number }) {
    return records.searchRecords(this.sql, entitySlug, query, opts);
  }
  countRecords(entitySlug: string) {
    return records.countRecords(this.sql, entitySlug);
  }
  updateRecord(entitySlug: string, id: string, data: import('@pws/shared').RecordData) {
    const result = records.updateRecord(this.sql, entitySlug, id, data);
    if (result.ok) {
      this.bumpVersion();
      this.fire('record.updated', { entity: entitySlug, id });
    }
    return result;
  }
  /**
   * Atomically claim a `status` transition on a record: read, check
   * status === from, then write { status: to, ...extra } — all in one
   * synchronous DO pass, so two concurrent callers can't both observe the
   * pre-transition state. Used to make Pending→Paid exactly-once when the Stripe
   * webhook and the order success-redirect both invoke markOrderPaid. Returns
   * whether THIS call made the transition; `rejected` distinguishes a persisted
   * write failure (worth logging) from "already transitioned by the other caller".
   */
  claimStatusTransition(
    entitySlug: string,
    id: string,
    from: string,
    to: string,
    extra?: Record<string, unknown>,
  ): { transitioned: boolean; rejected?: boolean } {
    const rec = records.getRecord(this.sql, entitySlug, id);
    if (!rec) return { transitioned: false };
    if (String(rec.data.status) !== from) return { transitioned: false };
    const nextData = {
      ...rec.data,
      status: to,
      ...(extra ?? {}),
    } as import('@pws/shared').RecordData;
    const upd = records.updateRecord(this.sql, entitySlug, id, nextData);
    if (!upd.ok) return { transitioned: false, rejected: true };
    this.bumpVersion();
    this.fire('record.updated', { entity: entitySlug, id });
    return { transitioned: true };
  }
  /**
   * Atomically reserve stock for a checkout. Runs entirely inside the DO (one
   * synchronous pass, no awaits), so the read-cap-decrement is race-free — unlike
   * doing it from the Worker across separate listRecords + updateRecord RPCs,
   * where two concurrent carts can both pass the stock check and oversell.
   *
   * For each requested line it grants `min(requested, available)`, decrements
   * tracked `stock` (and flips `in_stock:false` at zero), and returns the granted
   * quantity + the server-trusted price/name so the caller prices the order off
   * what was actually reserved. Untracked items (no numeric `stock`) grant the
   * request as-is unless `in_stock:false`.
   */
  reserveStock(
    entitySlug: string,
    requests: Array<{ id: string; qty: number }>,
  ): Array<{ id: string; granted: number; price: number; name: string }> {
    const out: Array<{ id: string; granted: number; price: number; name: string }> = [];
    let changed = false;
    for (const req of requests) {
      const rec = records.getRecord(this.sql, entitySlug, req.id);
      if (!rec) continue;
      const r = records.computeReservation(rec.data, req.qty);
      if (r.granted <= 0) continue;
      if (r.nextData) {
        // The reservation math is pure; only report `granted` if the decrement
        // actually persisted. If updateRecord rejects (e.g. schema drift makes
        // the projected record fail strict validation), report granted:0 so the
        // caller's `granted < want` oversell guard fails instead of selling
        // stock that was never reserved.
        const upd = records.updateRecord(this.sql, entitySlug, req.id, r.nextData);
        if (!upd.ok) {
          out.push({ id: req.id, granted: 0, price: r.price, name: r.name });
          continue;
        }
        changed = true;
      }
      out.push({ id: req.id, granted: r.granted, price: r.price, name: r.name });
    }
    if (changed) this.bumpVersion();
    return out;
  }

  /** Inverse of reserveStock: add quantities back (refund / cancellation). */
  releaseStock(
    entitySlug: string,
    requests: Array<{ id: string; qty: number }>,
  ): Array<{ id: string; released: number }> {
    const out: Array<{ id: string; released: number }> = [];
    let changed = false;
    for (const req of requests) {
      const rec = records.getRecord(this.sql, entitySlug, req.id);
      if (!rec) continue;
      const nextData = records.computeRelease(rec.data, req.qty);
      if (nextData) {
        // Only report `released` if the restore write persisted (same schema-drift
        // caveat as reserveStock) — otherwise a refund would log stock it never
        // put back.
        const upd = records.updateRecord(this.sql, entitySlug, req.id, nextData);
        if (!upd.ok) {
          out.push({ id: req.id, released: 0 });
          continue;
        }
        changed = true;
      }
      out.push({ id: req.id, released: Math.max(0, Math.floor(Number(req.qty) || 0)) });
    }
    if (changed) this.bumpVersion();
    return out;
  }

  getRecordByField(entitySlug: string, fieldSlug: string, value: string) {
    return records.getRecordByField(this.sql, entitySlug, fieldSlug, value);
  }
  removeRecord(entitySlug: string, id: string) {
    const result = records.removeRecord(this.sql, entitySlug, id);
    if (result.removed) {
      this.bumpVersion();
      this.fire('record.deleted', { entity: entitySlug, id });
    }
    return result;
  }

  // ---- Page operations ----

  /**
   * Bank a page into `page_revisions` and trim the history to the last 20.
   *
   * Called on the way OUT of a page — before an overwrite and before a delete —
   * because a revision is only worth writing if the live copy is about to stop
   * being the live copy. DECISIONS §14 makes reversibility the condition on
   * which "AI as sole operator" is safe, and this row is the whole of it.
   */
  private snapshotPage(page: Page, createdBy: string): void {
    try {
      this.sql.exec(
        `INSERT INTO page_revisions (page_slug, blocks_json, seo_json, title, created_by)
         VALUES (?, ?, ?, ?, ?)`,
        page.slug,
        JSON.stringify(page.blocks),
        page.seo ? JSON.stringify(page.seo) : null,
        page.title,
        createdBy,
      );
      // Keep only last 20 revisions per page
      this.sql.exec(
        `DELETE FROM page_revisions WHERE page_slug = ? AND id NOT IN (
          SELECT id FROM page_revisions WHERE page_slug = ? ORDER BY id DESC LIMIT 20
        )`,
        page.slug,
        page.slug,
      );
    } catch {
      /* revisions table may not exist on old schemas */
    }
  }

  upsertPage(input: pages.UpsertPageInput) {
    // Capture the current page BEFORE the overwrite, but only persist the
    // revision AFTER the write succeeds — otherwise a rejected edit (invalid
    // blocks/slug/title) still writes a no-op revision and can evict a real one
    // from the 20-entry history.
    const existing = pages.getPage(this.sql, input.slug);
    const result = pages.upsertPage(this.sql, input);
    if (result.ok) {
      if (existing) this.snapshotPage(existing, 'auto');
      this.bumpVersion();
      this.fire('page.updated', { slug: input.slug });
    }
    return result;
  }
  getPage(slug: string) {
    return pages.getPage(this.sql, slug);
  }
  listPages() {
    return pages.listPages(this.sql);
  }
  listPageRevisions(slug: string, limit = 10) {
    try {
      const rows = this.sql
        .exec<{
          id: number;
          page_slug: string;
          blocks_json: string;
          seo_json: string | null;
          title: string;
          created_at: string;
          created_by: string | null;
        }>(`SELECT * FROM page_revisions WHERE page_slug = ? ORDER BY id DESC LIMIT ?`, slug, limit)
        .toArray();
      return rows.map((r) => ({
        id: r.id,
        slug: r.page_slug,
        title: r.title,
        blocks: JSON.parse(r.blocks_json),
        seo: r.seo_json ? JSON.parse(r.seo_json) : null,
        created_at: r.created_at,
        created_by: r.created_by,
      }));
    } catch {
      return [];
    }
  }
  restorePageRevision(slug: string, revisionId: number) {
    const rows = this.sql
      .exec<{ blocks_json: string; seo_json: string | null; title: string }>(
        `SELECT blocks_json, seo_json, title FROM page_revisions WHERE id = ? AND page_slug = ?`,
        revisionId,
        slug,
      )
      .toArray();
    if (!rows[0]) return { ok: false as const, error: 'Revision not found' };
    // A revision of a page that no longer exists is the case that matters most:
    // `removePage` banks one on the way out, so restoring it RE-CREATES the
    // page. Refusing here (the old behaviour) made a delete permanent even
    // though its content was still sitting in the table. The revision row
    // carries title/blocks/seo; nav placement and page_type are not versioned,
    // so a re-created page comes back out of the nav for the operator to place.
    const page = pages.getPage(this.sql, slug);
    const carried = page ?? {
      slug,
      page_type: slug === '/' ? 'home' : 'page',
      show_in_nav: false,
      nav_label: null,
      nav_order: 0,
      auth_required: false,
    };
    // Route through the wrapper (not the raw pages.upsertPage) so the restore
    // bumps the site version, invalidates the snapshot cache, fires page.updated,
    // and snapshots the current version as a revision (so a restore is undoable).
    return this.upsertPage({
      ...carried,
      title: rows[0].title,
      blocks: JSON.parse(rows[0].blocks_json),
      seo: rows[0].seo_json ? JSON.parse(rows[0].seo_json) : null,
    });
  }
  removePage(slug: string) {
    // Snapshot BEFORE the delete. A delete is the only page mutation that
    // destroys the sole live copy — every other one banks the previous version
    // through upsertPage — so `remove_page` was the one hole in §14's undo, and
    // it is the hole `test-shop` fell through: its home page was deleted by a
    // misaddressed DELETE (#39) and there is nothing to restore it from.
    // `restorePageRevision` re-creates a missing page, so this row is a working
    // undo rather than an archive nobody can reach.
    const existing = pages.getPage(this.sql, slug);
    if (existing) this.snapshotPage(existing, 'auto-delete');
    const result = pages.removePage(this.sql, slug);
    // Only bump on a real delete: a miss changes nothing, so invalidating the
    // snapshot cache for it would be a lie about the site having changed.
    if (result.ok) this.bumpVersion();
    return result;
  }

  // ---- Site meta ----

  setMeta(key: 'config' | 'theme' | 'nav' | 'footer' | 'analytics' | 'webhooks', value: unknown) {
    const result = meta.setMeta(this.sql, key, value);
    if ('ok' in result && result.ok === true) this.bumpVersion();
    return result;
  }
  siteSnapshot() {
    if (!this._snapshotCache) {
      this._snapshotCache = meta.siteSnapshot(this.sql);
    }
    return this._snapshotCache;
  }

  // ---- Users ----

  async createUser(input: auth.CreateUserInput) {
    const user = await auth.createUser(this.sql, input);
    if (input.role === 'member') {
      this.fire('member.registered', { email: input.email });
    }
    return user;
  }
  listUsers() {
    return auth.listUsers(this.sql);
  }
  getUserById(id: string) {
    return auth.getUserById(this.sql, id);
  }
  getUserByEmail(email: string) {
    return auth.getUserByEmail(this.sql, email);
  }
  removeUser(id: string) {
    return auth.removeUser(this.sql, id);
  }

  // ---- Sessions ----

  async authenticate(email: string, password: string) {
    return auth.authenticate(this.sql, email, password);
  }
  async authenticateByEmail(email: string) {
    return auth.authenticateByEmail(this.sql, email);
  }
  async resolveSession(token: string) {
    return auth.resolveSession(this.sql, token);
  }
  async revokeSession(token: string) {
    return auth.revokeSession(this.sql, token);
  }
  revokeUserSessions(userId: string) {
    return auth.revokeUserSessions(this.sql, userId);
  }

  // ---- Submissions ----

  addSubmission(input: { id: string; form_id: string; data: Record<string, string>; ip?: string }) {
    return submissions.addSubmission(this.sql, input);
  }
  listSubmissions(form_id?: string, opts?: { limit?: number; offset?: number }) {
    return submissions.listSubmissions(this.sql, form_id, opts);
  }
  countSubmissions() {
    return submissions.countSubmissions(this.sql);
  }

  // ---- Template application ----

  applyTemplate(bundle: TemplateBundle): { schemas: number; records: number; pages: number } {
    // Atomic: a template lands whole or not at all. `records.addRecord`
    // inserts unconditionally (it has no upsert/skip path the way
    // `schemas.defineEntity` and `pages.upsertPage` do), so a throw part-way
    // through — a malformed bundle, a SQL error in defineEntity/upsertPage —
    // used to leave the schemas and records written before it behind. The
    // caller's only recovery is to remove the owner and retry (routes/api.ts,
    // console/routes.tsx), and that retry then duplicated every record the
    // first attempt got through. transactionSync rolls the whole apply back,
    // which is the same reason the migrations at the top of this file use it.
    //
    // Safe because this body is entirely synchronous — there is no `await` in
    // it and the method is not `async`. bumpVersion() stays INSIDE the
    // transaction so the site version does not advance for a template that did
    // not land. Issue #34.
    return this.storage.transactionSync(() => {
      let schemaCount = 0;
      let recordCount = 0;
      let pageCount = 0;

      for (const schemaDef of bundle.schemas) {
        if (schemas.getSchema(this.sql, schemaDef.slug)) continue;
        schemas.defineEntity(this.sql, {
          slug: schemaDef.slug,
          name: schemaDef.name,
          name_plural: schemaDef.name_plural,
          icon: schemaDef.icon,
          fields: schemaDef.fields,
          source_template: bundle.slug,
          public_writable: schemaDef.public_writable,
        });
        schemaCount++;
      }

      for (const [entitySlug, recordList] of Object.entries(bundle.records)) {
        for (const data of recordList) {
          const result = records.addRecord(this.sql, {
            entity_slug: entitySlug,
            data,
            created_by: `template:${bundle.slug}`,
          });
          if (result.ok) recordCount++;
        }
      }

      for (const pageDef of bundle.pages) {
        const result = pages.upsertPage(this.sql, {
          slug: pageDef.slug,
          title: pageDef.title,
          page_type: pageDef.page_type,
          blocks: pageDef.blocks,
          seo: pageDef.seo,
          show_in_nav: pageDef.show_in_nav,
          nav_label: pageDef.nav_label,
          nav_order: pageDef.nav_order,
        });
        if (result.ok) pageCount++;
      }

      if (bundle.config && Object.keys(bundle.config).length > 0) {
        meta.setMeta(this.sql, 'config', { title: 'Untitled Site', ...bundle.config });
      }
      if (bundle.theme && Object.keys(bundle.theme).length > 0) {
        meta.setMeta(this.sql, 'theme', { ...DEFAULT_THEME, ...bundle.theme });
      }
      if (bundle.nav && Object.keys(bundle.nav).length > 0) {
        meta.setMeta(this.sql, 'nav', bundle.nav);
      }
      if (bundle.footer && Object.keys(bundle.footer).length > 0) {
        meta.setMeta(this.sql, 'footer', bundle.footer);
      }

      if (bundle.admin_views) {
        for (const view of bundle.admin_views) {
          adminViews.defineAdminView(this.sql, view);
        }
      }
      if (bundle.admin_widgets) {
        for (const widget of bundle.admin_widgets) {
          adminViews.addAdminWidget(this.sql, widget);
        }
      }

      this.bumpVersion();
      return { schemas: schemaCount, records: recordCount, pages: pageCount };
    });
  }

  // ---- Admin Views ----

  defineAdminView(input: Parameters<typeof adminViews.defineAdminView>[1]) {
    return adminViews.defineAdminView(this.sql, input);
  }
  listAdminViews() {
    return adminViews.listAdminViews(this.sql);
  }
  updateAdminView(id: string, updates: Parameters<typeof adminViews.updateAdminView>[2]) {
    return adminViews.updateAdminView(this.sql, id, updates);
  }
  removeAdminView(id: string) {
    return adminViews.removeAdminView(this.sql, id);
  }
  addAdminWidget(input: Parameters<typeof adminViews.addAdminWidget>[1]) {
    return adminViews.addAdminWidget(this.sql, input);
  }
  listAdminWidgets() {
    return adminViews.listAdminWidgets(this.sql);
  }

  // ---- Translations ----

  setTranslation(locale: string, key: string, value: string, source = 'manual') {
    // Normalize + validate to the exact locale shape the URL router (/es/…) and
    // switcher handle: a 2-letter language with an optional 2-letter region. The
    // old guard accepted 3–8 letter/uppercase tags (e.g. "EN", "haw"), which then
    // appeared in hreflang and the switcher but never routed — dead locales.
    // Canonicalize case (lang lower, region upper) so "ES"/"es-br" become
    // routable "es"/"es-BR". Also blocks characters that could break out of the
    // hreflang/URL-prefix contexts.
    const m = /^([a-zA-Z]{2})(?:-([a-zA-Z]{2}))?$/.exec(locale.trim());
    if (!m) {
      return {
        ok: false as const,
        error: 'Invalid locale (expected "es" or "pt-BR")',
      };
    }
    const normalizedLocale = m[2]
      ? `${m[1]!.toLowerCase()}-${m[2].toUpperCase()}`
      : m[1]!.toLowerCase();
    // biome-ignore lint/style/noParameterAssign: canonicalize before persisting
    locale = normalizedLocale;
    try {
      this.sql.exec(
        `INSERT INTO translations (locale, key, value, source, updated_at)
         VALUES (?, ?, ?, ?, datetime('now'))
         ON CONFLICT (locale, key) DO UPDATE SET value = excluded.value, source = excluded.source, updated_at = datetime('now')`,
        locale,
        key,
        value,
        source,
      );
      this.bumpVersion();
      return { ok: true as const };
    } catch {
      return { ok: false as const, error: 'Failed to save translation' };
    }
  }

  deleteTranslation(locale: string, key: string) {
    this.sql.exec(`DELETE FROM translations WHERE locale = ? AND key = ?`, locale, key);
    this.bumpVersion(); // parity with setTranslation — keep version-keyed freshness correct
    return { ok: true as const };
  }

  getTranslations(locale: string): Record<string, string> {
    try {
      const rows = this.sql
        .exec<{ key: string; value: string }>(
          `SELECT key, value FROM translations WHERE locale = ?`,
          locale,
        )
        .toArray();
      const map: Record<string, string> = {};
      for (const r of rows) map[r.key] = r.value;
      return map;
    } catch {
      return {};
    }
  }

  listTranslationLocales(): Array<{ locale: string; count: number }> {
    try {
      return this.sql
        .exec<{ locale: string; count: number }>(
          `SELECT locale, COUNT(*) as count FROM translations GROUP BY locale ORDER BY locale`,
        )
        .toArray();
    } catch {
      return [];
    }
  }

  listTranslationKeys(
    locale: string,
  ): Array<{ key: string; value: string; source: string; updated_at: string }> {
    try {
      return this.sql
        .exec<{ key: string; value: string; source: string; updated_at: string }>(
          `SELECT key, value, source, updated_at FROM translations WHERE locale = ? ORDER BY key`,
          locale,
        )
        .toArray();
    } catch {
      return [];
    }
  }

  // ---- Diagnostics ----

  diagnostics() {
    const e = this.sql.exec<{ c: number }>(`SELECT COUNT(*) as c FROM schemas`).toArray();
    const r = this.sql
      .exec<{ c: number }>(`SELECT COUNT(*) as c FROM records WHERE status = 'live'`)
      .toArray();
    const p = this.sql.exec<{ c: number }>(`SELECT COUNT(*) as c FROM pages`).toArray();
    const u = this.sql.exec<{ c: number }>(`SELECT COUNT(*) as c FROM users`).toArray();
    return {
      schema_v: this.getDoSchemaVersion(),
      site_v: this.getVersion(),
      entities: e[0]?.c ?? 0,
      records: r[0]?.c ?? 0,
      pages: p[0]?.c ?? 0,
      users: u[0]?.c ?? 0,
    };
  }
}
