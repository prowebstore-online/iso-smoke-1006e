// Schema operations extracted from SiteDO.

import type { EntitySchema, FieldDef } from '@pws/shared';
import { validatorForFields } from '@pws/shared';

interface SchemaRow extends Record<string, SqlStorageValue> {
  slug: string;
  name: string;
  name_plural: string;
  icon: string | null;
  fields_json: string;
  source_template: string | null;
  version: number;
  system_managed: number;
  public_writable: number;
  created_at: string;
  updated_at: string;
}

export interface DefineEntityInput {
  slug: string;
  name: string;
  name_plural: string;
  icon?: string;
  fields: FieldDef[];
  source_template?: string;
  system_managed?: boolean;
  public_writable?: boolean;
}

export function defineEntity(sql: SqlStorage, input: DefineEntityInput): EntitySchema {
  if (!/^[a-z][a-z0-9_]*$/.test(input.slug)) {
    throw new Error(`invalid entity slug '${input.slug}': use lowercase, digits, underscore`);
  }
  // Validate the field definitions at definition time. validatorForFields throws
  // for structurally-invalid fields (e.g. a select/multiselect with no options).
  // Without this, such a field is stored fine but then EVERY add_record/
  // update_record throws when it rebuilds the validator — the entity is silently
  // write-dead.
  validatorForFields(input.fields);
  const fieldsJson = JSON.stringify(input.fields);
  sql.exec(
    `INSERT INTO schemas (slug, name, name_plural, icon, fields_json, source_template, system_managed, public_writable)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    input.slug,
    input.name,
    input.name_plural,
    input.icon ?? null,
    fieldsJson,
    input.source_template ?? null,
    input.system_managed ? 1 : 0,
    input.public_writable ? 1 : 0,
  );
  return requireSchema(sql, input.slug);
}

/**
 * Replace an existing entity's field definitions (and bump its version). Used
 * for schema evolution — e.g. adding a new `select` option that newer templates
 * have but an older provisioned site is missing. Throws if the entity doesn't
 * exist. Existing records are not touched; they validate lazily on next write.
 */
export function updateEntityFields(
  sql: SqlStorage,
  slug: string,
  fields: FieldDef[],
): EntitySchema {
  requireSchema(sql, slug); // throws if the entity doesn't exist
  validatorForFields(fields); // same guard as defineEntity: a bad field makes the entity write-dead
  sql.exec(
    `UPDATE schemas SET fields_json = ?, version = version + 1, updated_at = datetime('now')
     WHERE slug = ?`,
    JSON.stringify(fields),
    slug,
  );
  return requireSchema(sql, slug);
}

export function listSchemas(sql: SqlStorage): EntitySchema[] {
  const rows = sql.exec<SchemaRow>(`SELECT * FROM schemas ORDER BY slug`).toArray();
  return rows.map(rowToSchema);
}

export function getSchema(sql: SqlStorage, slug: string): EntitySchema | null {
  const rows = sql.exec<SchemaRow>(`SELECT * FROM schemas WHERE slug = ?`, slug).toArray();
  return rows[0] ? rowToSchema(rows[0]) : null;
}

export function requireSchema(sql: SqlStorage, slug: string): EntitySchema {
  const s = getSchema(sql, slug);
  if (!s) throw new Error(`entity '${slug}' not found`);
  return s;
}

function rowToSchema(row: SchemaRow): EntitySchema {
  return {
    slug: row.slug,
    name: row.name,
    name_plural: row.name_plural,
    icon: row.icon,
    fields: JSON.parse(row.fields_json) as FieldDef[],
    source_template: row.source_template,
    version: row.version,
    system_managed: row.system_managed === 1,
    public_writable: row.public_writable === 1,
    created_at: row.created_at,
    updated_at: row.updated_at,
  };
}
