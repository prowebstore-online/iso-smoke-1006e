// Record operations extracted from SiteDO.

import type { EntityRecord, FieldDef, RecordData } from '@pws/shared';
import { projectRecord, validateRecord } from '@pws/shared';
import { getSchema, requireSchema } from './schemas.ts';

interface RecordRow extends Record<string, SqlStorageValue> {
  id: string;
  entity_slug: string;
  slug: string | null;
  data_json: string;
  search_text: string | null;
  schema_version: number;
  status: string;
  created_at: string;
  updated_at: string;
  created_by: string | null;
}

/**
 * Pure per-line stock reservation decision for a checkout. Given a sellable
 * record's data and a requested quantity, returns the granted quantity, the
 * server-trusted price/name, and the `nextData` to persist (decremented stock,
 * `in_stock:false` at zero) — or `nextData: null` when there's nothing to write
 * (untracked item, or none granted). Caller persists `nextData` atomically.
 *
 * Availability: numeric `stock` caps the qty; `in_stock:false` blocks; otherwise
 * unlimited. Requested qty is clamped to 1..99.
 */
export function computeReservation(
  data: RecordData,
  requestedQty: number,
): { granted: number; price: number; name: string; nextData: RecordData | null } {
  const price = Math.max(0, Math.round(Number(data.price) || 0));
  const name = String(data.name ?? 'Item');
  const tracked = typeof data.stock === 'number';
  const available = tracked
    ? Math.max(0, Math.floor(Number(data.stock)))
    : data.in_stock === false
      ? 0
      : Number.POSITIVE_INFINITY;
  if (available <= 0) return { granted: 0, price, name, nextData: null };

  const requested = Math.max(1, Math.min(99, Math.floor(Number(requestedQty) || 1)));
  const granted = Math.min(requested, available);
  if (granted <= 0) return { granted: 0, price, name, nextData: null };

  let nextData: RecordData | null = null;
  if (tracked) {
    const remaining = available - granted;
    nextData = { ...data, stock: remaining };
    if (remaining === 0 && 'in_stock' in data) nextData.in_stock = false;
  }
  return { granted, price, name, nextData };
}

/**
 * Inverse of computeReservation: add `qty` back to a record's stock (refund /
 * cancellation). Returns the next data, or null when nothing changes. Numeric
 * `stock` is incremented (and `in_stock` flipped back true if it was a tracked
 * sell-out); a record with only a boolean `in_stock:false` is flipped true;
 * untracked/unlimited records need no restore.
 */
export function computeRelease(data: RecordData, qty: number): RecordData | null {
  if (typeof data.stock === 'number') {
    const add = Math.max(0, Math.floor(Number(qty) || 0));
    if (add === 0) return null;
    const next = Math.max(0, Math.floor(Number(data.stock) || 0)) + add;
    const nextData: RecordData = { ...data, stock: next };
    if (next > 0 && 'in_stock' in data) nextData.in_stock = true;
    return nextData;
  }
  if (data.in_stock === false) return { ...data, in_stock: true };
  return null;
}

/** Find the first record of an entity whose JSON field equals `value`, in ANY
 *  status. Used to match a Stripe refund (carries payment_intent, not order_id)
 *  back to its order via `payment_ref` — an archived order must still be
 *  matchable so it can be refunded, so this intentionally does not filter by
 *  status = 'live'. */
export function getRecordByField(
  sql: SqlStorage,
  entitySlug: string,
  fieldSlug: string,
  value: string,
): EntityRecord | null {
  const schema = getSchema(sql, entitySlug);
  if (!schema) return null;
  const rows = sql
    .exec<RecordRow>(
      `SELECT * FROM records WHERE entity_slug = ? AND json_extract(data_json, '$.' || ?) = ? LIMIT 1`,
      entitySlug,
      fieldSlug,
      value,
    )
    .toArray();
  return rows[0] ? rowToRecord(rows[0], schema.fields) : null;
}

export interface AddRecordInput {
  entity_slug: string;
  data: RecordData;
  slug?: string;
  created_by?: string;
}

export interface AddRecordResult {
  ok: true;
  record: EntityRecord;
}

export interface ValidationFailure {
  ok: false;
  errors: Array<{ path: string; message: string; code: string }>;
}

export function addRecord(
  sql: SqlStorage,
  input: AddRecordInput,
): AddRecordResult | ValidationFailure {
  const schema = requireSchema(sql, input.entity_slug);
  const validation = validateRecord(schema.fields, input.data);
  if (!validation.ok) {
    return { ok: false, errors: validation.errors };
  }

  const id = crypto.randomUUID();
  let desiredSlug = input.slug ?? deriveSlug(validation.data);
  // Non-ASCII titles (e.g. Chinese) kebab to an empty string. A titled record
  // should still get a detail-page slug, so fall back to a short id-based one.
  if (!desiredSlug && hasTitleField(validation.data)) desiredSlug = `item-${id.slice(0, 8)}`;
  const slug = desiredSlug ? uniqueSlug(sql, input.entity_slug, desiredSlug) : null;
  const dataJson = JSON.stringify(validation.data);
  const searchText = buildSearchText(validation.data);

  try {
    sql.exec(
      `INSERT INTO records
        (id, entity_slug, slug, data_json, search_text, schema_version, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      id,
      input.entity_slug,
      slug,
      dataJson,
      searchText,
      schema.version,
      input.created_by ?? null,
    );
  } catch (err) {
    const msg = (err as Error).message;
    if (/UNIQUE|constraint/i.test(msg)) {
      return {
        ok: false,
        errors: [
          {
            path: 'slug',
            message: `Could not generate a unique slug for '${desiredSlug}'. Provide an explicit slug.`,
            code: 'unique_violation',
          },
        ],
      };
    }
    throw err;
  }

  updateRefs(sql, input.entity_slug, id, schema.fields, validation.data);

  const record = getRecord(sql, input.entity_slug, id);
  if (!record) throw new Error('record not found after insert');
  return { ok: true, record };
}

export function getRecord(sql: SqlStorage, entitySlug: string, id: string): EntityRecord | null {
  const rows = sql
    .exec<RecordRow>(`SELECT * FROM records WHERE entity_slug = ? AND id = ?`, entitySlug, id)
    .toArray();
  if (!rows[0]) return null;
  const schema = getSchema(sql, entitySlug);
  if (!schema) return null;
  return rowToRecord(rows[0], schema.fields);
}

/** Look up a record by ID without knowing the entity slug. Used by checkout price verification. */
export function getRecordById(sql: SqlStorage, id: string): EntityRecord | null {
  const rows = sql.exec<RecordRow>(`SELECT * FROM records WHERE id = ?`, id).toArray();
  if (!rows[0]) return null;
  const schema = getSchema(sql, rows[0].entity_slug);
  if (!schema) return null;
  return rowToRecord(rows[0], schema.fields);
}

/** Look up a record by entity slug + record slug. Used by entity detail pages. */
export function getRecordBySlug(
  sql: SqlStorage,
  entitySlug: string,
  recordSlug: string,
): EntityRecord | null {
  const schema = getSchema(sql, entitySlug);
  if (!schema) return null;
  const rows = sql
    .exec<RecordRow>(
      `SELECT * FROM records WHERE entity_slug = ? AND slug = ? AND status = 'live'`,
      entitySlug,
      recordSlug,
    )
    .toArray();
  if (!rows[0]) return null;
  return rowToRecord(rows[0], schema.fields);
}

export function listRecords(
  sql: SqlStorage,
  entitySlug: string,
  opts?: { limit?: number; offset?: number; sort?: string },
): EntityRecord[] {
  const schema = getSchema(sql, entitySlug);
  if (!schema) return [];
  const limit = Math.min(opts?.limit ?? 100, 500);
  const offset = opts?.offset ?? 0;
  const orderBy =
    opts?.sort === 'created_at'
      ? 'created_at DESC'
      : opts?.sort === 'name'
        ? "json_extract(data_json, '$.name') ASC"
        : 'updated_at DESC';
  const rows = sql
    .exec<RecordRow>(
      `SELECT * FROM records WHERE entity_slug = ? AND status = 'live'
       ORDER BY ${orderBy} LIMIT ? OFFSET ?`,
      entitySlug,
      limit,
      offset,
    )
    .toArray();
  return rows.map((r) => rowToRecord(r, schema.fields));
}

export function searchRecords(
  sql: SqlStorage,
  entitySlug: string,
  query: string,
  opts?: { limit?: number },
): EntityRecord[] {
  const schema = getSchema(sql, entitySlug);
  if (!schema) return [];
  const limit = Math.min(Math.max(opts?.limit ?? 50, 1), 500);
  const escaped = query.replace(/[%_\\]/g, '\\$&');
  const rows = sql
    .exec<RecordRow>(
      `SELECT * FROM records WHERE entity_slug = ? AND status = 'live'
       AND search_text LIKE ? ESCAPE '\\' ORDER BY updated_at DESC LIMIT ?`,
      entitySlug,
      `%${escaped}%`,
      limit,
    )
    .toArray();
  return rows.map((r) => rowToRecord(r, schema.fields));
}

export function countRecords(sql: SqlStorage, entitySlug: string): number {
  const rows = sql
    .exec<{ c: number }>(
      `SELECT COUNT(*) as c FROM records WHERE entity_slug = ? AND status = 'live'`,
      entitySlug,
    )
    .toArray();
  return rows[0]?.c ?? 0;
}

export function updateRecord(
  sql: SqlStorage,
  entitySlug: string,
  id: string,
  data: RecordData,
): AddRecordResult | ValidationFailure {
  const schema = requireSchema(sql, entitySlug);
  const validation = validateRecord(schema.fields, data);
  if (!validation.ok) return { ok: false, errors: validation.errors };

  const existing = getRecord(sql, entitySlug, id);
  if (!existing) {
    return {
      ok: false,
      errors: [{ path: 'id', message: 'Record not found', code: 'not_found' }],
    };
  }

  const dataJson = JSON.stringify(validation.data);
  const searchText = buildSearchText(validation.data);
  sql.exec(
    `UPDATE records SET data_json = ?, search_text = ?, schema_version = ?, updated_at = datetime('now')
     WHERE entity_slug = ? AND id = ?`,
    dataJson,
    searchText,
    schema.version,
    entitySlug,
    id,
  );
  updateRefs(sql, entitySlug, id, schema.fields, validation.data);

  const record = getRecord(sql, entitySlug, id);
  if (!record) throw new Error('record not found after update');
  return { ok: true, record };
}

export function removeRecord(
  sql: SqlStorage,
  entitySlug: string,
  id: string,
): { ok: boolean; removed: boolean } {
  const before = sql
    .exec<{ c: number }>(
      `SELECT COUNT(*) as c FROM records WHERE entity_slug = ? AND id = ?`,
      entitySlug,
      id,
    )
    .toArray();
  if ((before[0]?.c ?? 0) === 0) return { ok: true, removed: false };
  sql.exec(`DELETE FROM records WHERE entity_slug = ? AND id = ?`, entitySlug, id);
  sql.exec(`DELETE FROM refs WHERE source_entity = ? AND source_id = ?`, entitySlug, id);
  // Also drop INBOUND refs — other records pointing at this one — otherwise they
  // dangle and the reference graph keeps joining to a deleted target.
  sql.exec(`DELETE FROM refs WHERE target_entity = ? AND target_id = ?`, entitySlug, id);
  return { ok: true, removed: true };
}

// ---- Reference graph maintenance ----

function updateRefs(
  sql: SqlStorage,
  sourceEntity: string,
  sourceId: string,
  fields: FieldDef[],
  data: RecordData,
) {
  sql.exec(`DELETE FROM refs WHERE source_entity = ? AND source_id = ?`, sourceEntity, sourceId);
  for (const field of fields) {
    const targetEntity = field.reference_to;
    if (!targetEntity) continue;
    const value = data[field.slug];
    const targets =
      field.type === 'reference' && typeof value === 'string'
        ? [value]
        : field.type === 'reference_list' && Array.isArray(value)
          ? value.filter((v): v is string => typeof v === 'string')
          : [];
    for (const targetId of targets) {
      sql.exec(
        `INSERT OR IGNORE INTO refs
          (source_entity, source_id, source_field, target_entity, target_id)
         VALUES (?, ?, ?, ?, ?)`,
        sourceEntity,
        sourceId,
        field.slug,
        targetEntity,
        targetId,
      );
    }
  }
}

// ---- Helpers ----

function rowToRecord(row: RecordRow, currentFields: FieldDef[]): EntityRecord {
  const storedData = JSON.parse(row.data_json) as RecordData;
  const projected = projectRecord(storedData, currentFields);
  return {
    id: row.id,
    entity_slug: row.entity_slug,
    slug: row.slug,
    data: projected,
    schema_version: row.schema_version,
    status: row.status === 'archived' ? 'archived' : 'live',
    created_at: row.created_at,
    updated_at: row.updated_at,
    created_by: row.created_by,
  };
}

function uniqueSlug(sql: SqlStorage, entitySlug: string, desired: string): string {
  let candidate = desired;
  for (let i = 2; i <= 50; i++) {
    const rows = sql
      .exec<{ id: string }>(
        `SELECT id FROM records WHERE entity_slug = ? AND slug = ? LIMIT 1`,
        entitySlug,
        candidate,
      )
      .toArray();
    if (rows.length === 0) return candidate;
    candidate = `${desired}-${i}`;
  }
  return `${desired}-${crypto.randomUUID().slice(0, 8)}`;
}

export function deriveSlug(data: RecordData): string | null {
  for (const key of ['slug', 'name', 'title']) {
    const v = data[key];
    if (typeof v === 'string' && v.trim().length > 0) {
      const k = kebab(v);
      if (k) return k;
    }
  }
  return null;
}

function hasTitleField(data: RecordData): boolean {
  return ['slug', 'name', 'title'].some(
    (k) => typeof data[k] === 'string' && (data[k] as string).trim().length > 0,
  );
}

function kebab(s: string): string {
  return s
    .toLowerCase()
    .normalize('NFKD')
    .replace(/\p{M}/gu, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80);
}

function buildSearchText(data: RecordData): string {
  const parts: string[] = [];
  for (const v of Object.values(data)) {
    if (typeof v === 'string') parts.push(v);
    else if (typeof v === 'number' || typeof v === 'boolean') parts.push(String(v));
  }
  return parts.join(' ').slice(0, 4000);
}
