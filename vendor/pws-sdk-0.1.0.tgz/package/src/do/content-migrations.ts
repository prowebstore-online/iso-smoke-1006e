// Per-site CONTENT migrations — schema/record fixups that bring a site's
// applied template up to date with newer template definitions.
//
// Distinct from the structural DO migrations in sql.ts (DO_SCHEMA_VERSION):
// those create/alter the DO's own tables; these operate on the *user* schemas
// and records inside a site (e.g. adding a select option a newer template has).
// They exist because `defineEntity` is insert-only, so a template change never
// reaches sites that were provisioned earlier.
//
// Pattern mirrors bootstrap(): an ordered, append-only list of idempotent
// migrations; the index+1 is the version, tracked in do_meta('content_mig_v').
// Each migration must be defensive — a no-op on sites where the target entity
// doesn't exist (e.g. a non-commerce site has no `order`).

import type { FieldDef } from '@pws/shared';
import * as schemas from './schemas.ts';

/**
 * Pure: return a new `fields` array with `needed` options appended to the named
 * select/multiselect field, or `null` if nothing needs to change (field absent,
 * not a select, or already has every option). Kept pure so it's unit-testable
 * without a SqlStorage harness.
 */
export function addSelectOptions(
  fields: FieldDef[],
  fieldSlug: string,
  needed: string[],
): FieldDef[] | null {
  const field = fields.find((f) => f.slug === fieldSlug);
  if (!field || (field.type !== 'select' && field.type !== 'multiselect')) return null;
  if (!Array.isArray(field.options)) return null;
  const missing = needed.filter((o) => !field.options?.includes(o));
  if (missing.length === 0) return null;
  return fields.map((f) =>
    f.slug === fieldSlug ? { ...f, options: [...(f.options ?? []), ...missing] } : f,
  );
}

/** Idempotently add missing select options on an entity; no-op if absent. */
function ensureSelectOptions(
  sql: SqlStorage,
  entitySlug: string,
  fieldSlug: string,
  needed: string[],
): void {
  const schema = schemas.getSchema(sql, entitySlug);
  if (!schema) return;
  const fields = addSelectOptions(schema.fields, fieldSlug, needed);
  if (fields) schemas.updateEntityFields(sql, entitySlug, fields);
}

// Append-only. Never reorder or delete an entry (the array index is the version).
const CONTENT_MIGRATIONS: Array<(sql: SqlStorage) => void> = [
  // v1: the Stripe storefront checkout creates 'Pending' orders that the webhook
  // flips to 'Paid'. Sites provisioned before those statuses existed have an
  // `order.status` select missing them, which made updateRecord reject the
  // paid-order write. Backfill the options.
  (sql) => ensureSelectOptions(sql, 'order', 'status', ['Pending', 'Paid']),
  // v2: the rest of the order lifecycle — checkout-failure 'Cancelled' and the
  // refund webhook's 'Refunded' (plus 'Fulfilled'/'Paid (test)') were likewise
  // missing on older order schemas, so those status writes were rejected too.
  (sql) =>
    ensureSelectOptions(sql, 'order', 'status', [
      'Paid (test)',
      'Fulfilled',
      'Cancelled',
      'Refunded',
    ]),
];

export const CONTENT_MIGRATION_VERSION = CONTENT_MIGRATIONS.length;

/** Run every content migration newer than `from`; returns the new version. */
export function runContentMigrations(sql: SqlStorage, from: number): number {
  for (let v = from; v < CONTENT_MIGRATIONS.length; v++) {
    CONTENT_MIGRATIONS[v]?.(sql);
  }
  return CONTENT_MIGRATION_VERSION;
}
