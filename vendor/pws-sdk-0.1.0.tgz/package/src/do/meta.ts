// Site meta operations extracted from SiteDO.

import type { AnalyticsConfig, FooterConfig, NavConfig, SiteConfig, Theme } from '@pws/shared';
import { DEFAULT_THEME, validateMeta } from '@pws/shared';
import { listNavPages } from './pages.ts';

interface MetaRow extends Record<string, SqlStorageValue> {
  key: string;
  value_json: string;
  updated_at: string;
}

export interface ValidationFailure {
  ok: false;
  errors: Array<{ path: string; message: string; code: string }>;
}

export interface SiteSnapshot {
  config: SiteConfig;
  theme: Theme;
  nav: NavConfig;
  footer: FooterConfig;
  analytics: AnalyticsConfig;
  pages: import('@pws/shared').NavPage[];
}

export function setMeta(
  sql: SqlStorage,
  key: 'config' | 'theme' | 'nav' | 'footer' | 'analytics' | 'webhooks',
  value: unknown,
): { ok: true } | ValidationFailure {
  const result = validateMeta(key, value);
  if (!result.ok) return { ok: false, errors: result.errors };
  sql.exec(
    `INSERT INTO site_meta (key, value_json) VALUES (?, ?)
     ON CONFLICT(key) DO UPDATE SET value_json = excluded.value_json,
       updated_at = datetime('now')`,
    key,
    JSON.stringify(result.value),
  );
  return { ok: true };
}

export function getMeta<T>(sql: SqlStorage, key: string): T | null {
  const rows = sql.exec<MetaRow>(`SELECT * FROM site_meta WHERE key = ?`, key).toArray();
  if (!rows[0]) return null;
  return JSON.parse(rows[0].value_json) as T;
}

export function siteSnapshot(sql: SqlStorage): SiteSnapshot {
  return {
    config: getMeta<SiteConfig>(sql, 'config') ?? { title: 'Untitled Site' },
    theme: getMeta<Theme>(sql, 'theme') ?? DEFAULT_THEME,
    nav: getMeta<NavConfig>(sql, 'nav') ?? {},
    footer: getMeta<FooterConfig>(sql, 'footer') ?? {},
    analytics: getMeta<AnalyticsConfig>(sql, 'analytics') ?? {},
    pages: listNavPages(sql),
  };
}
