// SessionDO: per-conversation state.
// One DO instance per session_id. Holds the message array (user + assistant
// turns including tool_use / tool_result blocks) so conversations persist
// across HTTP requests.
//
// Message content is stored as JSON-stringified Anthropic ContentBlock arrays
// (or strings for plain user turns). The Anthropic SDK can replay them as-is.

import { DurableObject } from 'cloudflare:workers';
import type { MessageParam } from '@anthropic-ai/sdk/resources/messages';

interface MessageRow extends Record<string, SqlStorageValue> {
  idx: number;
  role: string;
  content_json: string;
  created_at: string;
}

const MAX_MESSAGES = 500;

export interface SessionStats {
  message_count: number;
  created_at: string | null;
  updated_at: string | null;
}

export class SessionDO extends DurableObject {
  private sql: SqlStorage;
  private bootstrapped = false;

  constructor(state: DurableObjectState, env: never) {
    super(state, env);
    this.sql = state.storage.sql;
    this.bootstrap();
  }

  private bootstrap() {
    if (this.bootstrapped) return;
    this.sql.exec(`
      CREATE TABLE IF NOT EXISTS messages (
        idx INTEGER PRIMARY KEY AUTOINCREMENT,
        role TEXT NOT NULL,
        content_json TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      )
    `);
    this.bootstrapped = true;
  }

  /** Replace all messages (use after explicit reset; otherwise prefer append). */
  setMessages(messages: MessageParam[]): { ok: true; count: number } {
    // Cap at MAX_MESSAGES — keep the most recent if over limit.
    const capped = messages.length > MAX_MESSAGES ? messages.slice(-MAX_MESSAGES) : messages;
    this.sql.exec(`DELETE FROM messages`);
    for (const m of capped) {
      this.sql.exec(
        `INSERT INTO messages (role, content_json) VALUES (?, ?)`,
        m.role,
        JSON.stringify(m.content),
      );
    }
    return { ok: true, count: capped.length };
  }

  /** Append messages to the end of the conversation. */
  appendMessages(messages: MessageParam[]): { ok: true; appended: number; total: number } {
    let appended = 0;
    for (const m of messages) {
      this.sql.exec(
        `INSERT INTO messages (role, content_json) VALUES (?, ?)`,
        m.role,
        JSON.stringify(m.content),
      );
      appended++;
    }
    const total = this.countMessages();
    if (total > MAX_MESSAGES) {
      // Trim oldest to keep within budget.
      const excess = total - MAX_MESSAGES;
      this.sql.exec(
        `DELETE FROM messages WHERE idx IN (SELECT idx FROM messages ORDER BY idx ASC LIMIT ?)`,
        excess,
      );
    }
    return { ok: true, appended, total: this.countMessages() };
  }

  /** Return the full message array in chronological order. */
  getMessages(): MessageParam[] {
    const rows = this.sql
      .exec<MessageRow>(`SELECT idx, role, content_json, created_at FROM messages ORDER BY idx ASC`)
      .toArray();
    return rows.map((r) => ({
      role: r.role as MessageParam['role'],
      content: JSON.parse(r.content_json) as MessageParam['content'],
    }));
  }

  /** Wipe conversation. Returns the count that was wiped. */
  reset(): { ok: true; cleared: number } {
    const before = this.countMessages();
    this.sql.exec(`DELETE FROM messages`);
    return { ok: true, cleared: before };
  }

  stats(): SessionStats {
    const count = this.countMessages();
    const range = this.sql
      .exec<{ first: string | null; last: string | null }>(
        `SELECT MIN(created_at) as first, MAX(created_at) as last FROM messages`,
      )
      .toArray();
    return {
      message_count: count,
      created_at: range[0]?.first ?? null,
      updated_at: range[0]?.last ?? null,
    };
  }

  private countMessages(): number {
    const rows = this.sql.exec<{ c: number }>(`SELECT COUNT(*) as c FROM messages`).toArray();
    return rows[0]?.c ?? 0;
  }
}
