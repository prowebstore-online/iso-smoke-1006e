// Build a compact digest of the current site state for the AI system prompt.
// Goal: small token footprint, cache-friendly (changes only when site state changes).

import type { SiteRpc } from '../do/rpc.ts';

export async function buildSiteDigest(rpc: SiteRpc): Promise<string> {
  const [schemas, pages, snap] = await Promise.all([
    rpc.listSchemas(),
    rpc.listPages(),
    rpc.siteSnapshot(),
  ]);

  const entityLines = await Promise.all(
    schemas.map(async (s) => {
      const c = await rpc.countRecords(s.slug);
      const fields = s.fields.map((f) => `${f.slug}:${f.type}${f.required ? '*' : ''}`).join(', ');
      return `  ${s.slug}${s.icon ? ` ${s.icon}` : ''} (${c} record${c === 1 ? '' : 's'}, v${s.version}): ${fields}`;
    }),
  );

  const pageLines = pages.map(
    (p) =>
      `  ${p.slug}  "${p.title}"  type:${p.page_type}  blocks:${p.blocks.length}  nav:${p.show_in_nav ? `yes(order ${p.nav_order})` : 'no'}`,
  );

  const theme = snap.theme;
  const themeLine =
    `colors: primary=${theme.colors.primary} bg=${theme.colors.background} text=${theme.colors.text}` +
    `  fonts: ${theme.fonts.heading} / ${theme.fonts.body}` +
    `  radius:${theme.radius ?? 'md'} shadow:${theme.shadow ?? 'sm'} spacing:${theme.spacing ?? 'normal'}`;

  return [
    `# Site: ${snap.config.title}`,
    snap.config.description ? `Description: ${snap.config.description}` : null,
    '',
    '## Entity types (* = required field)',
    entityLines.length ? entityLines.join('\n') : '  (none defined yet)',
    '',
    '## Pages',
    pageLines.length ? pageLines.join('\n') : '  (no pages yet)',
    '',
    '## Theme',
    `  ${themeLine}`,
  ]
    .filter((l): l is string => l !== null)
    .join('\n');
}
