// Agent loop: orchestrates Anthropic message exchange + tool execution.
// Runs in-memory for one HTTP request. Conversation persistence (SessionDO),
// streaming (SSE), and cost-aware routing land in the next iteration.

import type {
  ContentBlock,
  MessageParam,
  ToolResultBlockParam,
  ToolUseBlock,
} from '@anthropic-ai/sdk/resources/messages';
import type { SiteRpc } from '../do/rpc.ts';
import type { Env } from '../env.ts';
import { makeAnthropic, pickModel } from './anthropic.ts';
import { buildSiteDigest } from './digest.ts';
import { buildSystemPrompt } from './system-prompt.ts';
import { TOOLS, dispatchTool } from './tools.ts';

const MAX_ITERATIONS = 25;
const MAX_TOKENS = 4096;

export interface AgentRunInput {
  env: Env;
  rpc: SiteRpc;
  siteId: string;
  messages: MessageParam[];
}

export interface AgentToolCall {
  iteration: number;
  name: string;
  input: Record<string, unknown>;
  ok: boolean;
  preview: string; // first ~200 chars of tool output
}

export interface AgentRunResult {
  messages: MessageParam[];
  assistantText: string;
  iterations: number;
  toolCalls: AgentToolCall[];
  stopReason: string | null;
  usage: { input_tokens: number; output_tokens: number };
  model: string;
}

export async function runAgent({
  env,
  rpc,
  siteId,
  messages,
}: AgentRunInput): Promise<AgentRunResult> {
  const client = makeAnthropic(env);
  const model = pickModel(env);
  const digest = await buildSiteDigest(rpc);
  const system = buildSystemPrompt(digest);

  const log: AgentToolCall[] = [];
  const usage = { input_tokens: 0, output_tokens: 0 };
  const accMessages: MessageParam[] = [...messages];
  let stopReason: string | null = null;
  let iterations = 0;
  let exhausted = false;

  for (let i = 0; i < MAX_ITERATIONS; i++) {
    iterations = i + 1;
    const response = await client.messages.create({
      model,
      max_tokens: MAX_TOKENS,
      system,
      tools: TOOLS,
      messages: accMessages,
    });

    usage.input_tokens += response.usage.input_tokens;
    usage.output_tokens += response.usage.output_tokens;
    stopReason = response.stop_reason;

    // Append the assistant's full content (text + any tool_use) to the conversation.
    accMessages.push({ role: 'assistant', content: response.content });

    if (response.stop_reason !== 'tool_use') break;

    const toolUses = response.content.filter((c): c is ToolUseBlock => c.type === 'tool_use');
    if (toolUses.length === 0) break;

    const toolResults: ToolResultBlockParam[] = [];
    for (const use of toolUses) {
      const result = await dispatchTool(use.name, use.input as Record<string, unknown>, rpc, {
        env,
        siteId,
      });
      const text = result.ok ? (result.result ?? 'OK') : `ERROR: ${result.error}`;
      log.push({
        iteration: i,
        name: use.name,
        input: use.input as Record<string, unknown>,
        ok: result.ok,
        preview: text.slice(0, 200),
      });
      toolResults.push({
        type: 'tool_result',
        tool_use_id: use.id,
        content: text,
        is_error: !result.ok,
      });
    }
    accMessages.push({ role: 'user', content: toolResults });

    if (i === MAX_ITERATIONS - 1) {
      exhausted = true;
    }
  }

  // If the run ended on a non-tool_use stop (e.g. max_tokens truncated the turn
  // mid-tool_use), the last assistant message can carry a tool_use block with no
  // following tool_result. Persisting that permanently 400s the session, so strip
  // any dangling tool_use before returning/persisting.
  stripDanglingToolUse(accMessages);

  // Find the most recent assistant message and extract its text. Falls back
  // through the conversation in case the loop ended on a tool_result message.
  const assistantText = extractLatestAssistantText(accMessages);

  return {
    messages: accMessages,
    assistantText:
      assistantText ||
      (exhausted ? `(stopped after ${MAX_ITERATIONS} iterations without a final answer)` : ''),
    iterations,
    toolCalls: log,
    stopReason,
    usage,
    model,
  };
}

/** Remove tool_use blocks from the final assistant message when they have no
 *  matching tool_result. The agent loop only leaves such a message when it
 *  stopped for a non-tool_use reason (e.g. max_tokens truncated the turn
 *  mid-tool_use); persisting an unanswered tool_use makes the next Anthropic
 *  call 400 and permanently breaks the session. */
export function stripDanglingToolUse(messages: MessageParam[]): void {
  const last = messages[messages.length - 1];
  if (!last || last.role !== 'assistant' || !Array.isArray(last.content)) return;
  const content = last.content as ContentBlock[];
  if (!content.some((c) => c.type === 'tool_use')) return;
  const kept = content.filter((c) => c.type !== 'tool_use');
  last.content = kept.length > 0 ? kept : [{ type: 'text', text: '(response was cut off)' }];
}

function extractLatestAssistantText(messages: MessageParam[]): string {
  for (let i = messages.length - 1; i >= 0; i--) {
    const m = messages[i];
    if (m?.role !== 'assistant') continue;
    if (typeof m.content === 'string') return m.content;
    if (Array.isArray(m.content)) {
      const text = (m.content as ContentBlock[])
        .filter((c): c is Extract<ContentBlock, { type: 'text' }> => c.type === 'text')
        .map((c) => c.text)
        .join('\n')
        .trim();
      if (text) return text;
    }
  }
  return '';
}
