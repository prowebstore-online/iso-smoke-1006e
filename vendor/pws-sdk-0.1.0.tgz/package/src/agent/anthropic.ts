// Anthropic SDK wrapper. Picks up an optional AI Gateway base URL.

import Anthropic from '@anthropic-ai/sdk';
import type { Env } from '../env.ts';

export const DEFAULT_MODEL = 'claude-sonnet-4-6';
export const HAIKU_MODEL = 'claude-haiku-4-5';
export const OPUS_MODEL = 'claude-opus-4-7';

export function makeAnthropic(env: Env): Anthropic {
  if (!env.ANTHROPIC_API_KEY) {
    throw new Error(
      'ANTHROPIC_API_KEY not set. Add it to .dev.vars or wrangler secret put ANTHROPIC_API_KEY.',
    );
  }
  return new Anthropic({
    apiKey: env.ANTHROPIC_API_KEY,
    baseURL: env.ANTHROPIC_BASE_URL,
  });
}

export function pickModel(env: Env): string {
  return env.ANTHROPIC_MODEL ?? DEFAULT_MODEL;
}
