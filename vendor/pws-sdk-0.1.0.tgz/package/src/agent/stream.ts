// Streaming agent loop: SSE events for real-time UI feedback.
// Mirrors the non-streaming loop.ts but writes events as they arrive.

import type {
  ContentBlock,
  MessageParam,
  TextBlock,
  ToolResultBlockParam,
  ToolUseBlock,
} from '@anthropic-ai/sdk/resources/messages';
import type { SiteRpc } from '../do/rpc.ts';
import type { Env } from '../env.ts';
import { makeAnthropic, pickModel } from './anthropic.ts';
import { buildSiteDigest } from './digest.ts';
import { stripDanglingToolUse } from './loop.ts';
import { buildSystemPrompt } from './system-prompt.ts';
import { TOOL_UNION, dispatchTool } from './tools.ts';

const MAX_ITERATIONS = 25;
const MAX_TOKENS = 4096;

export interface StreamAgentInput {
  env: Env;
  rpc: SiteRpc;
  siteId: string;
  messages: MessageParam[];
  onSessionSave?: (
    messages: MessageParam[],
    usage: { input_tokens: number; output_tokens: number },
  ) => Promise<void>;
}

/** SSE event types the client should handle. */
export type SSEEventType =
  | 'text' // partial text chunk
  | 'tool_use' // tool call started
  | 'tool_result' // tool finished
  | 'done' // final summary
  | 'error'; // error

function sseEvent(event: SSEEventType, data: unknown): string {
  return `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
}

export function runAgentStream(input: StreamAgentInput): ReadableStream {
  const { env, rpc, siteId, messages, onSessionSave } = input;

  return new ReadableStream({
    async start(controller) {
      const encoder = new TextEncoder();
      const write = (event: SSEEventType, data: unknown) => {
        controller.enqueue(encoder.encode(sseEvent(event, data)));
      };

      try {
        const client = makeAnthropic(env);
        const model = pickModel(env);
        const digest = await buildSiteDigest(rpc);
        const system = buildSystemPrompt(digest);

        const usage = { input_tokens: 0, output_tokens: 0 };
        const accMessages: MessageParam[] = [...messages];
        let stopReason: string | null = null;
        let iterations = 0;

        for (let i = 0; i < MAX_ITERATIONS; i++) {
          iterations = i + 1;

          // Stream the Anthropic response.
          const stream = client.messages.stream({
            model,
            max_tokens: MAX_TOKENS,
            system,
            tools: TOOL_UNION,
            messages: accMessages,
          });

          // Collect content blocks while streaming text deltas.
          const contentBlocks: ContentBlock[] = [];
          let currentText = '';

          stream.on('text', (text) => {
            currentText += text;
            write('text', { text });
          });

          const finalMessage = await stream.finalMessage();
          contentBlocks.push(...finalMessage.content);

          usage.input_tokens += finalMessage.usage.input_tokens;
          usage.output_tokens += finalMessage.usage.output_tokens;
          stopReason = finalMessage.stop_reason;

          accMessages.push({ role: 'assistant', content: finalMessage.content });

          if (finalMessage.stop_reason !== 'tool_use') break;

          const toolUses = finalMessage.content.filter(
            (c): c is ToolUseBlock => c.type === 'tool_use',
          );
          if (toolUses.length === 0) break;

          const toolResults: ToolResultBlockParam[] = [];
          for (const use of toolUses) {
            write('tool_use', { name: use.name, input: use.input });

            const result = await dispatchTool(use.name, use.input as Record<string, unknown>, rpc, {
              env,
              siteId,
            });
            const text = result.ok ? (result.result ?? 'OK') : `ERROR: ${result.error}`;

            write('tool_result', {
              name: use.name,
              ok: result.ok,
              preview: text.slice(0, 200),
            });

            toolResults.push({
              type: 'tool_result',
              tool_use_id: use.id,
              content: text,
              is_error: !result.ok,
            });
          }
          accMessages.push({ role: 'user', content: toolResults });
        }

        // Drop any dangling tool_use (e.g. max_tokens truncated a tool turn)
        // before persisting — otherwise the next call 400s on this session.
        stripDanglingToolUse(accMessages);

        // Persist session if callback provided.
        if (onSessionSave) {
          await onSessionSave(accMessages, usage);
        }

        // Extract final assistant text.
        let assistantText = '';
        for (let i = accMessages.length - 1; i >= 0; i--) {
          const m = accMessages[i];
          if (m?.role !== 'assistant') continue;
          if (Array.isArray(m.content)) {
            assistantText = (m.content as ContentBlock[])
              .filter((c): c is TextBlock => c.type === 'text')
              .map((c) => c.text)
              .join('\n')
              .trim();
            if (assistantText) break;
          }
        }

        write('done', {
          ok: true,
          assistantText,
          iterations,
          stopReason,
          usage,
          model,
        });
      } catch (err) {
        // Only expose Anthropic API error details; hide internal errors.
        const msg =
          err instanceof Error && 'status' in err
            ? err.message
            : 'Internal error. Please try again.';
        write('error', {
          ok: false,
          error: msg,
        });
      } finally {
        controller.close();
      }
    },
  });
}
