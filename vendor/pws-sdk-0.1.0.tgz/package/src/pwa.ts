// PWA manifest and service worker utilities shared across all interfaces.

/** Generate an SVG icon with a letter on a colored background. */
export function svgIcon(letter: string, bgColor: string, fgColor = '#fff'): string {
  const l = letter[0]?.toUpperCase() ?? 'W';
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><rect width="512" height="512" fill="${bgColor}" rx="64"/><text x="256" y="360" font-family="system-ui,sans-serif" font-size="320" fill="${fgColor}" text-anchor="middle" font-weight="700">${l}</text></svg>`;
}

/** Data-URI for an SVG icon (used in apple-touch-icon). */
export function svgIconDataUri(letter: string, bgColor: string, fgColor = '#fff'): string {
  return `data:image/svg+xml,${encodeURIComponent(svgIcon(letter, bgColor, fgColor))}`;
}

/** Generate a web app manifest JSON string. */
export function generateManifest(opts: {
  name: string;
  shortName: string;
  startUrl: string;
  themeColor: string;
  bgColor: string;
  iconLetter: string;
  iconBgColor: string;
  iconFgColor?: string;
  description?: string;
  basePath?: string;
}): string {
  const base = opts.basePath ?? '';
  return JSON.stringify({
    name: opts.name,
    short_name: opts.shortName,
    start_url: opts.startUrl,
    display: 'standalone',
    theme_color: opts.themeColor,
    background_color: opts.bgColor,
    description: opts.description,
    icons: [
      { src: `${base}/icon.svg`, sizes: 'any', type: 'image/svg+xml', purpose: 'any' },
      { src: `${base}/icon.svg`, sizes: 'any', type: 'image/svg+xml', purpose: 'maskable' },
    ],
  });
}

/** Minimal service worker that caches the app shell. */
export const MINIMAL_SW = `
// PWS service worker — cache-first for static assets, network-first for API/pages.
const CACHE_NAME = 'pws-v1';

self.addEventListener('install', (e) => { self.skipWaiting(); });
self.addEventListener('activate', (e) => { e.waitUntil(self.clients.claim()); });

self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  // Only intercept same-origin GET requests.
  if (e.request.method !== 'GET' || url.origin !== self.location.origin) return;
  // Skip API and auth routes.
  if (url.pathname.startsWith('/sites/') || url.pathname.startsWith('/auth/')) return;
  // Network-first for HTML pages.
  if (e.request.headers.get('accept')?.includes('text/html')) {
    e.respondWith(
      fetch(e.request).catch(() => caches.match(e.request))
    );
    return;
  }
  // Cache-first for static assets (images, fonts, css).
  e.respondWith(
    caches.match(e.request).then((cached) => {
      if (cached) return cached;
      return fetch(e.request).then((res) => {
        if (res.ok && (url.pathname.startsWith('/_/img/') || url.pathname.endsWith('.css') || url.pathname.endsWith('.js'))) {
          const clone = res.clone();
          caches.open(CACHE_NAME).then((c) => c.put(e.request, clone));
        }
        return res;
      });
    })
  );
});
`.trim();

// Same shape as escapeAttr in render/record-detail.tsx. Attribute values are an
// escapable context — unlike the <style> raw text in theme-css.ts — so escaping
// here is correct and lossless.
const escapeAttr = (s: string): string => s.replace(/[<>"'&]/g, (c) => `&#${c.charCodeAt(0)};`);

/** PWA meta tags for <head> (returns raw HTML string).
 *
 *  Every caller wraps the result in `raw()`, so this function is responsible for
 *  escaping its own interpolations. `themeColor` is tenant-controlled — it is
 *  `theme.colors.primary` at render/page.tsx:388 — and used to be emitted
 *  verbatim, so a colour of `</style><script>…` injected a real script element
 *  into every page's <head> (#37). `iconLetter`/`iconBgColor` reach the document
 *  through svgIconDataUri's encodeURIComponent and are already inert.
 *
 *  @param basePath - prefix for manifest/icon URLs (e.g. "/console") */
export function pwaMetaTags(opts: {
  themeColor: string;
  iconLetter: string;
  iconBgColor: string;
  basePath?: string;
}): string {
  const base = opts.basePath ?? '';
  const iconUri = svgIconDataUri(opts.iconLetter, opts.iconBgColor);
  return [
    `<meta name="theme-color" content="${escapeAttr(opts.themeColor)}">`,
    `<meta name="mobile-web-app-capable" content="yes">`,
    `<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">`,
    `<link rel="apple-touch-icon" href="${escapeAttr(iconUri)}">`,
    `<link rel="manifest" href="${escapeAttr(base)}/manifest.json">`,
  ].join('\n    ');
}
