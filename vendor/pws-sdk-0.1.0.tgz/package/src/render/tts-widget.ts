// Text-to-speech widget — adds a floating play button to any page.
// Uses the browser's built-in SpeechSynthesis API (free, no API key).
// Include via <script src="/_/tts.js"></script> on any page (CMS or static).

export const TTS_SCRIPT = `(function(){
  if (!('speechSynthesis' in window)) return;

  var speaking = false, paused = false, utterance = null;

  // Create floating button
  var btn = document.createElement('button');
  btn.id = 'pws-tts';
  btn.setAttribute('aria-label', 'Listen to this page');
  btn.title = 'Listen to this page';
  btn.innerHTML = '\\u25B6 Listen';
  btn.style.cssText = 'position:fixed;bottom:20px;right:20px;z-index:9999;background:var(--color-primary,#6366f1);color:#fff;border:none;border-radius:2rem;padding:10px 18px;font-size:14px;font-weight:600;cursor:pointer;box-shadow:0 2px 12px rgba(0,0,0,0.2);transition:all 0.2s;font-family:inherit;';
  btn.onmouseenter = function(){btn.style.transform='scale(1.05)';};
  btn.onmouseleave = function(){btn.style.transform='scale(1)';};
  document.body.appendChild(btn);

  // Progress bar
  var bar = document.createElement('div');
  bar.style.cssText = 'position:fixed;bottom:0;left:0;height:3px;background:var(--color-primary,#6366f1);z-index:9998;transition:width 0.3s;width:0;';
  document.body.appendChild(bar);

  function getText() {
    var main = document.querySelector('main');
    if (!main) main = document.body;
    // Skip nav, footer, scripts, styles, buttons
    var clone = main.cloneNode(true);
    var skip = clone.querySelectorAll('nav,footer,script,style,button,.pws-controls,#pws-tts');
    for (var i = 0; i < skip.length; i++) skip[i].remove();
    return (clone.textContent || '').replace(/\\s+/g, ' ').trim();
  }

  function stop() {
    speechSynthesis.cancel();
    speaking = false;
    paused = false;
    btn.innerHTML = '\\u25B6 Listen';
    bar.style.width = '0';
  }

  btn.onclick = function() {
    if (speaking && !paused) {
      speechSynthesis.pause();
      paused = true;
      btn.innerHTML = '\\u25B6 Resume';
      return;
    }
    if (paused) {
      speechSynthesis.resume();
      paused = false;
      btn.innerHTML = '\\u23F8 Pause';
      return;
    }

    var text = getText();
    if (!text) return;

    // Split into chunks (SpeechSynthesis has a ~200 char limit on some browsers)
    var sentences = text.match(/[^.!?]+[.!?]+/g) || [text];
    var totalChars = text.length;
    var spokenChars = 0;
    var idx = 0;

    function speakNext() {
      if (idx >= sentences.length) { stop(); return; }
      utterance = new SpeechSynthesisUtterance(sentences[idx]);
      utterance.rate = 1.0;
      utterance.pitch = 1.0;

      // Try to pick a natural voice
      var voices = speechSynthesis.getVoices();
      var lang = document.documentElement.lang || 'en';
      var natural = voices.find(function(v){ return v.lang.startsWith(lang) && v.name.toLowerCase().includes('natural'); })
        || voices.find(function(v){ return v.lang.startsWith(lang) && !v.localService; })
        || voices.find(function(v){ return v.lang.startsWith(lang); });
      if (natural) utterance.voice = natural;

      utterance.onend = function() {
        spokenChars += sentences[idx].length;
        bar.style.width = Math.min(100, (spokenChars / totalChars * 100)).toFixed(1) + '%';
        idx++;
        speakNext();
      };
      speechSynthesis.speak(utterance);
    }

    speaking = true;
    paused = false;
    btn.innerHTML = '\\u23F8 Pause';
    speakNext();
  };

  // Clean up on page unload
  window.addEventListener('beforeunload', stop);
})();`;
