/** @jsxRuntime automatic */
/** @jsxImportSource hono/jsx */
// Record-detail content (the <main> body for a single entity record).
//
// Detail pages do NOT have their own document/nav. The serve layer renders this
// body into the standard page shell via renderPage's rawHtml, so detail pages
// inherit the same nav (hamburger), footer, cart, language switcher, i18n, and
// theme as every other page. Keeping ONE render path is deliberate — the old
// bespoke full-document renderer drifted (missing hamburger / switcher / i18n)
// and was removed. See docs/RENDERING.md.

import type { EntityRecord, EntitySchema } from '@pws/shared';
import { safeHref, sanitizeHtml } from './sanitize.ts';

function escapeAttr(s: string): string {
  return s.replace(/[<>"'&]/g, (c) => `&#${c.charCodeAt(0)};`);
}

/** Inner <main> content for a record detail page (title + buy CTA + fields).
 *  Returned as a trusted HTML string for injection via renderPage's rawHtml.
 *  Product records get a storefront treatment (formatted price + Add to Cart,
 *  internal stock/featured flags hidden). Display strings are translated via the
 *  supplied map. */
export function renderRecordDetailBody(input: {
  record: EntityRecord;
  schema: EntitySchema;
  translations?: Record<string, string>;
  localePrefix?: string;
  /** Slug of the site's sellable entity (default 'product'); drives the buy CTA. */
  sellableEntity?: string;
}): string {
  const { record, schema } = input;
  const tr = (s: string) => input.translations?.[s] ?? s;
  const title = String(record.data.title ?? record.data.name ?? record.slug ?? schema.name);
  const isProduct = schema.slug === (input.sellableEntity ?? 'product');
  const fmtPrice = (cents: unknown) => `$${(Number(cents) / 100).toFixed(2)}`;
  const skipFields = isProduct
    ? new Set(['price', 'sale_price', 'in_stock', 'stock', 'featured'])
    : new Set<string>();

  let productCta = '';
  if (isProduct) {
    const price = Number(record.data.price) || 0;
    // Out of stock when the manual flag is false OR tracked stock is depleted.
    const inStock =
      record.data.in_stock !== false &&
      (typeof record.data.stock !== 'number' || Number(record.data.stock) > 0);
    const img = record.data.image as { asset_id?: string } | null | undefined;
    const aid = img && typeof img === 'object' ? (img.asset_id ?? '') : '';
    const btn = inStock
      ? `<button type="button" class="pws-add-to-cart pws-detail-add" data-product-id="${escapeAttr(record.id)}" data-product-name="${escapeAttr(title)}" data-product-price="${Math.round(price)}" data-product-image="${escapeAttr(aid)}">${escapeAttr(tr('Add to Cart'))}</button>`
      : `<span class="pws-detail-sold">${escapeAttr(tr('Sold'))}</span>`;
    productCta = `<div class="pws-detail-cta"><span class="pws-detail-price">${fmtPrice(price)}</span>${btn}</div>`;
  }

  const fieldHtml = schema.fields
    .map((field) => {
      if (skipFields.has(field.slug)) return '';
      const value = record.data[field.slug];
      if (value === null || value === undefined || value === '') return '';

      let rendered: string;
      switch (field.type) {
        case 'richtext':
          rendered = `<div class="prose" style="color: var(--color-text); font-family: var(--font-body);">${sanitizeHtml(String(value))}</div>`;
          break;
        case 'image':
          if (typeof value === 'object' && value && 'asset_id' in value) {
            const img = value as { asset_id: string; alt?: string };
            rendered = `<img src="/_/img/${escapeAttr(img.asset_id)}?w=1200" alt="${escapeAttr(img.alt ?? '')}" class="w-full h-auto" style="border-radius: var(--radius); max-height: 480px; object-fit: cover;" loading="lazy" />`;
          } else {
            return '';
          }
          break;
        case 'boolean':
          rendered = `<span>${value ? 'Yes' : 'No'}</span>`;
          break;
        case 'number':
          rendered = /price|cost|amount/.test(field.slug)
            ? `<span style="font-variant-numeric: tabular-nums;">${fmtPrice(value)}</span>`
            : `<span style="font-variant-numeric: tabular-nums;">${Number(value).toLocaleString()}</span>`;
          break;
        case 'email':
          rendered = `<a href="mailto:${escapeAttr(String(value))}">${escapeAttr(String(value))}</a>`;
          break;
        case 'phone':
          rendered = `<a href="tel:${escapeAttr(String(value))}">${escapeAttr(String(value))}</a>`;
          break;
        case 'url':
          rendered = `<a href="${escapeAttr(safeHref(String(value)))}" target="_blank" rel="noopener noreferrer">${escapeAttr(String(value))}</a>`;
          break;
        case 'multiselect':
          if (Array.isArray(value)) {
            rendered = value
              .map(
                (v) =>
                  `<span class="inline-block px-2 py-0.5 text-xs" style="background: var(--color-surface); border-radius: var(--radius);">${escapeAttr(tr(String(v)))}</span>`,
              )
              .join(' ');
          } else {
            return '';
          }
          break;
        case 'select':
          rendered = `<span class="inline-block px-2 py-0.5 text-xs" style="background: var(--color-surface); border-radius: var(--radius);">${escapeAttr(tr(String(value)))}</span>`;
          break;
        case 'color': {
          // escapeAttr does not neutralize CSS metacharacters (; : ( )), so
          // sanitize the value used in the style declaration — mirrors the
          // entity-grid color guard. (The trailing label is HTML-escaped.)
          const colorVal = String(value).replace(/[^a-zA-Z0-9#(),.\s%]/g, '');
          rendered = `<span class="inline-block w-6 h-6 align-middle" style="background-color: ${colorVal}; border-radius: var(--radius);"></span> ${escapeAttr(String(value))}`;
          break;
        }
        case 'reference':
        case 'reference_list':
          return '';
        default:
          rendered = `<span>${escapeAttr(String(value))}</span>`;
      }

      return `<div class="mb-4">
        <dt class="text-sm font-medium mb-1" style="color: var(--color-heading); opacity: 0.7;">${escapeAttr(tr(field.name))}</dt>
        <dd style="margin: 0;">${rendered}</dd>
      </div>`;
    })
    .filter(Boolean)
    .join('');

  return `<section class="px-6 py-12"><div class="max-w-3xl mx-auto">
    <h1 class="text-3xl font-bold mb-6" style="color: var(--color-heading); font-family: var(--font-heading);">${escapeAttr(title)}</h1>
    ${productCta}
    <dl>${fieldHtml}</dl>
  </div></section>`;
}
