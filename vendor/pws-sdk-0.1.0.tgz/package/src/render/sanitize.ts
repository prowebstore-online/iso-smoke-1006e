// Allowlist-based HTML sanitizer using ultrahtml's AST parser.
// Parses input into an AST, walks it with an allowlist filter, and serializes
// back to a safe HTML string. Unknown tags are dropped (children kept);
// unknown attributes are stripped. Text nodes are entity-encoded so partial
// tags can't reassemble into real elements.

import { ELEMENT_NODE, type Node, TEXT_NODE, parse, renderSync, walkSync } from 'ultrahtml';
import sanitize from 'ultrahtml/transformers/sanitize';

const ALLOWED_TAGS = new Set([
  'h1',
  'h2',
  'h3',
  'h4',
  'h5',
  'h6',
  'p',
  'a',
  'ul',
  'ol',
  'li',
  'strong',
  'em',
  'b',
  'i',
  'u',
  'br',
  'img',
  'blockquote',
  'code',
  'pre',
  'table',
  'thead',
  'tbody',
  'tr',
  'th',
  'td',
  'hr',
  'span',
  'sup',
  'sub',
  'figure',
  'figcaption',
  'dl',
  'dt',
  'dd',
  'abbr',
  'mark',
  'small',
  'del',
  'ins',
  'div',
]);

const DROP_TAGS = [
  'script',
  'style',
  'iframe',
  'object',
  'embed',
  'link',
  'meta',
  'base',
  'form',
  'svg',
  'math',
  'noscript',
  'template',
];

// Attributes allowed per tag.
const ALLOWED_ATTRS: Record<string, Set<string>> = {
  a: new Set(['href', 'target', 'class', 'id']),
  img: new Set(['src', 'alt', 'width', 'height', 'class', 'id']),
  th: new Set(['colspan', 'rowspan', 'width', 'class', 'id']),
  td: new Set(['colspan', 'rowspan', 'width', 'class', 'id']),
  table: new Set(['width', 'class', 'id']),
};
const DEFAULT_ATTRS = new Set(['class', 'id']);

// Safe URL protocol pattern.
const SAFE_URL = /^(?:https?:|mailto:|tel:|\/|#)/i;

function isSafeUrl(value: string): boolean {
  const trimmed = value.trim();
  if (trimmed === '') return true;
  return SAFE_URL.test(trimmed);
}

/**
 * Return `value` if it is a safe URL (http/https/mailto/tel/relative/#), else '#'.
 * For rendering record `url` fields into href/src: write-time validation covers
 * form input, but seed data, template scaffolds, and agent-issued direct SQL can
 * reach storage without it — so the render layer must not assume safety.
 */
export function safeHref(value: string): string {
  return isSafeUrl(value) ? value : '#';
}

function escapeHtml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

export function sanitizeHtml(input: string): string {
  const doc = parse(input);

  // First pass: drop dangerous elements entirely, unwrap unknown elements.
  const sanitized = sanitize({
    dropElements: DROP_TAGS,
    allowElements: [...ALLOWED_TAGS],
    allowComments: false,
  })(doc);

  // Second pass: strip disallowed attributes, validate URLs, and escape text
  // nodes so partial-tag fragments can't reassemble into real elements.
  walkSync(sanitized, (node: Node) => {
    if (node.type === TEXT_NODE) {
      const text = node as import('ultrahtml').TextNode;
      text.value = escapeHtml(text.value);
      return;
    }
    if (node.type !== ELEMENT_NODE) return;
    const el = node as import('ultrahtml').ElementNode;
    const tag = el.name;
    const allowed = ALLOWED_ATTRS[tag] ?? DEFAULT_ATTRS;

    for (const attr of Object.keys(el.attributes)) {
      if (!allowed.has(attr)) {
        delete el.attributes[attr];
        continue;
      }

      if (attr === 'href' || attr === 'src') {
        if (!isSafeUrl(el.attributes[attr] ?? '')) {
          delete el.attributes[attr];
        }
      }

      if (attr === 'target' && el.attributes[attr] !== '_blank') {
        delete el.attributes[attr];
      }
    }
  });

  return renderSync(sanitized);
}

// custom_head is owner-supplied HTML meant ONLY for <meta>/<link> tags
// (site-verification tokens, preconnect/prefetch) — never executable JS. A regex
// blocklist over HTML is bypassable (e.g. `<img src=x/onerror=...>` slips past a
// `\son\w+=` handler regex because the char before `on` is `/`, not whitespace),
// so parse to an AST and allowlist just <meta>/<link> with a fixed set of safe
// attributes. Every other element is dropped and all event handlers stripped.
const HEAD_ALLOWED_ATTRS: Record<string, Set<string>> = {
  // Deliberately excludes http-equiv (meta-refresh navigation) and charset.
  meta: new Set(['name', 'property', 'content']),
  link: new Set([
    'rel',
    'href',
    'type',
    'sizes',
    'crossorigin',
    'as',
    'media',
    'hreflang',
    'title',
  ]),
};

// Matches ONLY a first-party platform widget script (e.g. /_/tts.js) that
// enable_tts/enable_translate append to custom_head. The path charset forbids
// slashes and dot-sequences, so it can't be abused for traversal or a
// protocol-relative (//host) src.
const FIRST_PARTY_SCRIPT =
  /<script\b[^>]*\bsrc=["']?(\/_\/[a-zA-Z0-9_-]+\.js)["']?[^>]*><\/script>/gi;

export function sanitizeHeadHtml(input: string): string {
  // Preserve first-party widget scripts, rebuilding each from the validated src
  // (not passing the original attributes through), then drop them from the input
  // the AST allowlist sees.
  const widgets: string[] = [];
  const withoutWidgets = input.replace(FIRST_PARTY_SCRIPT, (_m, src) => {
    widgets.push(`<script src="${src}" defer></script>`);
    return '';
  });

  const doc = parse(withoutWidgets);
  const sanitized = sanitize({
    allowElements: ['meta', 'link'],
    dropElements: [...DROP_TAGS, 'img', 'a', 'video', 'audio', 'source', 'picture'],
    allowComments: false,
  })(doc);

  walkSync(sanitized, (node: Node) => {
    if (node.type === TEXT_NODE) {
      const text = node as import('ultrahtml').TextNode;
      text.value = escapeHtml(text.value);
      return;
    }
    if (node.type !== ELEMENT_NODE) return;
    const el = node as import('ultrahtml').ElementNode;
    const allowed = HEAD_ALLOWED_ATTRS[el.name] ?? new Set<string>();
    for (const attr of Object.keys(el.attributes)) {
      if (!allowed.has(attr)) {
        delete el.attributes[attr];
        continue;
      }
      if (attr === 'href' && !isSafeUrl(el.attributes[attr] ?? '')) {
        delete el.attributes[attr];
      }
    }
  });

  return [renderSync(sanitized), ...widgets].join('\n');
}
