// Client-side cart JS injected into pages containing product_grid or cart blocks.
// Uses localStorage. No external dependencies.

export const CART_SCRIPT = `(function(){
  var K='pws_cart';
  var I=(typeof window!=='undefined'&&window.__pwsI18n)||{};
  function L(k,d){return I[k]||d;}

  function getCart(){
    try{return JSON.parse(localStorage.getItem(K)||'[]');}catch(e){return[];}
  }
  function saveCart(c){localStorage.setItem(K,JSON.stringify(c));}

  function escAttr(s){return String(s).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
  function escHtml(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}

  function addToCart(id,name,price,image){
    var c=getCart();
    var item=c.find(function(i){return i.id===id;});
    if(item){item.qty++;}
    else{c.push({id:id,name:name,price:Number(price),image:image,qty:1});}
    saveCart(c);
    updateBadge();
    showNotification(name);
  }

  function removeFromCart(id){
    var c=getCart().filter(function(i){return i.id!==id;});
    saveCart(c);
    renderCartPage();
    updateBadge();
  }

  function changeQty(id,delta){
    var c=getCart();
    var item=c.find(function(i){return i.id===id;});
    if(!item)return;
    item.qty=Math.max(1,item.qty+delta);
    saveCart(c);
    renderCartPage();
    updateBadge();
  }

  function showNotification(name){
    var n=document.createElement('div');
    n.textContent=name+' '+L('added to cart','added to cart');
    n.style.cssText='position:fixed;bottom:24px;right:24px;background:var(--color-primary);color:#fff;padding:12px 20px;border-radius:8px;font-size:14px;z-index:9999;opacity:0;transition:opacity 0.3s;box-shadow:0 4px 12px rgba(0,0,0,0.15);';
    document.body.appendChild(n);
    requestAnimationFrame(function(){n.style.opacity='1';});
    setTimeout(function(){n.style.opacity='0';setTimeout(function(){n.remove();},300);},2000);
  }

  function updateBadge(){
    var badge=document.getElementById('pws-cart-badge');
    if(!badge)return;
    var c=getCart();
    var count=c.reduce(function(s,i){return s+i.qty;},0);
    badge.textContent=count>0?String(count):'';
    badge.style.display=count>0?'inline-flex':'none';
  }

  function formatPrice(cents){return '$'+(cents/100).toFixed(2);}

  function renderCartPage(){
    var listEl=document.getElementById('pws-cart-list');
    var emptyEl=document.getElementById('pws-cart-empty');
    var itemsEl=document.getElementById('pws-cart-items');
    var totalEl=document.getElementById('pws-cart-total');
    if(!listEl)return;

    var c=getCart();
    if(c.length===0){
      if(emptyEl)emptyEl.style.display='';
      if(itemsEl)itemsEl.style.display='none';
      return;
    }
    if(emptyEl)emptyEl.style.display='none';
    if(itemsEl)itemsEl.style.display='';

    var total=0;
    var html='';
    for(var i=0;i<c.length;i++){
      var item=c[i];
      var lineTotal=item.price*item.qty;
      total+=lineTotal;
      var safeId=escAttr(item.id);
      var imgHtml=item.image?'<img src="/_/img/'+escAttr(item.image)+'" alt="" style="width:64px;height:64px;object-fit:cover;border-radius:6px;" loading="lazy" />':'<div style="width:64px;height:64px;background:var(--color-neutral-200);border-radius:6px;"></div>';
      html+='<div class="flex items-center gap-4 py-4" style="border-bottom:1px solid var(--color-neutral-200);">'
        +imgHtml
        +'<div class="flex-1">'
        +'<div style="font-weight:600;color:var(--color-heading);">'+escHtml(item.name)+'</div>'
        +'<div style="font-size:0.85rem;opacity:0.6;">'+formatPrice(item.price)+' '+L('each','each')+'</div>'
        +'</div>'
        +'<div class="flex items-center gap-2">'
        +'<button type="button" data-cart-qty="'+safeId+':-1" style="width:28px;height:28px;border:1px solid var(--color-neutral-200);background:none;border-radius:4px;cursor:pointer;font-size:16px;color:var(--color-text);display:flex;align-items:center;justify-content:center;">-</button>'
        +'<span style="min-width:24px;text-align:center;font-variant-numeric:tabular-nums;">'+item.qty+'</span>'
        +'<button type="button" data-cart-qty="'+safeId+':1" style="width:28px;height:28px;border:1px solid var(--color-neutral-200);background:none;border-radius:4px;cursor:pointer;font-size:16px;color:var(--color-text);display:flex;align-items:center;justify-content:center;">+</button>'
        +'</div>'
        +'<div style="min-width:80px;text-align:right;font-weight:600;color:var(--color-primary);">'+formatPrice(lineTotal)+'</div>'
        +'<button type="button" data-cart-remove="'+safeId+'" style="background:none;border:none;cursor:pointer;font-size:18px;opacity:0.4;padding:4px;" title="'+escAttr(L('Remove','Remove'))+'">&times;</button>'
        +'</div>';
    }
    listEl.innerHTML=html;
    if(totalEl)totalEl.textContent=formatPrice(total);

    listEl.querySelectorAll('[data-cart-qty]').forEach(function(btn){
      btn.addEventListener('click',function(){
        var parts=this.getAttribute('data-cart-qty').split(':');
        changeQty(parts[0],parseInt(parts[1],10));
      });
    });
    listEl.querySelectorAll('[data-cart-remove]').forEach(function(btn){
      btn.addEventListener('click',function(){
        removeFromCart(this.getAttribute('data-cart-remove'));
      });
    });
  }

  // Wire up "Add to Cart" buttons on product grids
  document.querySelectorAll('.pws-add-to-cart').forEach(function(btn){
    btn.addEventListener('click',function(){
      addToCart(
        this.getAttribute('data-product-id'),
        this.getAttribute('data-product-name'),
        this.getAttribute('data-product-price'),
        this.getAttribute('data-product-image')
      );
    });
  });

  // Checkout page: populate the order summary + hidden cart payload.
  function renderCheckoutPage(){
    var itemsEl=document.getElementById('pws-checkout-items');
    if(!itemsEl)return;
    var c=getCart();
    var emptyEl=document.getElementById('pws-checkout-empty');
    var bodyEl=document.getElementById('pws-checkout-body');
    if(c.length===0){
      if(emptyEl)emptyEl.style.display='';
      if(bodyEl)bodyEl.style.display='none';
      return;
    }
    if(emptyEl)emptyEl.style.display='none';
    if(bodyEl)bodyEl.style.display='';
    var total=0,html='';
    for(var i=0;i<c.length;i++){
      var it=c[i];total+=it.price*it.qty;
      html+='<div class="flex justify-between gap-4" style="padding:0.6rem 0;border-bottom:1px solid var(--color-neutral-200);">'
        +'<span>'+escHtml(it.name)+' <span style="opacity:0.6;">x '+it.qty+'</span></span>'
        +'<span style="font-variant-numeric:tabular-nums;">'+formatPrice(it.price*it.qty)+'</span></div>';
    }
    itemsEl.innerHTML=html;
    var totalEl=document.getElementById('pws-checkout-total');if(totalEl)totalEl.textContent=formatPrice(total);
    var amtEl=document.getElementById('pws-co-pay-amt');if(amtEl)amtEl.textContent=formatPrice(total);
    var input=document.getElementById('pws-cart-input');
    if(input)input.value=JSON.stringify(c.map(function(i){return {id:i.id,qty:i.qty};}));
  }

  // Checkout button → go to the checkout page, which collects shipping details,
  // creates the order, and hands off to Stripe (Connect destination charge to the
  // merchant if connected, else a direct platform charge). Single path.
  var checkBtn=document.getElementById('pws-checkout-btn');
  if(checkBtn){
    checkBtn.addEventListener('click',function(){
      if(getCart().length===0)return;
      window.location.href=this.getAttribute('data-checkout-url')||'/checkout';
    });
  }

  // Checkout form: re-serialize the cart at submit time (defends against edits in another tab),
  // and disable the submit button so a double-click can't create duplicate orders/sessions.
  // The submit event only fires after HTML validation passes, so the button is never left
  // stuck-disabled on an invalid form.
  var coForm=document.getElementById('pws-checkout-form');
  if(coForm){
    coForm.addEventListener('submit',function(){
      var input=document.getElementById('pws-cart-input');
      if(input)input.value=JSON.stringify(getCart());
      var b=coForm.querySelector('button[type="submit"]');
      if(b){b.disabled=true;b.style.opacity='0.6';b.style.cursor='wait';b.textContent='Processing…';}
    });
  }

  // Order confirmation page: the purchase is recorded server-side, so empty the cart.
  if(document.getElementById('pws-order-confirmed')){
    try{localStorage.removeItem(K);}catch(e){}
  }

  renderCartPage();
  renderCheckoutPage();
  updateBadge();
})();`;
