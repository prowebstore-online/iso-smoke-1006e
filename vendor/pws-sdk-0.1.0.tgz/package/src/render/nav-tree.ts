import type { NavPage } from '@pws/shared';
import { t } from './translate.ts';

export interface NavNode {
  slug: string;
  label: string;
  active: boolean;
  children: NavNode[];
}

export function buildNavTree(
  pages: NavPage[],
  currentSlug: string,
  tr?: Record<string, string>,
): NavNode[] {
  const items = pages
    .filter((p) => p.show_in_nav)
    .sort((a, b) => a.nav_order - b.nav_order || a.title.localeCompare(b.title));
  const roots: NavNode[] = [];
  const nodeMap = new Map<string, NavNode>();
  // Two-pass: create all nodes first, then wire parent-child
  for (const p of items) {
    nodeMap.set(p.slug, {
      slug: p.slug === '/' ? '/' : p.slug,
      label: t(p.nav_label || p.title, tr),
      active: p.slug === currentSlug,
      children: [],
    });
  }
  for (const p of items) {
    const node = nodeMap.get(p.slug)!;
    const parts = p.slug.split('/').filter(Boolean);
    if (parts.length > 1) {
      const parent = nodeMap.get(`/${parts.slice(0, -1).join('/')}`);
      if (parent) {
        parent.children.push(node);
        continue;
      }
    }
    roots.push(node);
  }
  return roots;
}
