// HTTP response headers for rendered tenant pages.
//
// Two CSP shapes, one directive set. Both deny inline script by default; they
// differ only in how the renderer's own inline scripts are allowed back in:
//
//   cspForTenantPage(nonce)   dynamic render — a per-request nonce + strict-dynamic
//   cspForBakedPage(hashes)   pre-rendered R2 object — sha256 hashes of its scripts
//
// There is deliberately NO arm that emits script-src 'unsafe-inline'. One used
// to exist: the pre-hardening May policy, kept as the default value of an
// optional `nonce` parameter in 8c37dbb, six weeks before baked pages existed.
// 8710af9 then adopted it for the R2 path because it was the only nonce-less
// option in the tree, which left every baked page — the path carrying the
// product's least trustworthy HTML, since publish_static_page stores arbitrary
// markup verbatim — with no XSS mitigation at all (#38). "No nonce" implies
// "not a nonce policy"; it does not imply 'unsafe-inline'.
//
// Styles allow 'unsafe-inline' because the theme <style> block is generated
// server-side. That is only safe because theme values are guarded twice — a
// strict colour/font format in meta-validator.ts on write, and an allowlist in
// themeToCss() on emit. Do not weaken either: a value containing `</style>`
// ends the element and the rest is parsed as markup. This comment used to claim
// the Zod validation was sufficient on its own; it was not (#37) — the
// oklch()/hsl() branches accepted `oklch(</style><script …>)`.

import type { Context } from 'hono';

export interface RenderHeadersOpts {
  contentType?: string;
  /**
   * CSP nonce for the renderer's inline scripts. Omit ONLY for non-HTML bodies
   * (the text/plain 404 and 500 in worker/index.ts): a nonce-less HTML render
   * gets a policy with no inline allowance at all, which kills the theme/nav
   * IIFE — dark mode, font sizing and the mobile menu — exactly as in #33.
   */
  nonce?: string;
}

export function renderHtmlHeaders(
  cache: 'HIT' | 'MISS',
  version: number,
  opts: RenderHeadersOpts = {},
): Record<string, string> {
  return {
    'content-type': opts.contentType ?? 'text/html; charset=utf-8',
    'x-pws-cache': cache,
    'x-pws-version': String(version),
    'cache-control': 'public, max-age=60',
    'content-security-policy': opts.nonce ? cspForTenantPage(opts.nonce) : cspForBakedPage([]),
    'x-content-type-options': 'nosniff',
    'referrer-policy': 'strict-origin-when-cross-origin',
    'permissions-policy': 'geolocation=(), microphone=(), camera=(), payment=()',
    'strict-transport-security': 'max-age=31536000; includeSubDomains',
  };
}

const ANALYTICS_SCRIPT_HOSTS = [
  'https://static.cloudflareinsights.com',
  'https://www.googletagmanager.com',
  'https://plausible.io',
].join(' ');

const ANALYTICS_CONNECT_HOSTS = [
  'https://cloudflareinsights.com',
  'https://www.google-analytics.com',
  'https://plausible.io',
].join(' ');

/**
 * `inlineSources` are the expressions that allow the renderer's own inline
 * scripts — a nonce (+ strict-dynamic) on the dynamic path, sha256 hashes on
 * the baked one. An empty list is legal and means "no inline script"; it must
 * not collapse into a stray double space in the directive.
 */
function tenantCsp(inlineSources: string[]): string {
  const scriptSrc = [
    "'self'",
    ...inlineSources,
    'https://challenges.cloudflare.com',
    ANALYTICS_SCRIPT_HOSTS,
  ].join(' ');
  const directives = [
    "default-src 'self'",
    `script-src ${scriptSrc}`,
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    "img-src 'self' https://media.prowebstore.online https: data:",
    "font-src 'self' https://fonts.gstatic.com data:",
    `connect-src 'self' ${ANALYTICS_CONNECT_HOSTS}`,
    // checkout.stripe.com: storefront checkout POSTs to /_/checkout, which 303s
    // to Stripe's hosted page — the browser enforces form-action on that
    // redirect target, so it must be allowlisted or the redirect is blocked.
    "form-action 'self' https://accounts.google.com https://checkout.stripe.com",
    'frame-src https://challenges.cloudflare.com',
    // Live-preview iframe embedders: the console (prowebstore.online — the new
    // home of the studio), the shared admin host, 'self' (subdomain admin), and
    // the raw worker origin.
    "frame-ancestors 'self' https://prowebstore.online https://admin.prowebstore.online https://pws-worker-prod.serge-the-dev.workers.dev",
    "base-uri 'self'",
    "object-src 'none'",
    'upgrade-insecure-requests',
  ];
  return directives.join('; ');
}

/**
 * Dynamic render: a per-request nonce plus 'strict-dynamic', so scripts the
 * renderer emitted can pull sub-resources (analytics beacons) and nothing else
 * inline can run.
 */
export function cspForTenantPage(nonce: string): string {
  return tenantCsp([`'nonce-${nonce}'`, "'strict-dynamic'"]);
}

/**
 * Pre-rendered (baked) page. The R2 object is byte-identical for every request
 * so a per-request nonce is impossible — the inline scripts are allowed by
 * sha256 instead, computed by inlineScriptHashes() when the object is written
 * and stored in its customMetadata.
 *
 * Deliberately NO 'strict-dynamic' here. strict-dynamic makes the browser
 * ignore 'self' and every host expression, which on a baked page would silently
 * kill /_/translate.js, Turnstile and the analytics beacons — a breakage
 * invisible until someone bakes. Hashes plus the host allowlist is the correct
 * nonce-less shape, and it works because the renderer emits zero inline event
 * handlers (verified across all six live tenants), so 'unsafe-hashes' is not
 * needed.
 *
 * An empty list is a valid, deliberate policy: no inline script at all.
 */
export function cspForBakedPage(scriptHashes: string[]): string {
  return tenantCsp(scriptHashes);
}

/**
 * Name the Worker that served this response (#44). Both render stacks produce
 * byte-identical pages and the same x-pws-cache header, so `x-pws-worker` is
 * the one thing a smoke can use to prove which Worker answered a hostname.
 * Call after `await next()`. The response is rewrapped first because one from
 * fetch() or a DO stub has immutable headers on workerd.
 */
export function setWorkerHeader(c: Context, name: string): void {
  c.res = new Response(c.res.body, c.res);
  c.res.headers.set('x-pws-worker', name);
}
