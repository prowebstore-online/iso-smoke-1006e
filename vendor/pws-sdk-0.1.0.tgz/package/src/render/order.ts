// Order confirmation page body (post-checkout). Rendered as trusted raw HTML
// injected into the page shell by serveOrderPage. The presence of the
// #pws-order-confirmed element signals CART_SCRIPT to clear the cart.

function esc(s: string): string {
  return String(s ?? '').replace(/[<>"'&]/g, (c) => `&#${c.charCodeAt(0)};`);
}

function formatPrice(cents: number): string {
  return `$${(Number(cents) / 100).toFixed(2)}`;
}

export function renderOrderConfirmation(
  order: { id: string; data: Record<string, unknown> } | null,
): string {
  if (!order) {
    return `<section class="px-6 py-16"><div class="max-w-2xl mx-auto" style="text-align:center">
      <h1 class="text-3xl font-bold mb-4" style="color: var(--color-heading); font-family: var(--font-heading);">Order not found</h1>
      <p style="opacity:.7">We couldn't find that order. <a href="/" style="color: var(--color-primary); text-decoration: underline;">Return home</a></p>
    </div></section>`;
  }
  const d = order.data;
  let lines: Array<{ name: string; price: number; qty: number }> = [];
  try {
    const parsed = JSON.parse(String(d.items ?? '[]'));
    if (Array.isArray(parsed)) lines = parsed;
  } catch {}
  const rows = lines
    .map(
      (l) =>
        `<tr><td style="padding:.5rem .75rem">${esc(l.name)} <span style="opacity:.6">× ${Number(l.qty)}</span></td><td style="padding:.5rem .75rem;text-align:right;font-variant-numeric:tabular-nums">${formatPrice(l.price * l.qty)}</td></tr>`,
    )
    .join('');
  const total = formatPrice(Number(d.total) || 0);
  const ref = esc(String(d.payment_ref ?? order.id.slice(0, 8)));
  const name = d.customer_name ? `, ${esc(String(d.customer_name))}` : '';
  const email = esc(String(d.customer_email ?? 'your email'));
  const status = String(d.status ?? '');
  const payLabel =
    status === 'Paid'
      ? 'Payment confirmed'
      : status === 'Pending'
        ? 'Finalizing payment…'
        : 'Test payment';
  const confirmLine =
    status === 'Pending'
      ? `Your order is being finalized — this page updates once payment clears. A receipt will be sent to ${email}.`
      : `Your order is confirmed. A receipt was sent to ${email}.`;
  // While Pending, the Stripe webhook hasn't marked the order Paid yet — auto-
  // refresh (CSP-safe, no script) until it lands, then stop.
  const pendingRefresh = status === 'Pending' ? '<meta http-equiv="refresh" content="3" />' : '';
  return `${pendingRefresh}
<section class="px-6 py-16" id="pws-order-confirmed">
  <div class="max-w-2xl mx-auto">
    <div style="text-align:center;margin-bottom:2rem">
      <div style="font-size:3rem;line-height:1">✓</div>
      <h1 class="text-3xl font-bold" style="color: var(--color-heading); font-family: var(--font-heading);">Thank you${name}!</h1>
      <p style="opacity:.7;margin-top:.5rem">${confirmLine}</p>
      <p style="opacity:.5;font-size:.85rem;margin-top:.25rem">Order reference: <strong>${ref}</strong> · <span style="color: var(--color-primary)">${payLabel}</span></p>
    </div>
    <div style="background: var(--color-surface); border-radius: var(--radius); padding:1rem 1.25rem">
      <table style="width:100%;border-collapse:collapse">${rows}
        <tr style="border-top:1px solid var(--color-neutral-200,#ddd)"><td style="padding:.75rem;font-weight:600">Total</td><td style="padding:.75rem;text-align:right;font-weight:700;color:var(--color-primary)">${total}</td></tr>
      </table>
    </div>
    <div style="text-align:center;margin-top:2rem">
      <a href="/" style="color: var(--color-primary); text-decoration: underline;">Continue browsing</a>
    </div>
  </div>
</section>`;
}
