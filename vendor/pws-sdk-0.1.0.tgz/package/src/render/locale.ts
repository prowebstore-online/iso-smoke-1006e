// Locale path helpers shared by the page shell and block renderers.

/**
 * Prefix an internal path with the active locale (e.g. /about → /zh-CN/about).
 * Idempotent: a path already carrying the prefix, an external/absolute URL, an
 * anchor, or an internal /_/ asset path is returned unchanged. This matters
 * because localizeBlock already prefixes block link fields, so a block renderer
 * applying this on top must not double-prefix.
 */
export function localizeHref(href: string, prefix: string): string {
  if (!prefix || !href.startsWith('/') || href.startsWith('//') || href.startsWith('/_/')) {
    return href;
  }
  if (href === prefix || href.startsWith(`${prefix}/`)) return href;
  return prefix + (href === '/' ? '' : href);
}
