// Serve a published page: DO render with per-request CSP nonce.
//
// `version` is tracked for cache headers. KV caching is intentionally skipped:
// each response needs a unique CSP nonce, and caching nonce-bearing HTML is
// either an injection risk (placeholder replacement) or requires double-rendering
// (wasteful). The DO's in-memory cache and 60s Cache-Control provide sufficient
// performance for the current scale.

import type { EntityRecord, EntitySchema } from '@pws/shared';
import { parseSessionCookie } from '../admin/cookies.ts';
import type { SiteUser } from '../do/auth.ts';
import { type Env, siteStub } from '../env.ts';
import { renderHtmlHeaders } from './headers.ts';
import { renderLoginPage, renderProfilePage, renderRegisterPage } from './member-pages.tsx';
import { renderOrderConfirmation } from './order.ts';
import { renderPage } from './page.tsx';
import { resolveRecordPage } from './resolve-record-page.ts';

/** Render the order confirmation page for /order/:id (post-checkout). */
export async function serveOrderPage(env: Env, siteId: string, orderId: string): Promise<Response> {
  const stub = siteStub(env, siteId);
  const version = await stub.getVersion();
  const snapshot = await stub.siteSnapshot();
  const order = await stub.getRecord('order', orderId);
  const nonce = crypto.randomUUID();
  const rawHtml = renderOrderConfirmation(order ? { id: order.id, data: order.data } : null);

  const html = await renderPage({
    page: {
      id: 'order',
      slug: '/order',
      title: 'Order Confirmation',
      page_type: 'order',
      blocks: [],
      seo: { noindex: true },
      show_in_nav: false,
      nav_label: null,
      nav_order: 99,
      auth_required: false,
      created_at: '',
      updated_at: '',
    },
    pages: snapshot.pages,
    config: snapshot.config,
    theme: snapshot.theme,
    nav: snapshot.nav,
    footer: snapshot.footer,
    analytics: snapshot.analytics,
    nonce,
    rawHtml,
    fetchEntityRecords: () => ({ records: [], schema: null }),
  });

  return new Response(html, {
    status: order ? 200 : 404,
    headers: renderHtmlHeaders('MISS', version, { nonce }),
  });
}

/** Resolve the current member/user from the session cookie. */
async function resolveVisitor(
  env: Env,
  siteId: string,
  cookieHeader: string | null | undefined,
): Promise<SiteUser | null> {
  const parsed = parseSessionCookie(cookieHeader);
  if (!parsed || parsed.siteId !== siteId) return null;
  const stub = siteStub(env, siteId);
  return stub.resolveSession(parsed.token);
}

export async function serveSitePage(
  env: Env,
  siteId: string,
  pagePath: string,
  request?: Request,
): Promise<Response> {
  const stub = siteStub(env, siteId);
  const version = await stub.getVersion();
  const cookieHeader = request?.headers.get('cookie');

  // ── Member auth routes ─────────────────────────────────────
  if (pagePath === '/login' || pagePath === '/register' || pagePath === '/profile') {
    const snapshot = await stub.siteSnapshot();
    const nonce = crypto.randomUUID();
    const ctx = {
      config: snapshot.config,
      theme: snapshot.theme,
      nav: snapshot.nav,
      footer: snapshot.footer,
      pages: snapshot.pages,
      nonce,
      siteId,
    };

    if (pagePath === '/login') {
      const html = await renderLoginPage(ctx);
      return new Response(html, { headers: renderHtmlHeaders('MISS', version, { nonce }) });
    }
    if (pagePath === '/register') {
      const html = await renderRegisterPage(ctx);
      return new Response(html, { headers: renderHtmlHeaders('MISS', version, { nonce }) });
    }
    if (pagePath === '/profile') {
      const user = await resolveVisitor(env, siteId, cookieHeader);
      if (!user) {
        return new Response(null, { status: 302, headers: { Location: '/login' } });
      }
      const html = await renderProfilePage(ctx, user);
      return new Response(html, { headers: renderHtmlHeaders('MISS', version, { nonce }) });
    }
  }

  const page = await stub.getPage(pagePath);
  if (!page) {
    // Entity detail (/{collection}/{slug}) + category/genre pages — shared resolver.
    const resolved = await resolveRecordPage(stub, pagePath, {
      // Required by ResolveOpts since #36. This is the dead half of the dual render
      // stack (#29 retires it); passing the id already in scope is the minimum to
      // keep it compiling — the rest of #36 was deliberately NOT mirrored here.
      siteId,
      nonce: crypto.randomUUID(),
      version,
      turnstileSiteKey: env.TURNSTILE_SITE_KEY,
    });
    if (resolved) return resolved;

    // Render a styled 404 page using the site's theme.
    const snapshot404 = await stub.siteSnapshot();
    const nonce404 = crypto.randomUUID();
    const notFoundHtml = await renderPage({
      page: {
        id: '404',
        slug: '/404',
        title: 'Page Not Found',
        page_type: 'error',
        blocks: [
          {
            id: 'e404',
            _type: 'hero' as const,
            heading: 'Page not found',
            subheading:
              'The page you were looking for doesn\u2019t exist. It may have been moved or deleted.',
            cta_text: 'Go home',
            cta_url: '/',
            alignment: 'center' as const,
          },
        ],
        seo: null,
        show_in_nav: false,
        nav_label: null,
        nav_order: 99,
        auth_required: false,
        created_at: '',
        updated_at: '',
      },
      pages: snapshot404.pages,
      config: snapshot404.config,
      theme: snapshot404.theme,
      nav: snapshot404.nav,
      footer: snapshot404.footer,
      nonce: nonce404,
      fetchEntityRecords: () => ({ records: [], schema: null }),
    });
    return new Response(notFoundHtml, {
      status: 404,
      headers: renderHtmlHeaders('MISS', version, { nonce: nonce404 }),
    });
  }

  // Auth-gated page check
  if (page.auth_required) {
    const user = await resolveVisitor(env, siteId, cookieHeader);
    if (!user) {
      return new Response(null, {
        status: 302,
        headers: { Location: `/login?redirect=${encodeURIComponent(pagePath)}` },
      });
    }
  }

  const snapshot = await stub.siteSnapshot();

  // Pre-resolve every entity_grid/product_grid block's records up-front (per-request scope).
  const entityCache = new Map<string, { records: EntityRecord[]; schema: EntitySchema | null }>();
  for (const block of page.blocks) {
    if (
      (block._type === 'entity_grid' || block._type === 'product_grid') &&
      !entityCache.has(block.entity)
    ) {
      const [records, schema] = await Promise.all([
        stub.listRecords(block.entity, { limit: block.limit ?? 100 }),
        stub.getSchema(block.entity),
      ]);
      entityCache.set(block.entity, { records, schema });
    }
  }

  // Per-request nonce for CSP — ensures no inline script executes without it.
  const nonce = crypto.randomUUID();

  const html = await renderPage({
    page,
    pages: snapshot.pages,
    config: snapshot.config,
    theme: snapshot.theme,
    nav: snapshot.nav,
    footer: snapshot.footer,
    analytics: snapshot.analytics,
    turnstileSiteKey: env.TURNSTILE_SITE_KEY,
    nonce,
    fetchEntityRecords: (entitySlug) =>
      entityCache.get(entitySlug) ?? { records: [], schema: null },
  });

  return new Response(html, { headers: renderHtmlHeaders('MISS', version, { nonce }) });
}
