/** @jsxRuntime automatic */
/** @jsxImportSource hono/jsx */
// Server-rendered member auth pages (login, register, profile).
// Uses rawHtml injection (not custom_html blocks) to bypass the sanitizer.
// These pages are server-generated, never user-supplied.

import type { FooterConfig, NavConfig, NavPage, Page, SiteConfig, Theme } from '@pws/shared';
import type { SiteUser } from '../do/auth.ts';
import { renderPage } from './page.tsx';

interface MemberPageContext {
  config: SiteConfig;
  theme: Theme;
  nav: NavConfig;
  footer: FooterConfig;
  pages: NavPage[];
  nonce: string;
  error?: string;
  siteId: string;
}

export async function renderLoginPage(ctx: MemberPageContext): Promise<string> {
  const errorHtml = ctx.error
    ? `<div style="background: rgba(239,68,68,0.1); border: 1px solid #ef4444; color: #ef4444; padding: 0.75rem; border-radius: 0.5rem; margin-bottom: 1rem; font-size: 0.9rem;">${esc(ctx.error)}</div>`
    : '';

  const html = `
<section class="px-6 py-16" style="min-height: 60vh; display: flex; align-items: center; justify-content: center;">
  <div style="max-width: 400px; width: 100%;">
    <h1 style="font-family: var(--font-heading); font-size: 1.75rem; margin-bottom: 0.5rem; text-align: center;">Sign In</h1>
    <p style="text-align: center; opacity: 0.7; margin-bottom: 1.5rem;">Access your ${esc(ctx.config.title)} account.</p>
    ${errorHtml}
    <form method="post" action="/login" style="display: flex; flex-direction: column; gap: 1rem;">
      <label style="font-weight: 500; font-size: 0.9rem;">Email
        <input type="email" name="email" required autocomplete="email"
          style="display: block; width: 100%; padding: 0.6rem 0.75rem; margin-top: 0.25rem; border: 1px solid var(--color-neutral-200, #d1d5db); border-radius: var(--radius, 0.5rem); font-size: 1rem; box-sizing: border-box; background: var(--color-surface, #fff); color: var(--color-text);" />
      </label>
      <label style="font-weight: 500; font-size: 0.9rem;">Password
        <input type="password" name="password" required autocomplete="current-password"
          style="display: block; width: 100%; padding: 0.6rem 0.75rem; margin-top: 0.25rem; border: 1px solid var(--color-neutral-200, #d1d5db); border-radius: var(--radius, 0.5rem); font-size: 1rem; box-sizing: border-box; background: var(--color-surface, #fff); color: var(--color-text);" />
      </label>
      <button type="submit"
        style="background: var(--color-primary); color: white; border: none; padding: 0.75rem; border-radius: var(--radius, 0.5rem); font-size: 1rem; font-weight: 600; cursor: pointer;">Sign In</button>
    </form>
    <p style="text-align: center; margin-top: 1rem; font-size: 0.85rem; opacity: 0.7;">
      Don&rsquo;t have an account? <a href="/register" style="color: var(--color-primary); text-decoration: underline;">Sign up</a>
    </p>
  </div>
</section>`;

  return renderPage({
    page: makePseudoPage('/login', 'Sign In'),
    pages: ctx.pages,
    config: ctx.config,
    theme: ctx.theme,
    nav: ctx.nav,
    footer: ctx.footer,
    nonce: ctx.nonce,
    rawHtml: html,
    fetchEntityRecords: () => ({ records: [], schema: null }),
  });
}

export async function renderRegisterPage(ctx: MemberPageContext): Promise<string> {
  const errorHtml = ctx.error
    ? `<div style="background: rgba(239,68,68,0.1); border: 1px solid #ef4444; color: #ef4444; padding: 0.75rem; border-radius: 0.5rem; margin-bottom: 1rem; font-size: 0.9rem;">${esc(ctx.error)}</div>`
    : '';

  const html = `
<section class="px-6 py-16" style="min-height: 60vh; display: flex; align-items: center; justify-content: center;">
  <div style="max-width: 400px; width: 100%;">
    <h1 style="font-family: var(--font-heading); font-size: 1.75rem; margin-bottom: 0.5rem; text-align: center;">Create Account</h1>
    <p style="text-align: center; opacity: 0.7; margin-bottom: 1.5rem;">Join ${esc(ctx.config.title)}.</p>
    ${errorHtml}
    <form method="post" action="/register" style="display: flex; flex-direction: column; gap: 1rem;">
      <label style="font-weight: 500; font-size: 0.9rem;">Name
        <input type="text" name="display_name" required autocomplete="name"
          style="display: block; width: 100%; padding: 0.6rem 0.75rem; margin-top: 0.25rem; border: 1px solid var(--color-neutral-200, #d1d5db); border-radius: var(--radius, 0.5rem); font-size: 1rem; box-sizing: border-box; background: var(--color-surface, #fff); color: var(--color-text);" />
      </label>
      <label style="font-weight: 500; font-size: 0.9rem;">Email
        <input type="email" name="email" required autocomplete="email"
          style="display: block; width: 100%; padding: 0.6rem 0.75rem; margin-top: 0.25rem; border: 1px solid var(--color-neutral-200, #d1d5db); border-radius: var(--radius, 0.5rem); font-size: 1rem; box-sizing: border-box; background: var(--color-surface, #fff); color: var(--color-text);" />
      </label>
      <label style="font-weight: 500; font-size: 0.9rem;">Password
        <input type="password" name="password" required minlength="8" autocomplete="new-password"
          style="display: block; width: 100%; padding: 0.6rem 0.75rem; margin-top: 0.25rem; border: 1px solid var(--color-neutral-200, #d1d5db); border-radius: var(--radius, 0.5rem); font-size: 1rem; box-sizing: border-box; background: var(--color-surface, #fff); color: var(--color-text);" />
      </label>
      <button type="submit"
        style="background: var(--color-primary); color: white; border: none; padding: 0.75rem; border-radius: var(--radius, 0.5rem); font-size: 1rem; font-weight: 600; cursor: pointer;">Create Account</button>
    </form>
    <p style="text-align: center; margin-top: 1rem; font-size: 0.85rem; opacity: 0.7;">
      Already have an account? <a href="/login" style="color: var(--color-primary); text-decoration: underline;">Sign in</a>
    </p>
  </div>
</section>`;

  return renderPage({
    page: makePseudoPage('/register', 'Create Account'),
    pages: ctx.pages,
    config: ctx.config,
    theme: ctx.theme,
    nav: ctx.nav,
    footer: ctx.footer,
    nonce: ctx.nonce,
    rawHtml: html,
    fetchEntityRecords: () => ({ records: [], schema: null }),
  });
}

export async function renderProfilePage(ctx: MemberPageContext, user: SiteUser): Promise<string> {
  const html = `
<section class="px-6 py-16">
  <div style="max-width: 500px; margin: 0 auto;">
    <h1 style="font-family: var(--font-heading); font-size: 1.75rem; margin-bottom: 1.5rem;">Your Profile</h1>
    <div style="background: var(--color-surface, #f8fafc); border: 1px solid var(--color-neutral-200, #e2e8f0); border-radius: var(--radius, 0.5rem); padding: 1.5rem; margin-bottom: 1.5rem;">
      <div style="font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.05em; opacity: 0.6; margin-bottom: 0.25rem;">Email</div>
      <div style="font-size: 1rem; margin-bottom: 1rem;">${esc(user.email)}</div>
      <div style="font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.05em; opacity: 0.6; margin-bottom: 0.25rem;">Name</div>
      <div style="font-size: 1rem; margin-bottom: 1rem;">${esc(user.display_name ?? '\u2014')}</div>
      <div style="font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.05em; opacity: 0.6; margin-bottom: 0.25rem;">Member since</div>
      <div style="font-size: 1rem;">${user.created_at ? new Date(user.created_at).toLocaleDateString() : '\u2014'}</div>
    </div>
    <form method="post" action="/logout">
      <button type="submit"
        style="background: none; border: 1px solid var(--color-neutral-200, #d1d5db); padding: 0.5rem 1rem; border-radius: var(--radius, 0.5rem); font-size: 0.85rem; cursor: pointer; width: 100%; opacity: 0.7; color: var(--color-text);">Sign Out</button>
    </form>
  </div>
</section>`;

  return renderPage({
    page: makePseudoPage('/profile', 'Your Profile'),
    pages: ctx.pages,
    config: ctx.config,
    theme: ctx.theme,
    nav: ctx.nav,
    footer: ctx.footer,
    nonce: ctx.nonce,
    rawHtml: html,
    fetchEntityRecords: () => ({ records: [], schema: null }),
  });
}

function makePseudoPage(slug: string, title: string): Page {
  return {
    id: slug,
    slug,
    title,
    page_type: 'auth',
    blocks: [],
    seo: null,
    show_in_nav: false,
    nav_label: null,
    nav_order: 99,
    auth_required: false,
    created_at: '',
    updated_at: '',
  };
}

function esc(s: string): string {
  return s.replace(/[<>"'&]/g, (c) => `&#${c.charCodeAt(0)};`);
}
