// CSP script hashes for pre-rendered (baked) pages.
//
// A baked page is a byte-identical R2 object served to every visitor, so it
// cannot carry a per-request nonce. That argues for HASHES, not for
// 'unsafe-inline' (#38): the hashes are computed once, when the bytes are
// written, and stored alongside the object in R2 customMetadata. The serve
// path reads them back and builds the policy with cspForBakedPage().
//
// Two properties this file exists to guarantee:
//
//  1. **Byte-exactness.** A sha256 must cover the script element's text content
//     exactly as the browser sees it. ultrahtml treats <script> content as raw
//     text — no entity decoding, no whitespace normalisation — so the extracted
//     string is a literal substring of the HTML (asserted in csp-hashes.test.ts).
//     Always hash the same string that is handed to MEDIA.put, in the same call.
//     Re-deriving it later — a trailing newline, a minifier, an httpMetadata
//     transform — silently kills every inline script on every baked page at once.
//
//  2. **AST, not regex.** Finding <script> with a regex is the same class of
//     mistake as the blocklist that produced #37, so this uses the ultrahtml
//     parser already in the dependency tree for sanitize.ts.
//
// One known divergence from a real HTML tokenizer, measured and pinned in
// csp-hashes.test.ts: ultrahtml ends a start tag at the first `>` even inside a
// quoted attribute value, so `<script data-x="a>b">alert(1)</script>` yields the
// text `b">alert(1)` where a browser executes `alert(1)`. It is documented
// rather than worked around because the divergence is always FAIL-CLOSED — the
// stored hash simply does not match, so the browser blocks the script; it can
// never allow one. And it cannot arise on the bake paths: renderPage emits no
// <script> carrying author-controlled attributes, and the richtext sanitizer's
// 42-tag allowlist contains no script, svg, template, noscript or textarea.

import { ELEMENT_NODE, type Node, TEXT_NODE, type TextNode, parse, walkSync } from 'ultrahtml';

/**
 * R2 caps the sum of all customMetadata keys and values at 2 KB. One hash costs
 * ~55 bytes ("'sha256-' + 44 base64 chars" plus quotes and a separator), so 30
 * distinct inline scripts is ~1.6 KB and leaves headroom. A document with more
 * than that is refused at write time rather than written with a truncated list —
 * a truncated list is a page whose scripts are silently dead.
 */
export const MAX_INLINE_SCRIPT_HASHES = 30;

/**
 * The R2 customMetadata key holding the space-separated CSP source list.
 *
 * Lowercase and hyphenated on purpose. R2 stores custom metadata the way S3
 * does — as `x-amz-meta-<key>` — and HTTP field names are case-insensitive, so a
 * camelCase key can come back normalised. If it ever did, `storedScriptHashes()`
 * would find nothing, every baked page would serve an empty hash list, and the
 * theme IIFE would be dead with no error anywhere: the page still renders, dark
 * mode and the mobile menu just stop. That is #33's symptom exactly, and it went
 * unnoticed on six live sites for eight weeks.
 *
 * This could not be measured from outside a Worker — nothing else in the repo
 * writes customMetadata, and R2's REST API drops `x-amz-meta-*` on upload — so
 * the question is removed instead of answered: an already-lowercase key cannot
 * be lowercased, and the read below is case-insensitive regardless.
 */
export const CSP_HASHES_METADATA_KEY = 'csp-script-hashes';

async function sha256Base64(text: string): Promise<string> {
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
  return btoa(String.fromCharCode(...new Uint8Array(digest)));
}

/**
 * Every inline <script> element's CSP source expression, deduplicated, in
 * document order.
 *
 * Elements with a `src` attribute are skipped — those are external and covered
 * by the host allowlist, not by a hash. `type="application/ld+json"` data blocks
 * ARE hashed: per spec script-src is not enforced against a data block, but
 * hashing costs one digest and removes the question entirely.
 */
export async function inlineScriptHashes(html: string): Promise<string[]> {
  const sources: string[] = [];
  walkSync(parse(html), (node) => {
    if (node.type !== ELEMENT_NODE || node.name !== 'script') return;
    if (node.attributes?.src) return;
    const text = (node.children ?? [])
      .filter((child: Node) => child.type === TEXT_NODE)
      .map((child: Node) => (child as TextNode).value)
      .join('');
    sources.push(text);
  });

  const seen = new Set<string>();
  const hashes: string[] = [];
  for (const text of sources) {
    const source = `'sha256-${await sha256Base64(text)}'`;
    if (seen.has(source)) continue;
    seen.add(source);
    hashes.push(source);
  }
  return hashes;
}

/**
 * R2 customMetadata for a page about to be written to `${siteId}/_static/`.
 *
 * Throws when the document carries more distinct inline scripts than the
 * metadata budget allows. Callers surface that as a write failure: refusing the
 * write is the honest failure direction, because the alternative is a stored
 * page whose scripts the browser will block with no explanation.
 */
export async function bakedPageMetadata(html: string): Promise<Record<string, string>> {
  const hashes = await inlineScriptHashes(html);
  if (hashes.length > MAX_INLINE_SCRIPT_HASHES) {
    throw new Error(
      [
        `Page has ${hashes.length} distinct inline <script> elements; the limit is ${MAX_INLINE_SCRIPT_HASHES}.`,
        'Each one needs a CSP hash stored with the object, and R2 caps object metadata at 2KB.',
        'Move script into an external file.',
      ].join(' '),
    );
  }
  return { [CSP_HASHES_METADATA_KEY]: hashes.join(' ') };
}

/**
 * The stored source list, parsed back out of an R2 object's customMetadata.
 *
 * An object written before this shipped — or by any path that forgot the
 * metadata — yields an EMPTY list, i.e. no inline script runs. That is the
 * correct failure direction, and it is free to adopt: R2 held 0 objects under
 * any `_static/` prefix when #38 landed, so there is no legacy set to grandfather.
 * Do not add a permissive fallback arm here; a permissive fallback arm is
 * precisely the defect #38 fixed.
 */
export function storedScriptHashes(customMetadata?: Record<string, string>): string[] {
  const entry = Object.entries(customMetadata ?? {}).find(
    ([key]) => key.toLowerCase() === CSP_HASHES_METADATA_KEY,
  );
  return (entry?.[1] ?? '').split(' ').filter(Boolean);
}
