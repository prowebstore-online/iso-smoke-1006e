// Shared resolver for "/{collection}/{slug}" requests that don't match a real
// page: entity detail pages and category/genre pages. Both serve stacks (the
// multi-tenant worker and the per-site SDK routes) call this so the logic lives
// ONCE. Returns a Response, or null if the path isn't a resolvable record (caller
// then renders its own 404). See RENDERING.md §1–§2.

import { sellableEntityOf } from '@pws/shared';
import type { SiteRpc } from '../do/rpc.ts';
import { canonicalConfig } from './canonical.ts';
import { renderHtmlHeaders } from './headers.ts';
import { renderPage } from './page.tsx';
import { renderRecordDetailBody } from './record-detail.tsx';

interface ResolveOpts {
  /** Owning site id — canonicalises the render to the tenant's own host (#36). */
  siteId: string;
  locale?: string;
  nonce: string;
  version: number;
  turnstileSiteKey?: string;
}

export async function resolveRecordPage(
  stub: SiteRpc,
  pagePath: string,
  opts: ResolveOpts,
): Promise<Response | null> {
  const segments = pagePath.split('/').filter(Boolean);
  if (segments.length !== 2) return null;
  const [collection, recordSlug] = segments;

  const schemas = await stub.listSchemas();
  const schema = schemas.find(
    (s) => s.slug === collection || s.name_plural.toLowerCase().replace(/\s+/g, '-') === collection,
  );
  if (!schema) return null;

  if (!recordSlug) return null;
  const record = await stub.getRecordBySlug(schema.slug, recordSlug);
  if (!record) return null;

  const { nonce, version, locale } = opts;
  const snapshot = await stub.siteSnapshot();
  const sellable = sellableEntityOf(snapshot.config);
  const translations = locale ? await stub.getTranslations(locale) : undefined;
  const defaultLocale = snapshot.config.locale ?? 'en';
  const localePrefix = locale && locale !== defaultLocale ? `/${locale}` : '';
  const allLocales = await stub.listTranslationLocales();
  const availableLocales = allLocales.length
    ? [defaultLocale, ...allLocales.map((l) => l.locale)]
    : undefined;

  const headers = renderHtmlHeaders('MISS', version, { nonce });

  // Category/genre → list that genre's works through the full page pipeline.
  if (schema.slug === 'category') {
    const [products, productSchema] = await Promise.all([
      stub.listRecords(sellable, { limit: 500 }),
      stub.getSchema(sellable),
    ]);
    const catName = String(record.data.name ?? 'Genre');
    const html = await renderPage({
      page: {
        id: 'category',
        slug: `/category/${record.slug}`,
        title: catName,
        page_type: 'category',
        blocks: [
          {
            id: 'cat-hero',
            _type: 'hero',
            heading: catName,
            subheading: String(record.data.description ?? ''),
            alignment: 'left',
          },
          {
            id: 'cat-grid',
            _type: 'product_grid',
            entity: sellable,
            filter: { category: record.id },
            image_fit: 'contain',
            columns: 3,
            cart_url: '/cart',
          },
        ],
        seo: { noindex: false },
        show_in_nav: false,
        nav_label: null,
        nav_order: 99,
        auth_required: false,
        created_at: '',
        updated_at: '',
      },
      pages: snapshot.pages,
      config: canonicalConfig(snapshot.config, opts.siteId),
      theme: snapshot.theme,
      nav: snapshot.nav,
      footer: snapshot.footer,
      analytics: snapshot.analytics,
      turnstileSiteKey: opts.turnstileSiteKey,
      nonce,
      locale,
      translations,
      availableLocales,
      fetchEntityRecords: (entitySlug) =>
        entitySlug === sellable
          ? { records: products, schema: productSchema }
          : { records: [], schema: null },
    });
    return new Response(html, { headers });
  }

  // Record detail → standard page shell + the field body as main content.
  const detailTitle = String(record.data.title ?? record.data.name ?? record.slug ?? schema.name);
  const detailDesc = String(record.data.description ?? '')
    .replace(/<[^>]*>/g, '')
    .trim();
  const detailImg = record.data.image as { asset_id?: string } | null | undefined;
  const extraJsonLd =
    schema.slug === sellable
      ? {
          '@type': 'Product',
          name: detailTitle,
          description: detailDesc || undefined,
          image: detailImg?.asset_id ? `/_/img/${detailImg.asset_id}` : undefined,
          offers: record.data.price
            ? { '@type': 'Offer', price: record.data.price, priceCurrency: 'AUD' }
            : undefined,
        }
      : undefined;

  const html = await renderPage({
    page: {
      id: 'detail',
      slug: `/${schema.slug}/${record.slug}`,
      title: detailTitle,
      page_type: 'product',
      blocks: [],
      seo: { noindex: false, description: detailDesc.slice(0, 160) || undefined },
      show_in_nav: false,
      nav_label: null,
      nav_order: 99,
      auth_required: false,
      created_at: '',
      updated_at: '',
    },
    pages: snapshot.pages,
    config: canonicalConfig(snapshot.config, opts.siteId),
    theme: snapshot.theme,
    nav: snapshot.nav,
    footer: snapshot.footer,
    analytics: snapshot.analytics,
    turnstileSiteKey: opts.turnstileSiteKey,
    nonce,
    locale,
    translations,
    availableLocales,
    extraJsonLd,
    rawHtml: renderRecordDetailBody({
      record,
      schema,
      translations,
      localePrefix,
      sellableEntity: sellable,
    }),
    fetchEntityRecords: () => ({ records: [], schema: null }),
  });
  return new Response(html, { headers });
}
