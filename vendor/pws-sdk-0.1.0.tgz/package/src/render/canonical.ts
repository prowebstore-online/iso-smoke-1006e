// Canonical hostname for a tenant render.
//
// page.tsx reads `config.primary_hostname` for <link rel=canonical>, og:url and
// the hreflang set, and falls back to the marketing apex when it is unset.
// Nothing in provisioning ever sets it — it is written only when an owner asks
// the assistant to configure a custom domain — so the fallback was not an edge
// case but the default state of every site: 5 of 6 live tenants told search
// engines their canonical URL was https://prowebstore.online, contradicting
// their own sitemap (which is built from the request host and is correct) and
// pointing crawlers at the vendor's homepage or a 404. See #36.
//
// renderPage has neither a site id nor a request, so it cannot derive this
// itself; every caller has the site id, so the fix belongs at the callers.
//
// The site id — not the request Host header — is the source. Host is
// attacker-supplied in principle, and baking it into the one tag whose job is to
// be authoritative is textbook canonical poisoning. The site id is trusted state
// the route classifier already resolved, always resolves to a real page, and can
// never name a different tenant. (The sitemap's use of Host is defensible because
// it is self-referential; rel=canonical is not.)

import type { SiteConfig } from '@pws/shared';

/** The apex that tenant subdomains hang off. */
export const TENANT_APEX = 'prowebstore.online';

/** Default a site's canonical hostname to its own subdomain. A configured
 *  `primary_hostname` (i.e. a real custom domain) always wins. */
export function canonicalConfig(config: SiteConfig, siteId: string): SiteConfig {
  return config.primary_hostname
    ? config
    : { ...config, primary_hostname: `${siteId}.${TENANT_APEX}` };
}
