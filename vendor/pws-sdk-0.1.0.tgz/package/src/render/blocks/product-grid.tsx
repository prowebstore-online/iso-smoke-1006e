/** @jsxRuntime automatic */
/** @jsxImportSource hono/jsx */
// ProductGrid: renders product entity records with "Add to Cart" buttons.
// Cart state lives in localStorage — no backend needed.
// Tile styling lives in PRODUCT_TILE_CSS (page.tsx base styles); the look adapts
// to the site theme (radius/shadow vars) so it reads gallery-flat or shop-soft.

import type { EntityRecord, EntitySchema, ImageValue, ProductGridBlock, Theme } from '@pws/shared';

interface Props {
  block: ProductGridBlock;
  records: EntityRecord[];
  schema: EntitySchema;
  theme: Theme;
  localePrefix?: string;
  translations?: Record<string, string>;
}

export function ProductGrid({ block, records, localePrefix = '', translations }: Props) {
  const tr = (s: string) => translations?.[s] ?? s;
  const columns = clampColumns(block.columns ?? 3);
  const fit = block.image_fit ?? 'cover';
  // 'contain' (art) uses a natural-aspect masonry so paintings are never cropped
  // and never letterboxed in a fixed frame. 'cover' (products) uses a tidy grid.
  const masonry = fit === 'contain';
  const gridClass =
    columns === 2
      ? 'grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-12'
      : columns === 4
        ? 'grid grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-10'
        : 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-12';

  return (
    <section class="px-6 py-16">
      <div class="max-w-6xl mx-auto">
        {block.heading && (
          <h2
            class="text-3xl font-semibold mb-10"
            style="color: var(--color-heading); font-family: var(--font-heading); letter-spacing: -0.01em;"
          >
            {block.heading}
          </h2>
        )}
        {records.length === 0 ? (
          <p class="opacity-60" style="color: var(--color-text);">
            Nothing here yet.
          </p>
        ) : masonry ? (
          <div class={`pws-masonry pws-masonry-${columns}`}>
            {records.map((record) => (
              <ProductCard
                key={record.id}
                record={record}
                fit={fit}
                masonry
                localePrefix={localePrefix}
                addLabel={tr('Add to Cart')}
                soldLabel={tr('Sold')}
              />
            ))}
          </div>
        ) : (
          <ul class={gridClass}>
            {records.map((record) => (
              <ProductCard
                key={record.id}
                record={record}
                fit={fit}
                masonry={false}
                localePrefix={localePrefix}
                addLabel={tr('Add to Cart')}
                soldLabel={tr('Sold')}
              />
            ))}
          </ul>
        )}
      </div>
    </section>
  );
}

function ProductCard({
  record,
  fit,
  masonry,
  localePrefix = '',
  addLabel = 'Add to Cart',
  soldLabel = 'Sold',
}: {
  record: EntityRecord;
  fit: 'cover' | 'contain';
  masonry: boolean;
  localePrefix?: string;
  addLabel?: string;
  soldLabel?: string;
}) {
  const d = record.data;
  const name = String(d.name ?? d.title ?? 'Untitled');
  const price = typeof d.price === 'number' ? d.price : 0;
  const salePrice = typeof d.sale_price === 'number' ? d.sale_price : null;
  // Out of stock when the manual flag is false OR tracked stock is depleted.
  const inStock = d.in_stock !== false && (typeof d.stock !== 'number' || d.stock > 0);
  const image = d.image as ImageValue | null | undefined;
  const detailUrl = record.slug
    ? `${localePrefix}/${record.entity_slug}/${record.slug}`
    : undefined;
  // Gallery-friendly subtitles: surfaced only when the record has them (harmless elsewhere).
  const artist = typeof d.artist === 'string' && d.artist ? d.artist : '';
  const dims = typeof d.dimensions === 'string' && d.dimensions ? d.dimensions : '';

  const displayPrice = salePrice != null && salePrice < price ? salePrice : price;
  const hasDiscount = salePrice != null && salePrice < price;

  const frameClass = masonry ? 'pws-tile-frame-natural' : `pws-tile-frame pws-fit-${fit}`;
  const frame = (
    <div class={frameClass}>
      {image ? (
        <img
          src={`/_/img/${image.asset_id}?w=800`}
          alt={image.alt || name}
          loading="lazy"
          decoding="async"
        />
      ) : (
        <div class="pws-tile-noimg" />
      )}
    </div>
  );

  const inner = (
    <>
      {detailUrl ? (
        <a href={detailUrl} style="display:block; text-decoration:none; color:inherit;">
          {frame}
        </a>
      ) : (
        frame
      )}
      <div class="pws-tile-meta">
        <h3 class="pws-tile-title">
          {detailUrl ? (
            <a href={detailUrl} style="text-decoration:none; color:inherit;">
              {name}
            </a>
          ) : (
            name
          )}
        </h3>
        {artist && <p class="pws-tile-artist">{artist}</p>}
        {dims && <p class="pws-tile-dim">{dims}</p>}
        <div class="pws-tile-row">
          <span class="pws-tile-price">
            ${formatPrice(displayPrice)}
            {hasDiscount && <span class="pws-tile-was">${formatPrice(price)}</span>}
          </span>
          {inStock ? (
            <button
              type="button"
              class="pws-add-to-cart pws-tile-add"
              data-product-id={record.id}
              data-product-name={name}
              data-product-price={String(displayPrice)}
              data-product-image={image?.asset_id ?? ''}
            >
              {addLabel}
            </button>
          ) : (
            <span class="pws-tile-sold">{soldLabel}</span>
          )}
        </div>
      </div>
    </>
  );

  return masonry ? (
    <div class="pws-product-tile pws-masonry-item">{inner}</div>
  ) : (
    <li class="pws-product-tile">{inner}</li>
  );
}

function formatPrice(cents: number): string {
  return (cents / 100).toFixed(2);
}

function clampColumns(n: number): 2 | 3 | 4 {
  if (n <= 2) return 2;
  if (n >= 4) return 4;
  return 3;
}
