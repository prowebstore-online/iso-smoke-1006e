/** @jsxRuntime automatic */
/** @jsxImportSource hono/jsx */
import type { FeaturesBlock, Theme } from '@pws/shared';

export function Features({ block }: { block: FeaturesBlock; theme: Theme }) {
  const variant = block.variant ?? '3col';
  const iconLeft = variant === 'icon-left';

  return (
    <section class="px-6 py-12">
      <div class="max-w-6xl mx-auto">
        {block.heading && (
          <h2
            class="text-3xl font-bold text-center"
            style="color: var(--color-heading); font-family: var(--font-heading);"
          >
            {block.heading}
          </h2>
        )}
        {block.subheading && (
          <p
            class="mt-3 text-lg text-center"
            style="color: var(--color-text); font-family: var(--font-body);"
          >
            {block.subheading}
          </p>
        )}
        <div class={iconLeft ? 'mt-10 space-y-8' : 'mt-10 grid grid-cols-1 md:grid-cols-3 gap-8'}>
          {block.items.map((item) => (
            <div key={item.title} class={iconLeft ? 'flex items-start gap-4' : 'text-center'}>
              {item.icon && (
                <div
                  class={`inline-flex items-center justify-center w-12 h-12 rounded-full ${iconLeft ? 'shrink-0' : 'mx-auto'}`}
                  style="background-color: var(--color-primary); color: white;"
                >
                  <span class="text-xl">{item.icon}</span>
                </div>
              )}
              <div>
                <h3
                  class="mt-4 text-lg font-semibold"
                  style="color: var(--color-heading); font-family: var(--font-heading);"
                >
                  {item.title}
                </h3>
                <p
                  class="mt-2 text-sm"
                  style="color: var(--color-text); font-family: var(--font-body);"
                >
                  {item.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
