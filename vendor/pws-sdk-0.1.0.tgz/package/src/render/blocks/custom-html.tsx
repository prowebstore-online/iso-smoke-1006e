/** @jsxRuntime automatic */
/** @jsxImportSource hono/jsx */
import type { CustomHtmlBlock, Theme } from '@pws/shared';
import { raw } from 'hono/html';
import { sanitizeHtml } from '../sanitize.ts';

export function CustomHtml({ block }: { block: CustomHtmlBlock; theme: Theme }) {
  return (
    <section class="px-6 py-12">
      <div class="max-w-5xl mx-auto">{raw(sanitizeHtml(block.html))}</div>
    </section>
  );
}
