/** @jsxRuntime automatic */
/** @jsxImportSource hono/jsx */
// Cart block: renders a container populated by client-side JS from localStorage.
// The actual cart logic is injected by page.tsx as a nonce-protected script.

import type { CartBlock, Theme } from '@pws/shared';
import { localizeHref } from '../locale.ts';

interface Props {
  block: CartBlock;
  theme: Theme;
  translations?: Record<string, string>;
  localePrefix?: string;
}

export function Cart({ block, translations, localePrefix = '' }: Props) {
  const tr = (s: string) => translations?.[s] ?? s;
  const heading = tr(block.heading ?? 'Your Cart');
  const emptyMsg = tr(block.empty_message ?? 'Your cart is empty.');
  const checkoutText = tr(block.checkout_text ?? 'Proceed to Checkout');
  // localizeBlock already prefixes link fields it finds; localizeHref is
  // idempotent so defaults (which it never saw) get prefixed without
  // double-prefixing fields the block set explicitly.
  const shopUrl = localizeHref(block.continue_shopping_url ?? '/shop', localePrefix);
  const checkoutUrl = localizeHref(block.checkout_url ?? '/checkout', localePrefix);
  const continueLabel = tr('Continue Shopping');
  const totalLabel = tr('Total');

  return (
    <section class="px-6 py-12">
      <div class="max-w-3xl mx-auto">
        <h2
          class="text-3xl font-bold mb-8"
          style="color: var(--color-heading); font-family: var(--font-heading);"
        >
          {heading}
        </h2>

        {/* Empty state — hidden by JS when cart has items */}
        <div id="pws-cart-empty">
          <p class="mb-4" style="color: var(--color-text); opacity: 0.6;">
            {emptyMsg}
          </p>
          <a
            href={shopUrl}
            class="inline-block py-2 px-6 text-sm font-medium"
            style="background: var(--color-primary); color: #fff; border-radius: var(--radius); text-decoration: none;"
          >
            {continueLabel}
          </a>
        </div>

        {/* Cart items — populated by JS */}
        <div id="pws-cart-items" style="display: none;">
          <div id="pws-cart-list" style="border-top: 1px solid var(--color-neutral-200);" />

          {/* Totals */}
          <div
            class="flex justify-between items-center py-4 mt-4"
            style="border-top: 2px solid var(--color-heading);"
          >
            <span class="text-lg font-semibold" style="color: var(--color-heading);">
              {totalLabel}
            </span>
            <span
              id="pws-cart-total"
              class="text-xl font-bold"
              style="color: var(--color-primary);"
            />
          </div>

          {/* Actions */}
          <div class="flex gap-3 mt-6 flex-wrap">
            <button
              type="button"
              id="pws-checkout-btn"
              class="py-3 px-8 text-sm font-medium"
              style="background: var(--color-primary); color: #fff; border: none; border-radius: var(--radius); cursor: pointer; font-size: 1rem;"
              data-checkout-text={checkoutText}
              data-checkout-url={checkoutUrl}
            >
              {checkoutText}
            </button>
            <a
              href={shopUrl}
              class="py-3 px-8 text-sm font-medium"
              style="border: 1px solid var(--color-neutral-200); border-radius: var(--radius); text-decoration: none; color: var(--color-text); font-size: 1rem; display: inline-flex; align-items: center;"
            >
              {continueLabel}
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
