/** @jsxRuntime automatic */
/** @jsxImportSource hono/jsx */
import type { TeamBlock, Theme } from '@pws/shared';

export function Team({ block }: { block: TeamBlock; theme: Theme }) {
  const variant = block.variant ?? 'grid';
  const isCards = variant === 'cards';

  return (
    <section class="px-6 py-12">
      <div class="max-w-6xl mx-auto">
        {block.heading && (
          <h2
            class="text-3xl font-bold text-center mb-10"
            style="color: var(--color-heading); font-family: var(--font-heading);"
          >
            {block.heading}
          </h2>
        )}
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {block.members.map((member) => (
            <div
              key={member.name}
              class={isCards ? 'p-6' : 'text-center'}
              style={
                isCards
                  ? 'background-color: var(--color-surface); border-radius: var(--radius); box-shadow: var(--shadow);'
                  : ''
              }
            >
              {member.image && (
                <img
                  src={`/_/img/${member.image.asset_id}`}
                  alt={member.image.alt}
                  loading="lazy"
                  class={
                    isCards
                      ? 'w-full h-48 object-cover mb-4'
                      : 'w-24 h-24 rounded-full mx-auto object-cover'
                  }
                  style={isCards ? `border-radius: var(--radius);` : ''}
                />
              )}
              <h3
                class="mt-3 font-semibold"
                style="color: var(--color-heading); font-family: var(--font-heading);"
              >
                {member.name}
              </h3>
              <p class="text-sm" style="color: var(--color-text); opacity: 0.8;">
                {member.role}
              </p>
              {member.bio && (
                <p
                  class="mt-2 text-sm"
                  style="color: var(--color-text); font-family: var(--font-body);"
                >
                  {member.bio}
                </p>
              )}
              {member.social && Object.keys(member.social).length > 0 && (
                <div class="mt-3 flex gap-3 justify-center">
                  {Object.entries(member.social).map(([platform, url]) => (
                    <a
                      key={platform}
                      href={url}
                      class="text-sm underline"
                      style="color: var(--color-primary);"
                    >
                      {platform}
                    </a>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
