/** @jsxRuntime automatic */
/** @jsxImportSource hono/jsx */
import type { GalleryBlock, Theme } from '@pws/shared';

export function Gallery({ block }: { block: GalleryBlock; theme: Theme }) {
  return (
    <section class="px-6 py-12">
      <div class="max-w-6xl mx-auto">
        {block.heading && (
          <h2
            class="text-3xl font-bold text-center mb-10"
            style="color: var(--color-heading); font-family: var(--font-heading);"
          >
            {block.heading}
          </h2>
        )}
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {block.images.map((img) => (
            <figure key={img.url}>
              <img
                src={img.url}
                alt={img.alt}
                loading="lazy"
                class="w-full h-auto object-cover"
                style="border-radius: var(--radius);"
              />
              {img.caption && (
                <figcaption
                  class="mt-2 text-sm text-center"
                  style="color: var(--color-text); opacity: 0.7;"
                >
                  {img.caption}
                </figcaption>
              )}
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}
