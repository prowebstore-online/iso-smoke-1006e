/** @jsxRuntime automatic */
/** @jsxImportSource hono/jsx */
import type { TestimonialsBlock, Theme } from '@pws/shared';

function renderStars(rating: number): string {
  return '★'.repeat(rating) + '☆'.repeat(5 - rating);
}

export function Testimonials({ block }: { block: TestimonialsBlock; theme: Theme }) {
  const variant = block.variant ?? 'cards';
  const items = variant === 'single' ? block.items.slice(0, 1) : block.items;

  return (
    <section class="px-6 py-12">
      <div class="max-w-5xl mx-auto">
        {block.heading && (
          <h2
            class="text-3xl font-bold text-center mb-10"
            style="color: var(--color-heading); font-family: var(--font-heading);"
          >
            {block.heading}
          </h2>
        )}
        <div
          class={
            variant === 'single'
              ? 'max-w-2xl mx-auto'
              : 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6'
          }
        >
          {items.map((item) => (
            <blockquote
              key={item.author}
              class="p-6"
              style="background-color: var(--color-surface); border-radius: var(--radius); box-shadow: var(--shadow);"
            >
              {item.rating && (
                <div class="mb-2 text-lg" style="color: var(--color-primary);">
                  {renderStars(item.rating)}
                </div>
              )}
              <p
                class={`italic ${variant === 'single' ? 'text-xl' : ''}`}
                style="color: var(--color-text); font-family: var(--font-body);"
              >
                "{item.quote}"
              </p>
              <footer class="mt-4 flex items-center gap-3">
                {item.avatar && (
                  <img
                    src={`/_/img/${item.avatar.asset_id}`}
                    alt={item.avatar.alt}
                    class="w-10 h-10 rounded-full object-cover"
                    loading="lazy"
                  />
                )}
                <div>
                  <cite
                    class="not-italic font-semibold text-sm"
                    style="color: var(--color-heading);"
                  >
                    {item.author}
                  </cite>
                  {item.role && (
                    <p class="text-xs" style="color: var(--color-text); opacity: 0.7;">
                      {item.role}
                    </p>
                  )}
                </div>
              </footer>
            </blockquote>
          ))}
        </div>
      </div>
    </section>
  );
}
