/** @jsxRuntime automatic */
/** @jsxImportSource hono/jsx */
import type { RichTextBlock, Theme } from '@pws/shared';
import { raw } from 'hono/html';
import { sanitizeHtml } from '../sanitize.ts';

export function RichText({ block }: { block: RichTextBlock; theme: Theme }) {
  const variant = block.variant ?? 'standard';
  const widthClass =
    variant === 'narrow' ? 'max-w-2xl' : variant === 'wide' ? 'max-w-5xl' : 'max-w-3xl';

  return (
    <section class="px-6 py-12">
      <div
        class={`${widthClass} mx-auto prose`}
        style="color: var(--color-text); font-family: var(--font-body);"
      >
        {raw(sanitizeHtml(block.body))}
      </div>
    </section>
  );
}
