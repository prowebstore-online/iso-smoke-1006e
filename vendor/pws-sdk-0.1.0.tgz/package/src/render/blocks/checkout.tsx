/** @jsxRuntime automatic */
/** @jsxImportSource hono/jsx */
// Checkout block: order summary + shipping details, then hand off to payment.
// The summary + hidden cart payload are populated client-side by CART_SCRIPT
// from localStorage. Submitting POSTs to /_/checkout, where the server re-prices
// every line against the product records (client prices are ignored), writes the
// `order`, and — when Stripe is configured — 303-redirects to a hosted Stripe
// Checkout Session (card is collected there, not on this page). Without Stripe it
// falls back to an instant mock confirmation.

import type { CheckoutBlock, Theme } from '@pws/shared';
import { localizeHref } from '../locale.ts';

interface Props {
  block: CheckoutBlock;
  theme: Theme;
  translations?: Record<string, string>;
  localePrefix?: string;
}

export function Checkout({ block, translations, localePrefix = '' }: Props) {
  const tr = (s: string) => translations?.[s] ?? s;
  const heading = tr(block.heading ?? 'Checkout');
  // Idempotent: avoids double-prefixing a continue_shopping_url that
  // localizeBlock already localized, while still prefixing the default.
  const shopUrl = localizeHref(block.continue_shopping_url ?? '/', localePrefix);

  return (
    <section class="px-6 py-12">
      <div class="max-w-2xl mx-auto">
        <h1
          class="text-3xl font-bold mb-8"
          style="color: var(--color-heading); font-family: var(--font-heading);"
        >
          {heading}
        </h1>

        {/* Empty state — shown by JS when the cart is empty */}
        <div id="pws-checkout-empty" style="display: none;">
          <p class="mb-4" style="color: var(--color-text); opacity: 0.6;">
            {tr('Your cart is empty.')}
          </p>
          <a href={shopUrl} style="color: var(--color-primary); text-decoration: underline;">
            {tr('Continue browsing')}
          </a>
        </div>

        {/* Body — populated + revealed by JS */}
        <div id="pws-checkout-body" style="display: none;">
          <div
            id="pws-checkout-items"
            class="mb-2"
            style="border-top: 1px solid var(--color-neutral-200);"
          />
          <div
            class="flex justify-between items-center py-4 mb-6"
            style="border-top: 2px solid var(--color-heading); font-weight: 700;"
          >
            <span style="color: var(--color-heading);">{tr('Total')}</span>
            <span
              id="pws-checkout-total"
              style="color: var(--color-primary); font-size: 1.25rem;"
            />
          </div>

          <form id="pws-checkout-form" method="post" action="/_/checkout">
            <input type="hidden" name="cart" id="pws-cart-input" value="" />

            <h2
              class="text-lg font-semibold mb-3"
              style="color: var(--color-heading); font-family: var(--font-heading);"
            >
              {tr('Shipping details')}
            </h2>
            <div class="flex flex-col gap-3 mb-6">
              <input
                type="text"
                name="name"
                required
                placeholder={tr('Full name')}
                style={inputStyle}
              />
              <input
                type="email"
                name="email"
                required
                placeholder={tr('Email')}
                style={inputStyle}
              />
              <textarea
                name="address"
                rows={3}
                required
                placeholder={tr('Shipping address')}
                style={inputStyle}
              />
            </div>

            <h2
              class="text-lg font-semibold mb-1"
              style="color: var(--color-heading); font-family: var(--font-heading);"
            >
              {tr('Payment')}
            </h2>
            <p class="mb-6" style="font-size: 0.8rem; opacity: 0.7;">
              {tr('You’ll complete payment securely on the next step.')}
            </p>

            <button
              type="submit"
              class="w-full py-3 px-8 font-medium"
              style="background: var(--color-primary); color: #fff; border: none; border-radius: var(--radius); cursor: pointer; font-size: 1rem;"
            >
              {tr('Pay')} <span id="pws-co-pay-amt" />
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}

const inputStyle =
  'padding: 0.65rem 0.8rem; border: 1px solid var(--color-neutral-200); border-radius: var(--radius); background: var(--color-background); color: var(--color-text); font-family: inherit; font-size: 1rem; width: 100%; box-sizing: border-box;';
