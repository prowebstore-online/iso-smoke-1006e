/** @jsxRuntime automatic */
/** @jsxImportSource hono/jsx */
import type { CtaBlock, Theme } from '@pws/shared';

export function Cta({ block }: { block: CtaBlock; theme: Theme }) {
  const variant = block.variant ?? 'banner';
  const split = variant === 'split';

  return (
    <section
      class="px-6 py-16"
      style={`background-color: ${block.bg_color || 'var(--color-primary)'}; color: white;`}
    >
      <div
        class={`max-w-5xl mx-auto ${split ? 'flex items-center gap-8 flex-wrap' : 'text-center'}`}
      >
        <div class={split ? 'flex-1' : ''}>
          <h2 class="text-3xl md:text-4xl font-bold" style="font-family: var(--font-heading);">
            {block.heading}
          </h2>
          {block.text && (
            <p class="mt-4 text-lg opacity-90" style="font-family: var(--font-body);">
              {block.text}
            </p>
          )}
        </div>
        <div class={split ? '' : 'mt-8'}>
          <a
            href={block.cta_url}
            class="inline-block px-8 py-3 font-medium"
            style="background-color: white; color: var(--color-primary); border-radius: var(--radius); box-shadow: var(--shadow);"
          >
            {block.cta_text}
          </a>
        </div>
      </div>
    </section>
  );
}
