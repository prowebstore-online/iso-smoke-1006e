/** @jsxRuntime automatic */
/** @jsxImportSource hono/jsx */
// EntityGrid: queries entity records and renders them with smart field-type mapping.
// Fully generic — handles any entity type defined in the site's schema.

import type {
  EntityGridBlock,
  EntityRecord,
  EntitySchema,
  FieldDef,
  ImageValue,
  Theme,
} from '@pws/shared';
import { safeHref } from '../sanitize.ts';

interface Props {
  block: EntityGridBlock;
  records: EntityRecord[];
  schema: EntitySchema;
  theme: Theme;
  translations?: Record<string, string>;
  localePrefix?: string;
}

// Entities where a name-initial monogram reads as an avatar (people), vs ones
// where a single letter just looks like an empty placeholder (categories etc.).
const PERSON_LIKE = new Set(['artist', 'person', 'team', 'author', 'member', 'staff']);

export function EntityGrid({ block, records, schema, translations, localePrefix = '' }: Props) {
  const tr = (s: string) => translations?.[s] ?? s;
  const layout = block.layout ?? 'grid';
  const columns = clampColumns(block.columns ?? (layout === 'compact' ? 2 : 3));
  const gridClass =
    layout === 'compact'
      ? 'grid grid-cols-1 md:grid-cols-2 gap-4'
      : columns === 2
        ? 'grid grid-cols-1 md:grid-cols-2 gap-6'
        : columns === 4
          ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6'
          : 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6';

  return (
    <section class="px-6 py-12">
      <div class="max-w-6xl mx-auto">
        {block.heading && (
          <h2
            class="text-3xl font-bold mb-8"
            style="color: var(--color-heading); font-family: var(--font-heading);"
          >
            {tr(block.heading)}
          </h2>
        )}
        {records.length === 0 ? (
          <p class="opacity-60" style="color: var(--color-text);">
            No {schema.name_plural.toLowerCase()} yet.
          </p>
        ) : (
          <ul class={gridClass}>
            {records.map((record) => {
              const detailUrl = record.slug
                ? `${localePrefix}/${schema.slug}/${record.slug}`
                : undefined;
              const card = (
                <RecordCard
                  record={record}
                  schema={schema}
                  displayFields={block.display_fields}
                  translations={translations}
                  allowMonogram={PERSON_LIKE.has(schema.slug)}
                />
              );
              return (
                <li
                  key={record.id}
                  class="overflow-hidden"
                  style={`background-color: var(--color-surface); border-radius: var(--radius); box-shadow: var(--shadow);${detailUrl ? ' cursor: pointer;' : ''}`}
                >
                  {detailUrl ? (
                    <a
                      href={detailUrl}
                      style="text-decoration: none; color: inherit; display: block;"
                    >
                      {card}
                    </a>
                  ) : (
                    card
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </section>
  );
}

function RecordCard({
  record,
  schema,
  displayFields,
  translations,
  allowMonogram,
}: {
  record: EntityRecord;
  schema: EntitySchema;
  displayFields: string[];
  translations?: Record<string, string>;
  allowMonogram?: boolean;
}) {
  const fieldsBySlug = new Map(schema.fields.map((f) => [f.slug, f]));
  // Monogram fallback: when a person-like card is meant to show an image but the
  // record has none (e.g. an artist with no headshot), render an initial avatar.
  // Skipped for categories/genres, where a lone letter reads as a placeholder.
  const missingImage =
    allowMonogram &&
    displayFields.some((s) => {
      const f = fieldsBySlug.get(s);
      return f?.type === 'image' && !record.data[s];
    });
  const cardTitle = String(record.data.name ?? record.data.title ?? '').trim();
  const initial = cardTitle ? cardTitle[0] : '';
  return (
    <article class="p-4">
      {missingImage && initial && (
        <div class="pws-monogram" aria-hidden="true">
          {initial}
        </div>
      )}
      {displayFields.map((slug) => {
        const field = fieldsBySlug.get(slug);
        if (!field) return null;
        const value = record.data[slug];
        if (value === null || value === undefined) return null;
        return <FieldValue key={slug} field={field} value={value} translations={translations} />;
      })}
    </article>
  );
}

function FieldValue({
  field,
  value,
  translations,
}: { field: FieldDef; value: unknown; translations?: Record<string, string> }) {
  const tr = (s: string) => translations?.[s] ?? s;
  switch (field.type) {
    case 'image': {
      const img = value as ImageValue;
      return (
        <img
          src={`/_/img/${img.asset_id}?w=700`}
          alt={img.alt}
          loading="lazy"
          class="w-full h-48 object-cover mb-3"
          style="border-radius: var(--radius);"
        />
      );
    }
    case 'text':
      // Text fields named "name"/"title" rendered as headings.
      if (field.slug === 'name' || field.slug === 'title') {
        return (
          <h3
            class="text-lg font-semibold mb-1"
            style="color: var(--color-heading); font-family: var(--font-heading);"
          >
            {tr(String(value))}
          </h3>
        );
      }
      return <p style="color: var(--color-text);">{tr(String(value))}</p>;
    case 'number': {
      // Numbers in a "price"-named field rendered as currency cents.
      const looksLikePrice = /price|cost|amount/.test(field.slug);
      const display = looksLikePrice ? `$${(Number(value) / 100).toFixed(2)}` : String(value);
      return (
        <p
          class="font-medium"
          style={`color: var(--color-${looksLikePrice ? 'primary' : 'text'});`}
        >
          {display}
        </p>
      );
    }
    case 'boolean':
      return value ? (
        <span
          class="inline-block px-2 py-0.5 text-xs"
          style="background-color: var(--color-primary); color: white; border-radius: var(--radius);"
        >
          {field.name}
        </span>
      ) : null;
    case 'multiselect':
      return Array.isArray(value) ? (
        <div class="flex flex-wrap gap-1 mt-1">
          {(value as string[]).map((tag) => (
            <span
              key={tag}
              class="px-2 py-0.5 text-xs"
              style="background-color: var(--color-neutral-200); color: var(--color-text); border-radius: var(--radius);"
            >
              {tag}
            </span>
          ))}
        </div>
      ) : null;
    case 'select':
      return (
        <span
          class="inline-block px-2 py-0.5 text-xs"
          style="background-color: var(--color-neutral-200); color: var(--color-text); border-radius: var(--radius);"
        >
          {tr(String(value))}
        </span>
      );
    case 'url':
      return (
        <a href={safeHref(String(value))} class="underline" style="color: var(--color-primary);">
          {String(value)}
        </a>
      );
    case 'email':
      return (
        <a href={`mailto:${value}`} class="underline" style="color: var(--color-primary);">
          {String(value)}
        </a>
      );
    case 'phone':
      return (
        <a href={`tel:${value}`} class="underline" style="color: var(--color-primary);">
          {String(value)}
        </a>
      );
    case 'date':
    case 'datetime':
      return <p style="color: var(--color-text); opacity: 0.7;">{String(value)}</p>;
    case 'richtext':
      // RichText in a card → render as plain text snippet for v1.
      return (
        <p style="color: var(--color-text);">
          {String(value)
            .replace(/<[^>]+>/g, '')
            .slice(0, 200)}
        </p>
      );
    case 'reference':
    case 'reference_list':
      // Reference resolution happens at the page renderer level (joins).
      // For v1 in a generic grid we just show count or "—".
      return <p style="color: var(--color-text); opacity: 0.6;">—</p>;
    case 'color': {
      // Sanitize to prevent CSS injection — only allow valid hex/named colors
      const colorVal = String(value).replace(/[^a-zA-Z0-9#(),.\s%]/g, '');
      return (
        <span
          class="inline-block w-6 h-6 align-middle"
          style={`background-color: ${colorVal}; border-radius: var(--radius);`}
        />
      );
    }
    default:
      return null;
  }
}

function clampColumns(n: number): 2 | 3 | 4 {
  if (n <= 2) return 2;
  if (n >= 4) return 4;
  return 3;
}
