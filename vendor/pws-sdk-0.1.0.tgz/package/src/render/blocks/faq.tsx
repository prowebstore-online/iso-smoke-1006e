/** @jsxRuntime automatic */
/** @jsxImportSource hono/jsx */
import type { FaqBlock, Theme } from '@pws/shared';

export function Faq({ block }: { block: FaqBlock; theme: Theme }) {
  const variant = block.variant ?? 'accordion';
  const twoColumn = variant === 'two-column';

  return (
    <section class="px-6 py-12">
      <div class="max-w-4xl mx-auto">
        {block.heading && (
          <h2
            class="text-3xl font-bold text-center mb-10"
            style="color: var(--color-heading); font-family: var(--font-heading);"
          >
            {block.heading}
          </h2>
        )}
        {twoColumn ? (
          <dl class="space-y-6">
            {block.items.map((item) => (
              <div key={item.question} class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <dt
                  class="font-semibold"
                  style="color: var(--color-heading); font-family: var(--font-heading);"
                >
                  {item.question}
                </dt>
                <dd style="color: var(--color-text); font-family: var(--font-body);">
                  {item.answer}
                </dd>
              </div>
            ))}
          </dl>
        ) : (
          <div class="space-y-2">
            {block.items.map((item) => (
              <details
                key={item.question}
                class="p-4"
                style="background-color: var(--color-surface); border-radius: var(--radius);"
              >
                <summary
                  class="cursor-pointer font-semibold"
                  style="color: var(--color-heading); font-family: var(--font-heading);"
                >
                  {item.question}
                </summary>
                <p class="mt-3" style="color: var(--color-text); font-family: var(--font-body);">
                  {item.answer}
                </p>
              </details>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
