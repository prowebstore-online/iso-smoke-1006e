/** @jsxRuntime automatic */
/** @jsxImportSource hono/jsx */
import type { PricingTableBlock, Theme } from '@pws/shared';

export function PricingTable({ block }: { block: PricingTableBlock; theme: Theme }) {
  return (
    <section class="px-6 py-12">
      <div class="max-w-6xl mx-auto">
        {block.heading && (
          <h2
            class="text-3xl font-bold text-center mb-10"
            style="color: var(--color-heading); font-family: var(--font-heading);"
          >
            {block.heading}
          </h2>
        )}
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
          {block.plans.map((plan) => (
            <div
              key={plan.name}
              class="p-6 flex flex-col"
              style={`background-color: var(--color-surface); border-radius: var(--radius); box-shadow: var(--shadow); ${plan.highlighted ? 'border: 2px solid var(--color-primary);' : ''}`}
            >
              {plan.highlighted && (
                <span
                  class="inline-block self-start text-xs font-bold uppercase px-2 py-1 mb-3 text-white"
                  style="background-color: var(--color-primary); border-radius: var(--radius);"
                >
                  Popular
                </span>
              )}
              <h3
                class="text-xl font-bold"
                style="color: var(--color-heading); font-family: var(--font-heading);"
              >
                {plan.name}
              </h3>
              <div class="mt-3">
                <span class="text-3xl font-bold" style="color: var(--color-heading);">
                  {plan.price}
                </span>
                {plan.period && (
                  <span class="text-sm ml-1" style="color: var(--color-text); opacity: 0.7;">
                    /{plan.period}
                  </span>
                )}
              </div>
              <ul
                class="mt-6 space-y-2 flex-1"
                style="color: var(--color-text); font-family: var(--font-body);"
              >
                {plan.features.map((feature) => (
                  <li key={feature} class="flex items-start gap-2">
                    <span style="color: var(--color-primary);">✓</span>
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
              {plan.cta_text && (
                <a
                  href={plan.cta_url || '#'}
                  class="mt-6 block text-center px-6 py-3 font-medium text-white"
                  style="background-color: var(--color-primary); border-radius: var(--radius);"
                >
                  {plan.cta_text}
                </a>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
