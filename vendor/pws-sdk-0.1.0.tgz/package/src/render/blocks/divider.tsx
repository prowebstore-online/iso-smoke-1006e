/** @jsxRuntime automatic */
/** @jsxImportSource hono/jsx */
import type { DividerBlock, Theme } from '@pws/shared';

export function Divider({ block }: { block: DividerBlock; theme: Theme }) {
  switch (block.style) {
    case 'line':
      return (
        <div class="px-6 py-4">
          <hr class="max-w-5xl mx-auto" style="border-color: var(--color-text); opacity: 0.2;" />
        </div>
      );
    case 'space':
      return <div class="py-8" />;
    case 'gradient':
      return (
        <div class="px-6 py-4">
          <div
            class="max-w-5xl mx-auto h-px"
            style="background: linear-gradient(to right, transparent, var(--color-primary), transparent);"
          />
        </div>
      );
  }
}
