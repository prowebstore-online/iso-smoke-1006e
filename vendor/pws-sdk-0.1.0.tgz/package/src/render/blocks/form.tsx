/** @jsxRuntime automatic */
/** @jsxImportSource hono/jsx */
import type { FormBlock as FormBlockType, Theme } from '@pws/shared';

export function FormBlock({
  block,
  turnstileSiteKey,
}: { block: FormBlockType; theme: Theme; turnstileSiteKey?: string }) {
  const variant = block.variant ?? 'stacked';
  const split = variant === 'split';

  return (
    <section class="px-6 py-12">
      <div class="max-w-3xl mx-auto">
        <div class={split ? 'grid grid-cols-1 md:grid-cols-2 gap-8' : ''}>
          {(block.heading || block.description) && (
            <div>
              {block.heading && (
                <h2
                  class="text-3xl font-bold"
                  style="color: var(--color-heading); font-family: var(--font-heading);"
                >
                  {block.heading}
                </h2>
              )}
              {block.description && (
                <p class="mt-3" style="color: var(--color-text); font-family: var(--font-body);">
                  {block.description}
                </p>
              )}
            </div>
          )}
          <form action="/_/form" method="post" class="space-y-4">
            <input type="hidden" name="_form_id" value={block.id} />
            {block.entity_slug && (
              <input type="hidden" name="_entity_slug" value={block.entity_slug} />
            )}
            <div style="position:absolute;left:-9999px;" aria-hidden="true">
              <input
                type="text"
                name="_hp"
                tabindex={-1}
                autocomplete="off"
                aria-label="Leave blank"
              />
            </div>
            {block.fields.map((field) => (
              <div key={field.name}>
                <label
                  for={field.name}
                  class="block text-sm font-medium mb-1"
                  style="color: var(--color-heading);"
                >
                  {field.label}
                  {field.required && <span style="color: var(--color-primary);"> *</span>}
                </label>
                {field.type === 'textarea' ? (
                  <textarea
                    id={field.name}
                    name={field.name}
                    required={field.required}
                    placeholder={field.placeholder}
                    rows={4}
                    class="w-full px-3 py-2 border"
                    style="border-radius: var(--radius); border-color: color-mix(in srgb, var(--color-text) 30%, transparent);"
                  />
                ) : field.type === 'select' ? (
                  <select
                    id={field.name}
                    name={field.name}
                    required={field.required}
                    class="w-full px-3 py-2 border"
                    style="border-radius: var(--radius);"
                  >
                    <option value="">{field.placeholder || 'Select...'}</option>
                    {field.options?.map((opt) => (
                      <option key={opt} value={opt}>
                        {opt}
                      </option>
                    ))}
                  </select>
                ) : field.type === 'checkbox' ? (
                  <input
                    id={field.name}
                    type="checkbox"
                    name={field.name}
                    required={field.required}
                    class="ml-1"
                  />
                ) : (
                  <input
                    id={field.name}
                    type={field.type}
                    name={field.name}
                    required={field.required}
                    placeholder={field.placeholder}
                    class="w-full px-3 py-2 border"
                    style="border-radius: var(--radius);"
                  />
                )}
              </div>
            ))}
            {turnstileSiteKey && <div class="cf-turnstile" data-sitekey={turnstileSiteKey} />}
            <button
              type="submit"
              class="px-6 py-3 font-medium text-white"
              style="background-color: var(--color-primary); border-radius: var(--radius);"
            >
              {block.submit_label}
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}
