/** @jsxRuntime automatic */
/** @jsxImportSource hono/jsx */
import type { CardsBlock, Theme } from '@pws/shared';

export function Cards({ block }: { block: CardsBlock; theme: Theme }) {
  const variant = block.variant ?? 'grid';
  const featured = variant === 'featured';

  return (
    <section class="px-6 py-12">
      <div class="max-w-6xl mx-auto">
        {block.heading && (
          <h2
            class="text-3xl font-bold text-center mb-10"
            style="color: var(--color-heading); font-family: var(--font-heading);"
          >
            {block.heading}
          </h2>
        )}
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {block.items.map((item, i) => {
            const span = featured && i === 0 ? 'md:col-span-2' : '';
            return (
              <div
                key={item.title}
                class={`p-6 ${span}`}
                style="background-color: var(--color-surface); border-radius: var(--radius); box-shadow: var(--shadow);"
              >
                {item.image && (
                  <img
                    src={`/_/img/${item.image.asset_id}`}
                    alt={item.image.alt}
                    loading="lazy"
                    class="w-full h-48 object-cover mb-4"
                    style="border-radius: var(--radius);"
                  />
                )}
                <h3
                  class="text-lg font-semibold"
                  style="color: var(--color-heading); font-family: var(--font-heading);"
                >
                  {item.link ? <a href={item.link}>{item.title}</a> : item.title}
                </h3>
                <p
                  class="mt-2 text-sm"
                  style="color: var(--color-text); font-family: var(--font-body);"
                >
                  {item.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
