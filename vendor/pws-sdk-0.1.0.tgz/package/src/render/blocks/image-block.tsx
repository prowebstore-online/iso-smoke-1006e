/** @jsxRuntime automatic */
/** @jsxImportSource hono/jsx */
import type { ImageBlockBlock, Theme } from '@pws/shared';

export function ImageBlock({ block }: { block: ImageBlockBlock; theme: Theme }) {
  const variant = block.variant ?? 'contained';
  const widthClass = variant === 'full' ? 'w-full' : 'max-w-5xl mx-auto';
  const roundedClass = variant === 'rounded' ? 'rounded-lg overflow-hidden' : '';

  return (
    <section class="px-6 py-12">
      <figure class={`${widthClass} ${roundedClass}`}>
        <img
          src={`/_/img/${block.image.asset_id}`}
          alt={block.image.alt}
          width={block.image.width}
          height={block.image.height}
          loading="lazy"
          class="w-full h-auto"
          style="border-radius: var(--radius);"
        />
        {block.caption && (
          <figcaption
            class="mt-3 text-sm text-center"
            style="color: var(--color-text); opacity: 0.7;"
          >
            {block.caption}
          </figcaption>
        )}
      </figure>
    </section>
  );
}
