/** @jsxRuntime automatic */
/** @jsxImportSource hono/jsx */
// Block dispatcher: pick renderer by `_type`.

import type {
  Block,
  EntityGridBlock,
  EntityRecord,
  EntitySchema,
  ProductGridBlock,
  Theme,
} from '@pws/shared';
import { Cards } from './cards.tsx';
import { Cart } from './cart.tsx';
import { Checkout } from './checkout.tsx';
import { Cta } from './cta.tsx';
import { CustomHtml } from './custom-html.tsx';
import { Divider } from './divider.tsx';
import { EntityGrid } from './entity-grid.tsx';
import { Faq } from './faq.tsx';
import { Features } from './features.tsx';
import { FormBlock } from './form.tsx';
import { Gallery } from './gallery.tsx';
import { Hero } from './hero.tsx';
import { ImageBlock } from './image-block.tsx';
import { PricingTable } from './pricing-table.tsx';
import { ProductGrid } from './product-grid.tsx';
import { RichText } from './richtext.tsx';
import { Team } from './team.tsx';
import { Testimonials } from './testimonials.tsx';

export interface RenderContext {
  theme: Theme;
  turnstileSiteKey?: string;
  /** original→translated map for the active locale (translates record data). */
  translations?: Record<string, string>;
  /** Locale path prefix for internal links, e.g. "/zh-CN". Empty for default. */
  localePrefix?: string;
  // For entity-bound blocks: function that fetches records by entity slug.
  fetchEntityRecords?: (
    entitySlug: string,
    opts?: { limit?: number },
  ) => {
    records: EntityRecord[];
    schema: EntitySchema | null;
  };
}

export function renderBlock(block: Block, ctx: RenderContext) {
  if (block.visible === false) return null;
  switch (block._type) {
    case 'hero':
      return <Hero block={block} theme={ctx.theme} />;
    case 'richtext':
      return <RichText block={block} theme={ctx.theme} />;
    case 'cta':
      return <Cta block={block} theme={ctx.theme} />;
    case 'image_block':
      return <ImageBlock block={block} theme={ctx.theme} />;
    case 'entity_grid':
      return renderEntityGrid(block, ctx);
    case 'features':
      return <Features block={block} theme={ctx.theme} />;
    case 'cards':
      return <Cards block={block} theme={ctx.theme} />;
    case 'testimonials':
      return <Testimonials block={block} theme={ctx.theme} />;
    case 'faq':
      return <Faq block={block} theme={ctx.theme} />;
    case 'team':
      return <Team block={block} theme={ctx.theme} />;
    case 'pricing_table':
      return <PricingTable block={block} theme={ctx.theme} />;
    case 'form':
      return <FormBlock block={block} theme={ctx.theme} turnstileSiteKey={ctx.turnstileSiteKey} />;
    case 'gallery':
      return <Gallery block={block} theme={ctx.theme} />;
    case 'divider':
      return <Divider block={block} theme={ctx.theme} />;
    case 'custom_html':
      return <CustomHtml block={block} theme={ctx.theme} />;
    case 'product_grid':
      return renderProductGrid(block, ctx);
    case 'cart':
      return (
        <Cart
          block={block}
          theme={ctx.theme}
          translations={ctx.translations}
          localePrefix={ctx.localePrefix}
        />
      );
    case 'checkout':
      return (
        <Checkout
          block={block}
          theme={ctx.theme}
          translations={ctx.translations}
          localePrefix={ctx.localePrefix}
        />
      );
    default: {
      const _exhaustive: never = block;
      return _exhaustive;
    }
  }
}

function renderEntityGrid(block: EntityGridBlock, ctx: RenderContext) {
  if (!ctx.fetchEntityRecords) {
    return (
      <section class="px-6 py-12">
        <p class="opacity-60">Entity rendering not configured.</p>
      </section>
    );
  }
  const { records, schema } = ctx.fetchEntityRecords(block.entity, { limit: block.limit });
  if (!schema) {
    return (
      <section class="px-6 py-12">
        <p class="opacity-60">Unknown entity: {block.entity}</p>
      </section>
    );
  }
  return (
    <EntityGrid
      block={block}
      records={records}
      schema={schema}
      theme={ctx.theme}
      translations={ctx.translations}
      localePrefix={ctx.localePrefix}
    />
  );
}

function renderProductGrid(block: ProductGridBlock, ctx: RenderContext) {
  if (!ctx.fetchEntityRecords) {
    return (
      <section class="px-6 py-12">
        <p class="opacity-60">Entity rendering not configured.</p>
      </section>
    );
  }
  const { records: allRecords, schema } = ctx.fetchEntityRecords(block.entity, {
    limit: block.limit,
  });
  if (!schema) {
    return (
      <section class="px-6 py-12">
        <p class="opacity-60">Unknown entity: {block.entity}</p>
      </section>
    );
  }
  const records = block.filter ? applyFilter(allRecords, block.filter) : allRecords;
  return (
    <ProductGrid
      block={block}
      records={records}
      schema={schema}
      theme={ctx.theme}
      localePrefix={ctx.localePrefix}
      translations={ctx.translations}
    />
  );
}

function applyFilter(records: EntityRecord[], filter: Record<string, unknown>): EntityRecord[] {
  return records.filter((r) => {
    for (const [key, val] of Object.entries(filter)) {
      if (r.data[key] !== val) return false;
    }
    return true;
  });
}
