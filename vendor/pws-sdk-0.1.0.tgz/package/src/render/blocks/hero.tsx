/** @jsxRuntime automatic */
/** @jsxImportSource hono/jsx */
import type { HeroBlock, Theme } from '@pws/shared';

/** Escape a string for safe insertion into a CSS string literal. */
function cssEscape(s: string): string {
  return s
    .replace(/\\/g, '\\\\')
    .replace(/'/g, "\\'")
    .replace(/[\n\r]/g, '');
}

export function Hero({ block }: { block: HeroBlock; theme: Theme }) {
  const align = block.alignment ?? 'center';
  const alignClass =
    align === 'left' ? 'text-left' : align === 'right' ? 'text-right' : 'text-center';
  const containerClass = align === 'center' ? 'mx-auto max-w-3xl' : 'max-w-3xl';

  const bgStyle = block.bg_image?.asset_id
    ? `background-image: url('/_/img/${cssEscape(block.bg_image.asset_id)}'); background-size: cover; background-position: center;`
    : '';

  return (
    <section
      class="relative px-6 py-24 md:py-32"
      style={`background-color: var(--color-surface); ${bgStyle}`}
    >
      <div class={`${containerClass} ${alignClass}`}>
        <h1
          class="text-4xl md:text-6xl font-bold leading-tight"
          style="color: var(--color-heading); font-family: var(--font-heading);"
        >
          {block.heading}
        </h1>
        {block.subheading && (
          <p
            class="mt-6 text-lg md:text-xl"
            style="color: var(--color-text); font-family: var(--font-body);"
          >
            {block.subheading}
          </p>
        )}
        {(block.cta_text || block.cta2_text) && (
          <div
            class={`mt-8 flex gap-4 ${align === 'center' ? 'justify-center' : align === 'right' ? 'justify-end' : ''}`}
          >
            {block.cta_text && block.cta_url && (
              <a
                href={block.cta_url}
                class="inline-block px-6 py-3 font-medium text-white"
                style="background-color: var(--color-primary); border-radius: var(--radius); box-shadow: var(--shadow);"
              >
                {block.cta_text}
              </a>
            )}
            {block.cta2_text && block.cta2_url && (
              <a
                href={block.cta2_url}
                class="inline-block px-6 py-3 font-medium border"
                style="color: var(--color-text); border-color: var(--color-text); border-radius: var(--radius);"
              >
                {block.cta2_text}
              </a>
            )}
          </div>
        )}
      </div>
    </section>
  );
}
