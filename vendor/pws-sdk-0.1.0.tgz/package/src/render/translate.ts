/** Translate a string using the translation map. Falls back to original. */
export function t(text: string, translations?: Record<string, string>): string {
  if (!translations) return text;
  return translations[text] ?? text;
}
