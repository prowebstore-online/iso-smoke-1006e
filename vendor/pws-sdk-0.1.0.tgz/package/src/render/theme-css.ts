// Theme → CSS custom properties.
// Emitted in <head> as <style> for every rendered page.

import {
  DEFAULT_THEME,
  type RadiusToken,
  type ShadowToken,
  type SpacingToken,
  type Theme,
} from '@pws/shared';

const RADIUS_PX: Record<RadiusToken, string> = {
  none: '0',
  sm: '4px',
  md: '8px',
  lg: '16px',
  full: '9999px',
};

const SHADOW_VALUES: Record<ShadowToken, string> = {
  none: 'none',
  sm: '0 1px 2px 0 rgb(0 0 0 / 0.05)',
  md: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)',
  lg: '0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1)',
};

const SPACING_SCALE: Record<SpacingToken, string> = {
  compact: '0.875',
  normal: '1',
  relaxed: '1.125',
};

// A value that is safe to emit into the <style> text node at page.tsx:398-399.
//
// <style> is raw text per the HTML spec — character references are NOT decoded
// inside it — so HTML-escaping would corrupt the CSS (`&quot;` shipped literally
// into every quoted font family) without preventing anything, and the `raw()` at
// page.tsx:399 is required. Removing it reintroduces #33's bug class one element
// over. The guard therefore has to be on the VALUE, not on the markup: the only
// string that ends the element is `</style`, and no amount of escaping the
// surrounding template stops a value from containing it.
//
// Allowlist, not blocklist — a blocklist comment in meta-validator.ts is how #37
// got here, and `</style\t>`, `</style/>` and `</STYLE >` all end the element.
// This class is exactly what a colour or length token needs (`/` for
// `rgb(0 0 0 / 0.5)`, `%`, `#` for hex, `,` and `-` for shadow lists) and it
// excludes `<`, `>`, `;`, `{`, `}` and `*` — so a value can neither close the
// element, end the declaration, close the rule, nor open a comment.
const CSS_VALUE_RE = /^[#0-9A-Za-z.%,()\/\s+-]+$/;

// Font families additionally need quotes, for `"Playfair Display", Georgia, serif`.
const CSS_FONT_RE = /^[0-9A-Za-z_ ,.'"-]+$/;

// Fall back to the DEFAULT_THEME token rather than dropping the declaration:
// most of the renderer uses bare `var(--color-primary)` with no CSS fallback, so
// a dropped declaration is an unstyled page — a worse failure than a wrong
// colour, and a much quieter one. Where there is no default to fall back to (an
// optional token DEFAULT_THEME happens not to set) the declaration IS dropped,
// which the renderer already handles because the token was optional anyway.
// Never fall back to the rejected value itself.
const cssValue = (v: string, fallback: string | undefined): string | undefined =>
  CSS_VALUE_RE.test(v) ? v : fallback;

const cssFont = (v: string, fallback: string): string => (CSS_FONT_RE.test(v) ? v : fallback);

// `decl('--color-accent', value, default)` → the declaration, or undefined to drop it.
const decl = (
  name: string,
  v: string | undefined,
  fallback: string | undefined,
): string | undefined => {
  if (!v) return undefined;
  const safe = cssValue(v, fallback);
  return safe === undefined ? undefined : `${name}: ${safe};`;
};

export function themeToCss(theme: Theme): string {
  const c = theme.colors;
  const d = DEFAULT_THEME.colors;
  const radius = RADIUS_PX[theme.radius ?? 'md'];
  const shadow = SHADOW_VALUES[theme.shadow ?? 'sm'];
  const spacing = SPACING_SCALE[theme.spacing ?? 'normal'];

  // radius/shadow/spacing are enum keys into the constant maps above, so they
  // are safe by construction. The colours and fonts are caller-supplied.
  const lines: string[] = [
    decl('--color-primary', c.primary, d.primary),
    decl('--color-secondary', c.secondary, d.secondary),
    decl('--color-accent', c.accent, d.accent),
    decl('--color-background', c.background, d.background),
    decl('--color-surface', c.surface, d.surface),
    decl('--color-text', c.text, d.text),
    decl('--color-heading', c.heading, d.heading),
    `--font-heading: ${cssFont(theme.fonts.heading, DEFAULT_THEME.fonts.heading)};`,
    `--font-body: ${cssFont(theme.fonts.body, DEFAULT_THEME.fonts.body)};`,
    `--radius: ${radius};`,
    `--shadow: ${shadow};`,
    `--spacing-scale: ${spacing};`,
  ].filter((s): s is string => typeof s === 'string');

  if (c.neutral) {
    // The `--color-neutral-${k}` KEY is safe by construction: NeutralSchema is
    // .strict() with the fixed keys 50…950. The value is not.
    for (const [k, v] of Object.entries(c.neutral)) {
      const line = decl(`--color-neutral-${k}`, v, d.neutral?.[k as keyof typeof d.neutral]);
      if (line) lines.push(line);
    }
  }

  lines.push(`--font-size-base: 17px;`);

  return `:root {\n  ${lines.join('\n  ')}\n}`;
}
