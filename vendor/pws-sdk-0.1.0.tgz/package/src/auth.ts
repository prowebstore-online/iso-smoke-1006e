// Worker-side auth: principal resolution + middleware.
//
// Two principal kinds:
//   - admin: the `ADMIN_API_TOKEN` bearer (god mode, used by ops + provisioning)
//   - user:  a per-site session token resolved against that site's DO
//
// Routes under `/sites/:siteId/*` accept either; routes under `/admin/*`
// require admin. The login endpoint is the only `/sites/...` path that runs
// without auth — it IS the auth.

import type { Context, Next } from 'hono';
import { parseSessionCookie } from './admin/cookies.ts';
import type { SiteUser } from './do/rpc.ts';
import { type Env, siteStub } from './env.ts';

export type Principal =
  | { kind: 'admin' }
  | { kind: 'user'; siteId: string; user: SiteUser; token: string };

export interface AuthVars {
  principal?: Principal;
}

// Loose Context type for the auth helpers — they only read `principal` and
// `env`, so we don't constrain the rest of the app's Variables shape (which
// also carries `mode` and is invariant in Hono's Context generic).
// biome-ignore lint/suspicious/noExplicitAny: intentional widening
type Ctx = Context<{ Bindings: Env; Variables: any }>;

/** Display name for `created_by` columns. */
export function principalLabel(p: Principal): string {
  if (p.kind === 'admin') return 'admin';
  return p.user.id;
}

/** Constant-time string comparison; avoids leaking the token via timing or length. */
export function constantTimeEquals(a: string, b: string): boolean {
  const maxLen = Math.max(a.length, b.length);
  let diff = a.length ^ b.length; // non-zero if lengths differ
  for (let i = 0; i < maxLen; i++) {
    diff |= (a.charCodeAt(i) || 0) ^ (b.charCodeAt(i) || 0);
  }
  return diff === 0;
}

function extractBearer(c: Ctx): string | null {
  const auth = c.req.header('authorization') ?? '';
  if (!auth.startsWith('Bearer ')) return null;
  return auth.slice(7).trim() || null;
}

/**
 * Try the admin token. Returns admin principal on match, null otherwise.
 * Returns null silently when ADMIN_API_TOKEN is unset (callers handle 503).
 */
function tryAdmin(env: Env, token: string): Principal | null {
  const expected = env.ADMIN_API_TOKEN;
  if (!expected) return null;
  return constantTimeEquals(token, expected) ? { kind: 'admin' } : null;
}

/**
 * Strict admin auth — for `/admin/*` routes. 401 on missing/wrong token,
 * 503 if the token isn't configured.
 */
export async function adminOnly(c: Ctx, next: Next): Promise<Response | undefined> {
  if (!c.env.ADMIN_API_TOKEN) {
    return c.json(
      { ok: false, error: 'ADMIN_API_TOKEN not configured. See SECURITY.md / DEPLOY.md.' },
      503,
    );
  }
  const token = extractBearer(c);
  if (!token) return c.json({ ok: false, error: 'Unauthorized.' }, 401);
  const principal = tryAdmin(c.env, token);
  if (!principal) return c.json({ ok: false, error: 'Unauthorized.' }, 401);
  c.set('principal', principal);
  await next();
}

/**
 * Site-scoped auth — for `/sites/:siteId/*` routes.
 * Accepts the admin token (god mode) OR a session token for THAT specific site.
 * Skips the login endpoint, which authenticates inline via email + password.
 */
export async function siteAuth(c: Ctx, next: Next): Promise<Response | undefined> {
  // Login endpoint is the auth — let it through.
  const path = new URL(c.req.url).pathname;
  if (/^\/sites\/[^/]+\/auth\/login\/?$/.test(path)) {
    await next();
    return;
  }

  if (!c.env.ADMIN_API_TOKEN) {
    return c.json(
      { ok: false, error: 'ADMIN_API_TOKEN not configured. See SECURITY.md / DEPLOY.md.' },
      503,
    );
  }

  const urlSiteId = c.req.param('siteId');

  // 1. Bearer token in the Authorization header — CLI / API path.
  const bearer = extractBearer(c);
  if (bearer) {
    const admin = tryAdmin(c.env, bearer);
    if (admin) {
      c.set('principal', admin);
      await next();
      return;
    }
    if (urlSiteId) {
      const user = await siteStub(c.env, urlSiteId).resolveSession(bearer);
      if (user) {
        c.set('principal', { kind: 'user', siteId: urlSiteId, user, token: bearer });
        await next();
        return;
      }
    }
  }

  // 2. pws_session cookie — admin web UI path. Cookie carries its own siteId;
  //    we only honor it when it matches the URL's :siteId param (no replay across sites).
  const cookie = parseSessionCookie(c.req.header('cookie'));
  if (cookie && urlSiteId && cookie.siteId === urlSiteId) {
    const user = await siteStub(c.env, urlSiteId).resolveSession(cookie.token);
    if (user) {
      c.set('principal', { kind: 'user', siteId: urlSiteId, user, token: cookie.token });
      await next();
      return;
    }
  }

  return c.json({ ok: false, error: 'Unauthorized.' }, 401);
}

/** Resolve the cookie session without enforcing — used by the admin UI middleware. */
export async function resolveCookieSession(
  c: Ctx,
): Promise<{ siteId: string; user: SiteUser; token: string } | null> {
  const cookie = parseSessionCookie(c.req.header('cookie'));
  if (!cookie) return null;
  const user = await siteStub(c.env, cookie.siteId).resolveSession(cookie.token);
  if (!user) return null;
  return { siteId: cookie.siteId, user, token: cookie.token };
}

/** Route guards — call after `siteAuth` has populated the principal. */

export function requirePrincipal(c: Ctx): Principal | Response {
  const p = c.get('principal');
  if (!p) return c.json({ ok: false, error: 'Unauthorized.' }, 401);
  return p;
}

/** Owner-or-admin guard for user-management endpoints. */
export function requireOwner(c: Ctx, siteId: string): Principal | Response {
  const p = requirePrincipal(c);
  if (p instanceof Response) return p;
  if (p.kind === 'admin') return p;
  if (p.siteId !== siteId || p.user.role !== 'owner') {
    return c.json({ ok: false, error: 'Forbidden — owner role required.' }, 403);
  }
  return p;
}
