// @pws/sdk — the core CMS engine consumed by every PWS site.
//
// Each site repo depends on this package. It provides:
// - Block renderers (15 types)
// - Page renderer + theme engine
// - Admin panel (server-rendered Hono JSX)
// - AI agent tools + conversation loop
// - Entity/schema/record system (SiteDO)
// - Template composition helpers
// - Quality testing utilities
//
// Sites extend the SDK with custom blocks, plugins, and API routes.

export { mountSiteRoutes } from './site-routes.ts';
export { DESIGN_TOKENS, StyleTag, FONT_SANS, FONT_MONO } from './design-tokens.ts';
export {
  sendEmail,
  welcomeEmail,
  formSubmissionNotification,
  magicLinkEmail,
  notifyFormOwners,
  emailConfigFromEnv,
} from './email.ts';
export type { EmailConfig, SendEmailOpts } from './email.ts';
export { renderPage, googleFontsUrl, buildAnalyticsTags } from './render/page.tsx';
export type { PageRenderInput } from './render/page.tsx';
export { renderBlock } from './render/blocks/index.tsx';
export { themeToCss } from './render/theme-css.ts';
export { renderHtmlHeaders } from './render/headers.ts';
export { serveSitePage, serveOrderPage } from './render/serve.ts';
export { resolveRecordPage } from './render/resolve-record-page.ts';
export { renderOrderConfirmation } from './render/order.ts';
export { pwaMetaTags, generateManifest, svgIcon, MINIMAL_SW } from './pwa.ts';
export { hmacSha256 } from './crypto.ts';

// Re-export shared types
export * from '@pws/shared';
