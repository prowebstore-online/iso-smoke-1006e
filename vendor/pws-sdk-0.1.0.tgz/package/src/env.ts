// Typed bindings for the Worker. Mirrors wrangler.toml.
// DO namespaces are kept untyped here to dodge the Env ↔ DO circular chain;
// callers use the `siteStub` / `sessionStub` helpers which apply RPC types.

import type { SessionRpc, SiteRpc } from './do/rpc.ts';

export interface Env {
  SITE_DO: DurableObjectNamespace;
  SESSION_DO: DurableObjectNamespace;
  RENDER_CACHE?: KVNamespace;
  /**
   * Workers Rate Limiting binding (CF-managed token bucket).
   * Optional — when bound, /agent enforces per-(site, IP) limits.
   */
  AGENT_RATE_LIMIT?: { limit: (input: { key: string }) => Promise<{ success: boolean }> };
  /** Workers Rate Limiting for login brute-force protection. */
  AUTH_RATE_LIMIT?: { limit: (input: { key: string }) => Promise<{ success: boolean }> };
  /** Workers Rate Limiting for form submission spam prevention. */
  FORM_RATE_LIMIT?: { limit: (input: { key: string }) => Promise<{ success: boolean }> };
  /** D1 for cross-site platform data (user registry, site index, billing). */
  DB?: D1Database;
  MEDIA?: R2Bucket;
  /** Set (e.g. "1") when Cloudflare Image Resizing is enabled on the zone —
   *  activates on-the-fly thumbnails in serveImage. No-op when unset. */
  IMAGE_RESIZING?: string;
  // DB: D1Database;
  // VECTORS: VectorizeIndex;
  // QUEUE: Queue;

  // OAuth for admin sign-in (optional — password login still works without them).
  GOOGLE_CLIENT_ID?: string;
  GOOGLE_CLIENT_SECRET?: string;
  GITHUB_CLIENT_ID?: string;
  GITHUB_CLIENT_SECRET?: string;

  // Magic link passwordless login (optional — requires a transactional email service).
  MAGIC_LINK_SECRET?: string;

  // Turnstile bot protection (optional — forms degrade gracefully without it).
  TURNSTILE_SITE_KEY?: string;
  TURNSTILE_SECRET_KEY?: string;

  // Secrets — set via `wrangler secret put` in production, or .dev.vars locally.
  ANTHROPIC_API_KEY?: string;
  /**
   * Optional override of the Anthropic base URL. Set to a Cloudflare AI Gateway
   * URL like:
   *   https://gateway.ai.cloudflare.com/v1/{account_id}/{gateway_id}/anthropic
   * to get caching, rate-limit, observability, and multi-provider failover.
   */
  ANTHROPIC_BASE_URL?: string;
  /** Default model. Defaults to claude-sonnet-4-6 if unset. */
  ANTHROPIC_MODEL?: string;
  /**
   * Bearer token required on every admin API call. Set via:
   *   wrangler secret put ADMIN_API_TOKEN --env production
   * Generate strong: `openssl rand -hex 32`.
   */
  ADMIN_API_TOKEN?: string;
  /**
   * Isolated sites only: present for the few seconds the platform runs the
   * one-time POST /_/pws/setup (#46), then deleted. Never set it by hand.
   */
  PWS_SETUP_TOKEN?: string;

  // Transactional email (Resend)
  RESEND_API_KEY?: string;
  EMAIL_FROM?: string; // e.g. "ProWebStore <noreply@prowebstore.online>"

  // Stripe billing (Pro subscription)
  STRIPE_SECRET_KEY?: string;
  STRIPE_WEBHOOK_SECRET?: string;
  STRIPE_PRICE_ID?: string; // price_xxx for the $10/mo Website plan
}

export function siteStub(env: Env, siteId: string): SiteRpc {
  return env.SITE_DO.get(env.SITE_DO.idFromName(siteId)) as unknown as SiteRpc;
}

export function sessionStub(env: Env, sessionId: string): SessionRpc {
  return env.SESSION_DO.get(env.SESSION_DO.idFromName(sessionId)) as unknown as SessionRpc;
}
