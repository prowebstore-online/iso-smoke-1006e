// mountSiteRoutes — the one-call setup for per-site Workers.
// Mounts everything a PWS site needs: admin panel, page serving, media,
// forms, member auth, AI agent, PWA, robots.txt, RSS, sitemap.
//
// Usage in a site's src/index.ts:
//   import { mountSiteRoutes } from '@pws/sdk';
//   const app = new Hono();
//   mountSiteRoutes(app, { siteId: 'my-site' });
//   export default app;

import { sellableEntityOf } from '@pws/shared';
import type { Hono } from 'hono';
import { buildSessionCookie, clearSessionCookie, parseSessionCookie } from './admin/cookies.ts';
import { buildAdminRoutes } from './admin/routes.tsx';
import { constantTimeEquals } from './auth.ts';
import { emailConfigFromEnv, notifyFormOwners, sendEmail, welcomeEmail } from './email.ts';
import type { Env } from './env.ts';
import { siteStub } from './env.ts';
import {
  hashedClientIp,
  isFormRateLimited,
  turnstileAllows,
  verifyTurnstile,
} from './form-guard.ts';
import { MINIMAL_SW, generateManifest, svgIcon } from './pwa.ts';
import { setWorkerHeader } from './render/headers.ts';
import { serveOrderPage, serveSitePage } from './render/serve.ts';
import { TTS_SCRIPT } from './render/tts-widget.ts';
import { type TemplateFixture, applyTemplateFixture } from './templates/fixture.ts';

interface SiteRouteOptions {
  siteId: string;
  /** The generated repo's template fixture; enables the one-time platform setup. */
  template?: TemplateFixture;
}

export function mountSiteRoutes(app: Hono<{ Bindings: Env }>, opts: SiteRouteOptions): void {
  const { siteId } = opts;

  // ── Worker identity + workers.dev hygiene (#44) ────────────────────
  // Every response names this Worker (see setWorkerHeader). The workers.dev URL
  // stays public — provisioning smokes it before the route exists — so it is
  // kept out of search as a duplicate of the real site.
  app.use('*', async (c, next) => {
    await next();
    setWorkerHeader(c, `pws-site-${siteId}`);
    if (isWorkersDev(c.req.url)) c.res.headers.set('X-Robots-Tag', 'noindex');
  });

  // ── Health check ───────────────────────────────────────────────────
  app.get('/healthz', (c) => c.json({ ok: true, site: siteId, ts: Date.now() }));

  // ── One-time platform setup (#46) ──────────────────────────────────
  // Provisioning never writes content by itself (#42). The platform calls this
  // once, after the Worker is deployed and before the site gets its hostname:
  // it sets PWS_SETUP_TOKEN as a Worker secret, calls this, then deletes the
  // secret. Without the secret (or without a template) the route does not
  // exist. It refuses a site that already has pages or users, so it can never
  // overwrite or re-seed a site someone is using.
  app.post('/_/pws/setup', async (c) => {
    const expected = c.env.PWS_SETUP_TOKEN;
    if (!expected || !opts.template) return c.text('Not found', 404);
    const header = c.req.header('authorization') ?? '';
    const token = header.startsWith('Bearer ') ? header.slice(7).trim() : '';
    if (!token || !constantTimeEquals(token, expected)) {
      return c.json({ ok: false, error: 'Unauthorized.' }, 401);
    }
    let ownerEmail = '';
    try {
      ownerEmail = String(((await c.req.json()) as { owner_email?: unknown }).owner_email ?? '');
    } catch {
      /* validated below */
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(ownerEmail) || ownerEmail.length > 254) {
      return c.json({ ok: false, error: 'owner_email is required.' }, 400);
    }
    const stub = siteStub(c.env, siteId);
    const [pages, users] = await Promise.all([stub.listPages(), stub.listUsers()]);
    if (pages.length > 0 || users.length > 0) {
      return c.json({ ok: false, error: 'Site is already set up.' }, 409);
    }
    const applied = await applyTemplateFixture(stub, opts.template);
    // The owner signs in by resetting it; the platform never learns it.
    const owner = await stub.createUser({
      email: ownerEmail,
      password: `${crypto.randomUUID()}${crypto.randomUUID()}`,
      role: 'owner',
    });
    return c.json({ ok: true, applied, owner: { id: owner.id, email: owner.email } });
  });

  // ── Stylesheet ─────────────────────────────────────────────────────
  // Every page and the admin link /_/styles.css. Without this route an isolated
  // site served every page unstyled (§22). Same bytes and headers as the shared
  // Worker's (packages/worker/src/routes/tenant.ts): both import this file.
  app.get('/_/styles.css', async (c) => {
    const { default: css } = await import('./render/tailwind.gen.ts');
    return c.body(css, 200, {
      'Content-Type': 'text/css; charset=utf-8',
      'Cache-Control': 'public, max-age=31536000, immutable',
      'X-Content-Type-Options': 'nosniff',
    });
  });

  // ── Admin panel ────────────────────────────────────────────────────
  app.route('/admin', buildAdminRoutes());

  // ── Images ─────────────────────────────────────────────────────────
  app.get('/_/img/:assetId', async (c) => {
    if (!c.env.MEDIA) return c.text('Not found', 404);
    const { serveImage } = await import('./media.ts');
    const w = Number(c.req.query('w'));
    return serveImage(c.env, siteId, c.req.param('assetId'), {
      width: Number.isFinite(w) && w > 0 ? w : undefined,
      request: c.req.raw,
    });
  });

  // ── Media files ────────────────────────────────────────────────────
  app.get('/_/media/:fileId/:filename', async (c) => {
    if (!c.env.MEDIA) return c.text('Not found', 404);
    const { serveFile } = await import('./media.ts');
    return serveFile(c.env, siteId, c.req.param('fileId'));
  });

  // ── Text-to-speech widget ───────────────────────────────────────────
  app.get('/_/tts.js', (c) =>
    c.body(TTS_SCRIPT, 200, {
      'Content-Type': 'application/javascript',
      'Cache-Control': 'public, max-age=86400',
    }),
  );

  // ── Form submissions ──────────────────────────────────────────────
  app.post('/_/form', async (c) => {
    // Abuse protection is form-guard.ts, shared with the shared Worker's
    // routes/tenant.ts (#51, §22, §28): rate limit first, before the body.
    if (await isFormRateLimited(c.env, siteId, c.req.raw.headers)) {
      return c.html('<p>Too many submissions. Please try again later.</p>', 429);
    }
    // A body that is not form-encoded (e.g. JSON) is the client's error: 400,
    // not an unhandled throw that surfaces as a 500 (#48).
    let formData: FormData;
    try {
      formData = await c.req.formData();
    } catch {
      return c.html('<p>Expected a form submission.</p>', 400);
    }
    if (formData.get('_hp')) return c.html('<p>Thank you for your submission.</p>');

    const requestHost = c.req.header('host') ?? new URL(c.req.url).host;
    const referer = c.req.header('referer');
    let safeReferer: string | null = null;
    if (referer) {
      try {
        const u = new URL(referer);
        if (u.host === requestHost) safeReferer = referer;
      } catch {}
    }
    const redirect = (q: string) =>
      safeReferer ? c.redirect(`${safeReferer}?${q}`, 303) : c.html('<p>Thank you!</p>');

    // Turnstile: fail-open only when no secret is configured (§27); a missing,
    // bad or unverifiable token — including a siteverify outage — is refused.
    if (!turnstileAllows(await verifyTurnstile(c.env, formData, c.req.raw.headers))) {
      return redirect('error=captcha');
    }

    const entitySlug = formData.get('_entity_slug') as string | null;
    const stub = siteStub(c.env, siteId);

    if (entitySlug) {
      const schema = await stub.getSchema(entitySlug);
      if (!schema || !schema.public_writable) return redirect('error=1');

      const fieldMap = new Map(schema.fields.map((f) => [f.slug, f.type]));
      const data: Record<string, unknown> = {};
      for (const [key, value] of formData.entries()) {
        if (key.startsWith('_') || typeof value !== 'string') continue;
        const ft = fieldMap.get(key);
        if (!ft) continue;
        if (ft === 'number') {
          const n = Number(value);
          if (!Number.isNaN(n)) data[key] = n;
        } else if (ft === 'boolean')
          data[key] = value === 'on' || value === 'true' || value === '1';
        else data[key] = value.slice(0, 5000);
      }
      for (const [slug, type] of fieldMap) {
        if (type === 'boolean' && !(slug in data)) data[slug] = false;
      }
      const result = await stub.addRecord({
        entity_slug: entitySlug,
        data: data as import('@pws/shared').RecordData,
        created_by: 'form:visitor',
      });
      // Notify the site's owners, off the response path (see notifyFormOwners).
      if (result.ok) {
        c.executionCtx.waitUntil(
          notifyFormOwners(emailConfigFromEnv(c.env), stub, {
            siteId,
            formName: schema.name,
            fields: data,
          }),
        );
      }
      return redirect(result.ok ? 'submitted=1' : 'error=1');
    }

    const formId = (formData.get('_form_id') as string) || 'unknown';
    const flatData: Record<string, string> = {};
    for (const [key, value] of formData.entries()) {
      if (key.startsWith('_') || typeof value !== 'string') continue;
      flatData[key] = value.slice(0, 5000);
    }
    if (Object.keys(flatData).length === 0) return c.html('<p>No form data received.</p>', 400);
    // A hash of the trusted IP, never the address — this stored the raw IP (#51).
    const ip = await hashedClientIp(c.req.raw.headers);
    const stored = await stub.addSubmission({
      id: crypto.randomUUID(),
      form_id: formId,
      data: flatData,
      ip,
    });
    if (stored.ok) {
      c.executionCtx.waitUntil(
        notifyFormOwners(emailConfigFromEnv(c.env), stub, {
          siteId,
          formName: formId,
          fields: flatData,
        }),
      );
    }
    return redirect('submitted=1');
  });

  // ── Checkout (mock payment) ────────────────────────────────────────
  // Cart prices arrive from the client but are NEVER trusted: every line is
  // re-priced against the live sellable-entity records before the order is
  // written. Tracked inventory (numeric `stock`) is enforced + decremented here.
  app.post('/_/checkout', async (c) => {
    const stub = siteStub(c.env, siteId);
    const orderSchema = await stub.getSchema('order');
    if (!orderSchema) return c.redirect('/checkout?error=unavailable', 303);
    const snapshot = await stub.siteSnapshot();
    const sellable = sellableEntityOf(snapshot.config);

    const formData = await c.req.formData();
    let cart: Array<{ id?: string; qty?: number }> = [];
    try {
      const parsed = JSON.parse(String(formData.get('cart') ?? '[]'));
      // Cap the cart so the stored order JSON stays bounded (parity with the
      // multi-tenant worker path). Slicing the ARRAY keeps the JSON valid —
      // slicing the serialized string would corrupt it.
      if (Array.isArray(parsed)) cart = parsed.slice(0, 200);
    } catch {}
    if (cart.length === 0) return c.redirect('/checkout?error=empty', 303);

    // Requested lines (client prices are never trusted). qty is clamped here;
    // reserveStock re-prices from the live records.
    const reqLines: Array<{ id: string; qty: number }> = [];
    for (const item of cart) {
      if (!item.id) continue;
      reqLines.push({
        id: item.id,
        qty: Math.max(1, Math.min(99, Math.floor(Number(item.qty) || 1))),
      });
    }
    if (reqLines.length === 0) return c.redirect('/checkout?error=empty', 303);

    // Atomically reserve + decrement stock inside the DO (one synchronous pass),
    // so two concurrent carts can't both pass the stock check and oversell — the
    // previous read-then-decrement-across-RPCs pattern was racy. Returns the
    // granted qty plus server-trusted price/name per line.
    const granted = await stub.reserveStock(sellable, reqLines);
    const lines = granted
      .filter((g) => g.granted > 0)
      .map((g) => ({ id: g.id, name: g.name, price: g.price, qty: g.granted }));
    if (lines.length === 0) return c.redirect('/checkout?error=unavailable', 303);
    const subtotal = lines.reduce((n, l) => n + l.price * l.qty, 0);

    const result = await stub.addRecord({
      entity_slug: 'order',
      data: {
        customer_name: String(formData.get('name') ?? '').slice(0, 200),
        customer_email: String(formData.get('email') ?? '').slice(0, 200),
        shipping_address: String(formData.get('address') ?? '').slice(0, 1000),
        items: JSON.stringify(lines),
        item_count: lines.reduce((n, l) => n + l.qty, 0),
        subtotal,
        total: subtotal,
        status: 'Paid (test)',
        payment_ref: `TEST-${crypto.randomUUID().slice(0, 8).toUpperCase()}`,
      } as import('@pws/shared').RecordData,
      created_by: 'checkout:visitor',
    });
    if (!result.ok) return c.redirect('/checkout?error=server', 303);

    return c.redirect(`/order/${result.record.id}`, 303);
  });

  // ── Order confirmation ─────────────────────────────────────────────
  app.get('/order/:id', async (c) => serveOrderPage(c.env, siteId, c.req.param('id')));

  // ── PWA ────────────────────────────────────────────────────────────
  app.get('/manifest.json', async (c) => {
    const stub = siteStub(c.env, siteId);
    const snap = await stub.siteSnapshot();
    const title = snap.config.title ?? siteId;
    const color = snap.theme?.colors?.primary ?? '#6366f1';
    // generateManifest already returns a JSON string — use c.body, not c.json
    // (which would stringify it a second time and serve a quoted string literal,
    // silently breaking PWA install/icons/theme).
    return c.body(
      generateManifest({
        name: title,
        shortName: title,
        startUrl: '/',
        themeColor: color,
        bgColor: snap.theme?.colors?.background ?? '#ffffff',
        iconLetter: title[0] ?? 'W',
        iconBgColor: color,
      }),
      200,
      { 'Content-Type': 'application/manifest+json', 'Cache-Control': 'public, max-age=86400' },
    );
  });

  app.get('/sw.js', (c) =>
    c.body(MINIMAL_SW, 200, {
      'Content-Type': 'application/javascript',
      'Cache-Control': 'public, max-age=3600',
    }),
  );

  app.get('/favicon.ico', async (c) => {
    const stub = siteStub(c.env, siteId);
    const snap = await stub.siteSnapshot();
    return c.body(
      svgIcon(snap.config.title?.[0] ?? 'W', snap.theme?.colors?.primary ?? '#6366f1'),
      200,
      { 'Content-Type': 'image/svg+xml', 'Cache-Control': 'public, max-age=86400' },
    );
  });

  app.get('/icon.svg', async (c) => {
    const stub = siteStub(c.env, siteId);
    const snap = await stub.siteSnapshot();
    return c.body(
      svgIcon(snap.config.title?.[0] ?? 'W', snap.theme?.colors?.primary ?? '#6366f1'),
      200,
      { 'Content-Type': 'image/svg+xml', 'Cache-Control': 'public, max-age=86400' },
    );
  });

  // ── robots.txt ─────────────────────────────────────────────────────
  app.get('/robots.txt', (c) =>
    c.text(
      isWorkersDev(c.req.url)
        ? 'User-agent: *\nDisallow: /\n'
        : `User-agent: *\nAllow: /\nSitemap: https://${c.req.header('host') ?? `${siteId}.prowebstore.online`}/sitemap.xml`,
    ),
  );

  // ── Sitemap ────────────────────────────────────────────────────────
  app.get('/sitemap.xml', async (c) => {
    const stub = siteStub(c.env, siteId);
    const pages = await stub.listPages();
    const host = c.req.header('host') ?? `${siteId}.prowebstore.online`;
    const urls = pages
      .filter((p) => !p.seo?.noindex)
      .map((p) => `  <url><loc>https://${host}${p.slug}</loc></url>`)
      .join('\n');
    return c.body(
      `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>`,
      200,
      { 'Content-Type': 'application/xml' },
    );
  });

  // ── RSS feed ────────────────────────────────────────────────────────
  app.get('/feed.xml', async (c) => {
    const stub = siteStub(c.env, siteId);
    const snap = await stub.siteSnapshot();
    const host = c.req.header('host') ?? `${siteId}.prowebstore.online`;
    const title = snap.config.title ?? siteId;
    const desc = snap.config.description ?? '';

    // Collect entity records that look like blog/news content
    const schemas = await stub.listSchemas();
    const contentSchema = schemas.find(
      (s) =>
        s.slug === 'blog_post' || s.slug === 'post' || s.slug === 'article' || s.slug === 'news',
    );

    let items = '';
    if (contentSchema) {
      const records = await stub.listRecords(contentSchema.slug, { limit: 20 });
      const sorted = records
        .filter((r) => r.status === 'live')
        .sort((a, b) => b.updated_at.localeCompare(a.updated_at));
      items = sorted
        .map((r) => {
          const rTitle = String(r.data.title ?? r.data.name ?? 'Untitled');
          const rDesc = String(r.data.excerpt ?? r.data.description ?? '').slice(0, 500);
          const slug = r.slug ?? r.id;
          const plural = contentSchema.name_plural.toLowerCase().replace(/\s+/g, '-');
          return `    <item>
      <title>${escXml(rTitle)}</title>
      <link>https://${host}/${plural}/${slug}</link>
      <description>${escXml(rDesc)}</description>
      <pubDate>${new Date(r.created_at).toUTCString()}</pubDate>
      <guid>https://${host}/${plural}/${slug}</guid>
    </item>`;
        })
        .join('\n');
    }

    const rss = `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
  <channel>
    <title>${escXml(title)}</title>
    <link>https://${host}</link>
    <description>${escXml(desc)}</description>
    <atom:link href="https://${host}/feed.xml" rel="self" type="application/rss+xml"/>
${items}
  </channel>
</rss>`;
    return c.body(rss, 200, {
      'Content-Type': 'application/rss+xml; charset=utf-8',
      'Cache-Control': 'public, max-age=3600',
    });
  });

  // ── Member auth POST routes ────────────────────────────────────────
  app.post('/login', async (c) => {
    if (c.env.AUTH_RATE_LIMIT) {
      const ip = c.req.header('cf-connecting-ip') ?? 'unknown';
      const { success } = await c.env.AUTH_RATE_LIMIT.limit({ key: `auth:${siteId}:${ip}` });
      if (!success)
        return c.redirect(`/login?error=${encodeURIComponent('Too many attempts.')}`, 303);
    }
    const form = await c.req.formData();
    const email = String(form.get('email') ?? '').trim();
    const password = String(form.get('password') ?? '');
    const url = new URL(c.req.url);
    const redirectParam = url.searchParams.get('redirect') ?? '';
    const redirectQs = redirectParam ? `&redirect=${encodeURIComponent(redirectParam)}` : '';

    if (!email || !password)
      return c.redirect(
        `/login?error=${encodeURIComponent('Email and password required.')}${redirectQs}`,
        303,
      );

    const stub = siteStub(c.env, siteId);
    const result = await stub.authenticate(email, password);
    if (!result)
      return c.redirect(
        `/login?error=${encodeURIComponent('Invalid email or password.')}${redirectQs}`,
        303,
      );

    const cookie = buildSessionCookie(siteId, result.token, result.expires_at);
    // Require a path that starts with a single slash followed by a normal path
    // char. This rejects both `//evil.com` AND `/\evil.com` — browsers normalize
    // backslashes to slashes on special-scheme URLs, so `/\evil.com` would become
    // the protocol-relative `//evil.com` (open redirect to an attacker origin).
    const safe = redirectParam && /^\/[^/\\]/.test(redirectParam) ? redirectParam : '/';
    return new Response(null, { status: 303, headers: { Location: safe, 'Set-Cookie': cookie } });
  });

  app.post('/register', async (c) => {
    if (c.env.AUTH_RATE_LIMIT) {
      const ip = c.req.header('cf-connecting-ip') ?? 'unknown';
      const { success } = await c.env.AUTH_RATE_LIMIT.limit({ key: `reg:${siteId}:${ip}` });
      if (!success)
        return c.redirect(`/register?error=${encodeURIComponent('Too many attempts.')}`, 303);
    }
    const form = await c.req.formData();
    const email = String(form.get('email') ?? '').trim();
    const password = String(form.get('password') ?? '');
    const displayName = String(form.get('display_name') ?? '').trim();

    if (!email || !password)
      return c.redirect(
        `/register?error=${encodeURIComponent('Email and password required.')}`,
        303,
      );
    if (password.length < 8)
      return c.redirect(
        `/register?error=${encodeURIComponent('Password must be at least 8 characters.')}`,
        303,
      );

    const stub = siteStub(c.env, siteId);
    try {
      await stub.createUser({
        email,
        password,
        role: 'member',
        display_name: displayName || undefined,
      });
    } catch (err) {
      const raw = (err as Error).message;
      return c.redirect(
        `/register?error=${encodeURIComponent(raw.includes('already exists') ? raw : 'Registration failed.')}`,
        303,
      );
    }

    // Send welcome email (fire-and-forget)
    const cfg = emailConfigFromEnv(c.env);
    if (cfg) {
      const snap = await stub.siteSnapshot();
      const welcome = welcomeEmail(snap.config.title ?? siteId, displayName || email);
      welcome.to = email;
      sendEmail(cfg, welcome).catch(() => {});
    }

    const result = await stub.authenticate(email, password);
    if (!result)
      return c.redirect(
        `/login?error=${encodeURIComponent('Account created. Please sign in.')}`,
        303,
      );

    const cookie = buildSessionCookie(siteId, result.token, result.expires_at);
    return new Response(null, {
      status: 303,
      headers: { Location: '/profile', 'Set-Cookie': cookie },
    });
  });

  app.post('/logout', async (c) => {
    const parsed = parseSessionCookie(c.req.header('cookie'));
    if (parsed) {
      const stub = siteStub(c.env, siteId);
      await stub.revokeSession(parsed.token);
    }
    return new Response(null, {
      status: 303,
      headers: { Location: '/', 'Set-Cookie': clearSessionCookie() },
    });
  });

  // ── Page rendering (catch-all) ─────────────────────────────────────
  app.get('*', async (c) => {
    let pagePath = new URL(c.req.url).pathname || '/';
    if (pagePath !== '/' && pagePath.endsWith('/')) pagePath = pagePath.slice(0, -1);
    if (pagePath.includes('..') || pagePath.includes('//')) return c.text('Not found', 404);
    return serveSitePage(c.env, siteId, pagePath, c.req.raw);
  });
}

function escXml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function isWorkersDev(url: string): boolean {
  return new URL(url).hostname.endsWith('.workers.dev');
}
