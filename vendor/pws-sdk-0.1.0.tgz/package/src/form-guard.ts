// Abuse protection for public form submissions (POST /_/form), shared by both
// render stacks (#51). One implementation, consumed twice (DECISIONS §22): the
// shared Worker's routes/tenant.ts and the isolated tier's site-routes.ts both
// call these, so the two cannot drift. The policy is §27/§28's: a per-site,
// per-client rate limit, then a Turnstile check when a secret is configured.

const SITEVERIFY = 'https://challenges.cloudflare.com/turnstile/v0/siteverify';
/** Turnstile tokens are at most 2048 characters. Anything longer is not one. */
const MAX_TOKEN_LENGTH = 2048;

export interface FormGuardEnv {
  FORM_RATE_LIMIT?: { limit: (input: { key: string }) => Promise<{ success: boolean }> };
  TURNSTILE_SECRET_KEY?: string;
}

/**
 * The visitor's IP as Cloudflare's edge saw it. Only `cf-connecting-ip` is
 * trusted: the edge sets it on every request and overwrites a client-supplied
 * one. `x-forwarded-for` is whatever the client chose to send — keying a rate
 * limit on it lets one client rotate through unlimited buckets.
 */
export function clientIp(headers: Headers): string | null {
  return headers.get('cf-connecting-ip')?.trim() || null;
}

async function sha256Hex(input: string, bytes: number): Promise<string> {
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(input));
  return Array.from(new Uint8Array(digest).slice(0, bytes))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

/**
 * Per site, per client — without handing the limiter the address. A request
 * with no trusted IP only happens off the edge (tests, subrequests); those
 * share one bucket per site rather than escaping the limit.
 */
export async function formRateLimitKey(siteId: string, ip: string | null): Promise<string> {
  return `form:${siteId}:${ip ? await sha256Hex(`${siteId}:${ip}`, 16) : 'no-ip'}`;
}

/** True when this client has used up the site's form rate limit. No binding, no limit. */
export async function isFormRateLimited(
  env: FormGuardEnv,
  siteId: string,
  headers: Headers,
): Promise<boolean> {
  if (!env.FORM_RATE_LIMIT) return false;
  const key = await formRateLimitKey(siteId, clientIp(headers));
  const { success } = await env.FORM_RATE_LIMIT.limit({ key });
  return !success;
}

/**
 * What a flat submission stores for duplicate detection: a truncated hash of
 * the trusted IP, never the address (the same format the shared stack has
 * always stored).
 */
export async function hashedClientIp(headers: Headers): Promise<string | undefined> {
  const ip = clientIp(headers);
  return ip ? sha256Hex(ip, 8) : undefined;
}

/**
 * - `skipped`: no secret configured. §27's deliberate fail-open, visible on
 *   GET /admin/integrations as `turnstile: false`.
 * - `passed`: siteverify accepted the token.
 * - `missing` / `rejected`: no token, a malformed one, or siteverify said no.
 * - `unavailable`: siteverify could not be reached or answered garbage. This
 *   fails CLOSED: an outage must not let unverified submissions through.
 */
export type TurnstileOutcome = 'skipped' | 'passed' | 'missing' | 'rejected' | 'unavailable';

export async function verifyTurnstile(
  env: FormGuardEnv,
  formData: FormData,
  headers: Headers,
  fetchImpl: typeof fetch = fetch,
): Promise<TurnstileOutcome> {
  if (!env.TURNSTILE_SECRET_KEY) return 'skipped';
  const token = formData.get('cf-turnstile-response');
  if (typeof token !== 'string' || token.length === 0) return 'missing';
  if (token.length > MAX_TOKEN_LENGTH) return 'rejected';

  const body = new URLSearchParams({ secret: env.TURNSTILE_SECRET_KEY, response: token });
  const ip = clientIp(headers);
  if (ip) body.set('remoteip', ip);
  try {
    const res = await fetchImpl(SITEVERIFY, {
      method: 'POST',
      body,
      signal: AbortSignal.timeout(10_000),
    });
    const result = (await res.json()) as { success?: unknown };
    return result.success === true ? 'passed' : 'rejected';
  } catch {
    return 'unavailable';
  }
}

/** Whether a submission may be stored, given its Turnstile outcome. */
export function turnstileAllows(outcome: TurnstileOutcome): boolean {
  return outcome === 'passed' || outcome === 'skipped';
}
