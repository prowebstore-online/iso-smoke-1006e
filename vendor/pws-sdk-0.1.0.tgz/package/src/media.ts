import type { ImageValue } from '@pws/shared';
import { nanoid } from 'nanoid';
import type { Env } from './env.ts';

const ALLOWED_TYPES = new Set(['image/jpeg', 'image/png', 'image/webp', 'image/gif']);

const MAX_SIZE = 5 * 1024 * 1024; // 5 MB

export async function serveImage(
  env: Env,
  siteId: string,
  assetId: string,
  opts?: { width?: number; request?: Request },
): Promise<Response> {
  // Reject anything that isn't a clean nanoid-shaped token.
  if (!/^[A-Za-z0-9_-]{12}$/.test(assetId)) {
    return new Response('Not found', { status: 404 });
  }

  // On-the-fly thumbnail via Cloudflare Image Resizing. Gated on env.IMAGE_RESIZING
  // so it's a pure no-op (serve the original, no extra subrequest) until the zone
  // has Image Resizing enabled and the var is set. Loop-safe: the resize fetch
  // hits the same path WITHOUT ?w, which serves the raw R2 object as the origin.
  const width = opts?.width;
  if (width && width > 0 && env.IMAGE_RESIZING && opts?.request) {
    try {
      const origin = new URL(opts.request.url);
      origin.search = '';
      return await fetch(origin.toString(), {
        cf: {
          image: { width: Math.min(width, 2000), fit: 'scale-down', quality: 82, format: 'auto' },
        },
      } as unknown as RequestInit);
    } catch {
      // fall through to the raw object
    }
  }

  const key = `${siteId}/${assetId}`;
  const obj = await env.MEDIA!.get(key);
  if (!obj) return new Response('Not found', { status: 404 });
  return new Response(obj.body, {
    headers: {
      'Content-Type': obj.httpMetadata?.contentType ?? 'application/octet-stream',
      'Cache-Control': 'public, max-age=31536000, immutable',
      'X-Content-Type-Options': 'nosniff',
      'Content-Security-Policy': "default-src 'none'",
    },
  });
}

export async function uploadImage(
  env: Env,
  siteId: string,
  file: File,
  alt: string,
): Promise<ImageValue> {
  const contentType = file.type;
  if (!ALLOWED_TYPES.has(contentType)) {
    throw new Error(`Unsupported image type: ${contentType}`);
  }
  if (file.size > MAX_SIZE) {
    throw new Error(`Image too large (${file.size} bytes, max ${MAX_SIZE})`);
  }
  const assetId = nanoid(12);
  const key = `${siteId}/${assetId}`;
  await env.MEDIA!.put(key, file.stream(), {
    httpMetadata: { contentType },
  });
  return { asset_id: assetId, alt };
}

export function isPrivateHost(host: string): boolean {
  if (host === 'localhost' || host === '0.0.0.0' || host === '[::1]') return true;
  if (
    host.startsWith('0.') ||
    host.startsWith('127.') ||
    host.startsWith('10.') ||
    host.startsWith('192.168.') ||
    host.startsWith('169.254.') ||
    host.startsWith('100.64.') ||
    host.startsWith('198.18.') ||
    host.startsWith('198.19.')
  )
    return true;
  // 172.16.0.0 – 172.31.255.255
  if (host.startsWith('172.')) {
    const second = Number.parseInt(host.split('.')[1] ?? '', 10);
    if (second >= 16 && second <= 31) return true;
  }
  // IPv6 private/loopback (bracket-wrapped in URLs)
  const bare = host.replace(/^\[|\]$/g, '');
  if (
    bare === '::1' ||
    bare.startsWith('fc') ||
    bare.startsWith('fd') ||
    bare.startsWith('fe80') ||
    bare.startsWith('::ffff:')
  )
    return true;
  return false;
}

export async function uploadImageFromUrl(
  env: Env,
  siteId: string,
  url: string,
  alt: string,
): Promise<ImageValue> {
  const parsed = new URL(url);
  if (parsed.protocol !== 'https:') {
    throw new Error('Only HTTPS URLs are allowed');
  }
  const host = parsed.hostname;
  if (isPrivateHost(host)) {
    throw new Error('Private/local URLs are not allowed');
  }

  const res = await fetch(url, {
    headers: { Accept: 'image/*' },
    redirect: 'error',
  });
  if (!res.ok) {
    throw new Error('Failed to fetch image from the provided URL');
  }

  // Pre-check Content-Length to avoid buffering oversized responses.
  const cl = res.headers.get('content-length');
  if (cl && Number(cl) > MAX_SIZE) {
    throw new Error(`Image too large (${cl} bytes, max ${MAX_SIZE})`);
  }

  const contentType = res.headers.get('content-type')?.split(';')[0]?.trim() ?? '';
  if (!ALLOWED_TYPES.has(contentType)) {
    throw new Error('Unsupported image type from URL');
  }

  // Stream with size cap to prevent OOM from chunked responses without Content-Length.
  const reader = res.body!.getReader();
  const chunks: Uint8Array[] = [];
  let totalSize = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    totalSize += value.byteLength;
    if (totalSize > MAX_SIZE) {
      reader.cancel();
      throw new Error(`Image too large (exceeded ${MAX_SIZE} bytes during download)`);
    }
    chunks.push(value);
  }

  const blob = new Blob(chunks, { type: contentType });
  const assetId = nanoid(12);
  const key = `${siteId}/${assetId}`;
  await env.MEDIA!.put(key, blob.stream(), {
    httpMetadata: { contentType },
  });
  return { asset_id: assetId, alt };
}

export async function serveFile(env: Env, siteId: string, fileId: string): Promise<Response> {
  if (!/^[A-Za-z0-9_-]{12}$/.test(fileId)) return new Response('Not found', { status: 404 });
  const prefix = `${siteId}/media/${fileId}-`;
  const listed = await env.MEDIA!.list({ prefix, limit: 1 });
  if (!listed.objects[0]) return new Response('Not found', { status: 404 });
  const full = await env.MEDIA!.get(listed.objects[0].key);
  if (!full) return new Response('Not found', { status: 404 });
  const ct = full.httpMetadata?.contentType ?? 'application/octet-stream';
  const isImage = ct.startsWith('image/');
  const isSvg = ct === 'image/svg+xml';
  const isScript = ct.includes('javascript') || ct === 'text/css';
  return new Response(full.body, {
    headers: {
      'Content-Type': ct,
      'Cache-Control':
        isImage && !isSvg ? 'public, max-age=31536000, immutable' : 'public, max-age=86400',
      'X-Content-Type-Options': 'nosniff',
      'Content-Security-Policy': "default-src 'none'",
      ...(isSvg || isScript ? { 'Content-Disposition': 'attachment' } : {}),
    },
  });
}
