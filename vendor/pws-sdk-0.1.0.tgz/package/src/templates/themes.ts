// Theme presets — ready-to-use color/font/spacing combinations.
// Template authors pick one and optionally override specific tokens.

import type { Theme } from '@pws/shared';

/** Warm neutral — navy + gold accent, serif headings. Classic and trustworthy. */
export const warmNeutral: Theme = {
  colors: {
    primary: '#1e3a5f',
    secondary: '#4a6fa5',
    accent: '#c49b3c',
    background: '#faf9f7',
    surface: '#ffffff',
    text: '#2d3748',
    heading: '#1a202c',
  },
  fonts: { heading: 'Fraunces, Georgia, serif', body: 'Manrope, system-ui, sans-serif' },
  radius: 'md',
  shadow: 'sm',
  spacing: 'relaxed',
};

/** Modern clean — blue + emerald accent, all sans-serif. Tech-forward. */
export const modernClean: Theme = {
  colors: {
    primary: '#2563eb',
    secondary: '#3b82f6',
    accent: '#10b981',
    background: '#ffffff',
    surface: '#f8fafc',
    text: '#334155',
    heading: '#0f172a',
  },
  fonts: { heading: 'Inter, system-ui, sans-serif', body: 'Inter, system-ui, sans-serif' },
  radius: 'lg',
  shadow: 'md',
  spacing: 'normal',
};

/** Dark elegant — purple accent, serif headings. Premium feel. */
export const darkElegant: Theme = {
  colors: {
    primary: '#a78bfa',
    secondary: '#818cf8',
    accent: '#f59e0b',
    background: '#0f172a',
    surface: '#1e293b',
    text: '#e2e8f0',
    heading: '#f8fafc',
  },
  fonts: { heading: 'Fraunces, Georgia, serif', body: 'Manrope, system-ui, sans-serif' },
  radius: 'md',
  shadow: 'lg',
  spacing: 'relaxed',
};

/** Earth tones — olive + terracotta. Organic, grounded. */
export const earthTones: Theme = {
  colors: {
    primary: '#4a5d23',
    secondary: '#6b7f3b',
    accent: '#c4704b',
    background: '#faf8f5',
    surface: '#ffffff',
    text: '#3d3d3d',
    heading: '#2a2a2a',
  },
  fonts: { heading: 'Fraunces, Georgia, serif', body: 'Manrope, system-ui, sans-serif' },
  radius: 'sm',
  shadow: 'sm',
  spacing: 'relaxed',
};

/** Bold minimal — black + red accent, tight spacing. Statement. */
export const boldMinimal: Theme = {
  colors: {
    primary: '#18181b',
    secondary: '#3f3f46',
    accent: '#dc2626',
    background: '#ffffff',
    surface: '#fafafa',
    text: '#27272a',
    heading: '#09090b',
  },
  fonts: { heading: 'Inter, system-ui, sans-serif', body: 'Inter, system-ui, sans-serif' },
  radius: 'none',
  shadow: 'none',
  spacing: 'compact',
};

/** Soft pastel — lavender + rose. Friendly, approachable. */
export const softPastel: Theme = {
  colors: {
    primary: '#7c3aed',
    secondary: '#a78bfa',
    accent: '#f472b6',
    background: '#faf5ff',
    surface: '#ffffff',
    text: '#4b5563',
    heading: '#1f2937',
  },
  fonts: { heading: 'Manrope, system-ui, sans-serif', body: 'Manrope, system-ui, sans-serif' },
  radius: 'lg',
  shadow: 'sm',
  spacing: 'normal',
};
