// Reusable entity schema libraries.
// Template authors compose from these instead of redefining common patterns.
// Each function returns an EntityDef that can be spread into a template's schemas array.

import { type EntityDef, bool, entity, f, multi, ref, req, sel } from './helpers.ts';

// ============================================================
//  PEOPLE — staff, team, leadership
// ============================================================

/** Basic team member (name, role, photo, bio). Used by most templates. */
export const teamMember = (opts?: { departments?: string[]; roleTypes?: string[] }): EntityDef =>
  entity('person', 'Team Member', 'Team', '👤', [
    req('name', 'Name', 'text'),
    req('role', 'Role', 'text'),
    f('photo', 'Photo', 'image'),
    f('bio', 'Bio', 'richtext'),
    f('email', 'Email', 'email'),
    f('phone', 'Phone', 'phone'),
    ...(opts?.departments ? [sel('department', 'Department', opts.departments)] : []),
    ...(opts?.roleTypes ? [sel('role_type', 'Role Type', opts.roleTypes)] : []),
    f('order', 'Display Order', 'number', { default: 0 }),
  ]);

/** Staff member with social links (for portfolios, agencies). */
export const teamMemberSocial = (): EntityDef =>
  entity('person', 'Team Member', 'Team', '👤', [
    req('name', 'Name', 'text'),
    req('role', 'Role', 'text'),
    f('photo', 'Photo', 'image'),
    f('bio', 'Bio', 'richtext'),
    f('email', 'Email', 'email'),
    f('website', 'Website', 'url'),
    f('linkedin', 'LinkedIn', 'url'),
    f('twitter', 'Twitter/X', 'url'),
    f('order', 'Display Order', 'number', { default: 0 }),
  ]);

// ============================================================
//  CONTACT / FORMS — connect cards, inquiries, newsletter
// ============================================================

/** Generic contact inquiry (name, email, phone, message). */
export const contactInquiry = (slug = 'contact_inquiry', name = 'Contact Inquiry'): EntityDef =>
  entity(
    slug,
    name,
    `${name}s`,
    '✉',
    [
      req('name', 'Name', 'text'),
      req('email', 'Email', 'email'),
      f('phone', 'Phone', 'phone'),
      f('message', 'Message', 'text'),
    ],
    { public_writable: true },
  );

/** Connect card with reason multiselect (for churches, orgs). */
export const connectCard = (reasons: string[]): EntityDef =>
  entity(
    'connect_card',
    'Connect Card',
    'Connect Cards',
    '✉',
    [
      req('name', 'Name', 'text'),
      req('email', 'Email', 'email'),
      f('phone', 'Phone', 'phone'),
      multi('reason', 'I want to...', reasons),
      f('message', 'Message', 'text'),
    ],
    { public_writable: true },
  );

/** Newsletter signup (email + name + optional interests). */
export const newsletterSignup = (interests?: string[]): EntityDef =>
  entity(
    'newsletter_signup',
    'Newsletter Signup',
    'Newsletter Signups',
    '📧',
    [
      req('email', 'Email', 'email'),
      f('name', 'Name', 'text'),
      ...(interests ? [multi('interests', 'Interests', interests)] : []),
    ],
    { public_writable: true },
  );

// ============================================================
//  CONTENT — blog, photo albums, testimonials
// ============================================================

/** Blog / news posts with author reference. */
export const blogPost = (categories: string[]): EntityDef =>
  entity('blog_post', 'Blog Post', 'Blog Posts', '📝', [
    req('title', 'Title', 'text'),
    req('date', 'Date', 'date'),
    ref('author', 'Author', 'person'),
    req('body', 'Body', 'richtext'),
    f('excerpt', 'Excerpt', 'text'),
    f('image', 'Cover Image', 'image'),
    sel('category', 'Category', categories),
    bool('featured', 'Featured'),
  ]);

/** Photo albums with category. */
export const photoAlbum = (categories: string[]): EntityDef =>
  entity('photo_album', 'Photo Album', 'Photo Albums', '📸', [
    req('title', 'Title', 'text'),
    f('date', 'Date', 'date'),
    f('description', 'Description', 'text'),
    f('cover_image', 'Cover Image', 'image'),
    sel('category', 'Category', categories),
  ]);

/** Testimonials / stories with pull quote. */
export const testimony = (categories: string[]): EntityDef =>
  entity('testimony', 'Testimony', 'Testimonies', '💬', [
    req('name', 'Name', 'text'),
    req('quote', 'Pull Quote', 'text'),
    f('story', 'Full Story', 'richtext'),
    f('photo', 'Photo', 'image'),
    f('date', 'Date', 'date'),
    sel('category', 'Category', categories),
  ]);

// ============================================================
//  EVENTS — events, registration
// ============================================================

/** Event with optional registration, cost, capacity. */
export const event = (categories: string[]): EntityDef =>
  entity('event', 'Event', 'Events', '📅', [
    req('title', 'Title', 'text'),
    req('date', 'Date', 'date'),
    req('time', 'Time', 'text'),
    f('location', 'Location', 'text'),
    f('description', 'Description', 'richtext'),
    f('image', 'Image', 'image'),
    sel('category', 'Category', categories),
    bool('recurring', 'Recurring'),
    f('cost', 'Cost', 'text'),
    bool('registration_required', 'Registration Required'),
    f('max_attendees', 'Max Attendees', 'number'),
    ref('contact_person', 'Contact', 'person'),
  ]);

/** Event registration (public form). */
export const eventRegistration = (): EntityDef =>
  entity(
    'event_registration',
    'Event Registration',
    'Event Registrations',
    '✅',
    [
      req('name', 'Name', 'text'),
      req('email', 'Email', 'email'),
      f('phone', 'Phone', 'phone'),
      f('number_attending', 'Number Attending', 'number', { default: 1 }),
      bool('childcare_needed', 'Childcare Needed'),
      f('dietary_needs', 'Dietary Needs', 'text'),
      f('notes', 'Notes', 'text'),
    ],
    { public_writable: true },
  );

// ============================================================
//  GIVING / VOLUNTEER — donations, volunteer signups
// ============================================================

/** Donation / giving funds. */
export const donationFund = (categories: string[]): EntityDef =>
  entity('donation_fund', 'Giving Fund', 'Giving Funds', '💛', [
    req('name', 'Fund Name', 'text'),
    f('description', 'Description', 'richtext'),
    f('goal_amount', 'Goal Amount', 'number'),
    sel('category', 'Category', categories),
    bool('active', 'Active', true),
  ]);

/** Volunteer signup (public form). */
export const volunteerSignup = (): EntityDef =>
  entity(
    'volunteer_signup',
    'Volunteer Signup',
    'Volunteer Signups',
    '🙋',
    [
      req('name', 'Name', 'text'),
      req('email', 'Email', 'email'),
      f('phone', 'Phone', 'phone'),
      ref('role', 'Role Interest', 'ministry'),
      f('availability', 'Availability', 'text'),
      f('experience', 'Experience', 'text'),
      f('message', 'Message', 'text'),
    ],
    { public_writable: true },
  );

// ============================================================
//  SERVICE TIMES
// ============================================================

const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

/** Structured service times (day, time, location, childcare, livestream, language). */
export const serviceTime = (): EntityDef =>
  entity('service_time', 'Service Time', 'Service Times', '🕐', [
    req('name', 'Service Name', 'text'),
    sel('day', 'Day', DAYS, { required: true }),
    req('time', 'Time', 'text'),
    f('location', 'Location', 'text'),
    f('description', 'Description', 'text'),
    bool('childcare_available', 'Childcare Available'),
    bool('livestream_available', 'Livestream Available'),
    f('language', 'Language', 'text'),
    f('order', 'Display Order', 'number', { default: 0 }),
  ]);

// ============================================================
//  MISSIONS
// ============================================================

/** Missionary / mission partner. */
export const missionary = (): EntityDef =>
  entity('missionary', 'Missionary', 'Missionaries & Partners', '🌍', [
    req('name', 'Name', 'text'),
    f('location', 'Location', 'text'),
    f('organization', 'Organization', 'text'),
    f('description', 'Description', 'richtext'),
    f('photo', 'Photo', 'image'),
    f('prayer_needs', 'Prayer Needs', 'richtext'),
    f('update_date', 'Last Update', 'date'),
    f('support_url', 'Support Link', 'url'),
    bool('active', 'Active', true),
  ]);
