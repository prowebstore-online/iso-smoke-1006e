// Template authoring helpers — compact field, block, and admin view builders.
// Used by all templates to reduce verbosity.

import type { FieldDef } from '@pws/shared';

type FT = FieldDef['type'];

// -- Field helpers --
export const f = (slug: string, name: string, type: FT, extra?: Partial<FieldDef>): FieldDef =>
  ({ slug, name, type, ...extra }) as FieldDef;
export const req = (slug: string, name: string, type: FT, extra?: Partial<FieldDef>): FieldDef =>
  f(slug, name, type, { required: true, ...extra });
export const ref = (slug: string, name: string, to: string): FieldDef =>
  f(slug, name, 'reference', { reference_to: to });
export const refList = (slug: string, name: string, to: string): FieldDef =>
  f(slug, name, 'reference_list', { reference_to: to });
export const sel = (
  slug: string,
  name: string,
  options: string[],
  extra?: Partial<FieldDef>,
): FieldDef => f(slug, name, 'select', { options, ...extra });
export const multi = (slug: string, name: string, options: string[]): FieldDef =>
  f(slug, name, 'multiselect', { options });
export const bool = (slug: string, name: string, def = false): FieldDef =>
  f(slug, name, 'boolean', { default: def });

// -- Block helpers --
export const hero = (
  id: string,
  heading: string,
  sub?: string,
  opts?: Record<string, unknown>,
) => ({
  id,
  _type: 'hero' as const,
  heading,
  subheading: sub,
  alignment: 'left' as const,
  ...opts,
});
export const grid = (
  id: string,
  entity: string,
  fields: string[],
  opts?: Record<string, unknown>,
) => ({
  id,
  _type: 'entity_grid' as const,
  entity,
  display_fields: fields,
  layout: 'cards' as const,
  ...opts,
});
export const cta = (id: string, heading: string, text: string, label: string, url: string) => ({
  id,
  _type: 'cta' as const,
  heading,
  text,
  cta_text: label,
  cta_url: url,
});
export const richtext = (id: string, body: string) => ({ id, _type: 'richtext' as const, body });
export const features = (
  id: string,
  heading: string,
  items: Array<{ title: string; description: string }>,
) => ({ id, _type: 'features' as const, heading, items });

// -- Admin view helpers --
export const tbl = (
  entity: string,
  label: string,
  icon: string,
  order: number,
  columns: string[],
) => ({
  entity_slug: entity,
  label,
  icon,
  layout: 'table' as const,
  sort_order: order,
  config: { columns },
});
export const cardView = (
  entity: string,
  label: string,
  icon: string,
  order: number,
  img: string,
  title: string,
  sub: string,
) => ({
  entity_slug: entity,
  label,
  icon,
  layout: 'cards' as const,
  sort_order: order,
  config: { image_field: img, title_field: title, subtitle_field: sub },
});

// -- Schema helper --
export interface EntityDef {
  slug: string;
  name: string;
  name_plural: string;
  icon?: string;
  public_writable?: boolean;
  fields: FieldDef[];
}

export const entity = (
  slug: string,
  name: string,
  name_plural: string,
  icon: string,
  fields: FieldDef[],
  opts?: { public_writable?: boolean },
): EntityDef => ({ slug, name, name_plural, icon, fields, ...opts });
