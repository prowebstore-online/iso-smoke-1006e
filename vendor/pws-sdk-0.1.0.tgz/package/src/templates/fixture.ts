import type { TemplateBundle } from '@pws/shared';

/**
 * The portable, dev-only contract for an isolated-site template. It names the
 * exact product bundle to apply and pins the content shape expected afterwards.
 * It deliberately does not perform provisioning or invoke a live Worker.
 */
export interface TemplateFixture {
  template: TemplateBundle;
  expected: {
    schemas: number;
    records: number;
    pages: number;
  };
}

export interface TemplateApplier {
  applyTemplate(
    template: TemplateBundle,
  ): Promise<{ schemas: number; records: number; pages: number }>;
}

export function createTemplateFixture(template: TemplateBundle): TemplateFixture {
  return {
    template,
    expected: {
      schemas: template.schemas.length,
      records: Object.values(template.records).reduce(
        (total, records) => total + records.length,
        0,
      ),
      pages: template.pages.length,
    },
  };
}

/**
 * Apply a fixture through a runtime's normal template API and fail loudly if
 * it did not materialize the product bundle in full. Callers must opt in; this
 * helper never discovers credentials, creates sites, or deploys anything.
 */
export async function applyTemplateFixture(
  applier: TemplateApplier,
  fixture: TemplateFixture,
): Promise<{ schemas: number; records: number; pages: number }> {
  const applied = await applier.applyTemplate(fixture.template);
  for (const key of ['schemas', 'records', 'pages'] as const) {
    if (applied[key] !== fixture.expected[key]) {
      throw new Error(
        `Template fixture '${fixture.template.slug}' applied ${applied[key]} ${key}; expected ${fixture.expected[key]}`,
      );
    }
  }
  return applied;
}
