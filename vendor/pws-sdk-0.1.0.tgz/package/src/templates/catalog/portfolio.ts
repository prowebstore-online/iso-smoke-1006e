import type { TemplateBundle } from '@pws/shared';

const PERSON_IDS = {
  alex: 'b0000000-0000-0000-0000-000000000001',
  jordan: 'b0000000-0000-0000-0000-000000000002',
  mika: 'b0000000-0000-0000-0000-000000000003',
};

export const portfolioTemplate: TemplateBundle = {
  slug: 'portfolio',
  name: 'Portfolio / Agency',
  description:
    'Creative work showcase with client projects, team profiles, and project inquiry form. For agencies, studios, and freelancers.',
  icon: 'W',
  verticals: [
    'design agency',
    'photography',
    'architecture',
    'video production',
    'creative studio',
  ],
  combines_with: ['blog', 'professional', 'ecommerce'],

  schemas: [
    {
      slug: 'person',
      name: 'Team Member',
      name_plural: 'Team',
      icon: 'P',
      fields: [
        { slug: 'name', name: 'Name', type: 'text', required: true },
        { slug: 'role', name: 'Role', type: 'text', required: true },
        { slug: 'photo', name: 'Photo', type: 'image' },
        { slug: 'bio', name: 'Bio', type: 'richtext' },
        {
          slug: 'specialties',
          name: 'Specialties',
          type: 'multiselect',
          options: [
            'Brand Identity',
            'Web Design',
            'UX/UI',
            'Motion',
            'Photography',
            'Art Direction',
            'Strategy',
            'Development',
          ],
        },
        { slug: 'website', name: 'Website', type: 'url' },
        { slug: 'linkedin', name: 'LinkedIn', type: 'url' },
      ],
    },
    {
      slug: 'project',
      name: 'Project',
      name_plural: 'Projects',
      icon: 'J',
      fields: [
        { slug: 'title', name: 'Title', type: 'text', required: true },
        { slug: 'client', name: 'Client', type: 'text' },
        {
          slug: 'category',
          name: 'Category',
          type: 'select',
          options: [
            'Brand Identity',
            'Web Design',
            'Packaging',
            'Campaign',
            'Product Design',
            'Photography',
          ],
        },
        { slug: 'year', name: 'Year', type: 'number' },
        { slug: 'cover_image', name: 'Cover Image', type: 'image', required: true },
        { slug: 'description', name: 'Description', type: 'richtext', required: true },
        {
          slug: 'tags',
          name: 'Tags',
          type: 'multiselect',
          options: [
            'branding',
            'digital',
            'print',
            'motion',
            'photography',
            'packaging',
            'strategy',
            'development',
          ],
        },
        { slug: 'lead', name: 'Project Lead', type: 'reference', reference_to: 'person' },
        { slug: 'url', name: 'Live URL', type: 'url' },
        { slug: 'testimonial_quote', name: 'Client Quote', type: 'text' },
        { slug: 'testimonial_author', name: 'Quote Author', type: 'text' },
      ],
    },
    {
      slug: 'project_inquiry',
      name: 'Project Inquiry',
      name_plural: 'Project Inquiries',
      icon: 'Q',
      public_writable: true,
      fields: [
        { slug: 'name', name: 'Name', type: 'text', required: true },
        { slug: 'email', name: 'Email', type: 'email', required: true },
        { slug: 'company', name: 'Company', type: 'text' },
        {
          slug: 'project_type',
          name: 'Project Type',
          type: 'select',
          options: ['Brand Identity', 'Web Design', 'Packaging', 'Campaign', 'Other'],
        },
        {
          slug: 'budget',
          name: 'Budget Range',
          type: 'select',
          options: ['Under $10k', '$10k-$25k', '$25k-$50k', '$50k-$100k', '$100k+'],
        },
        { slug: 'timeline', name: 'Timeline', type: 'text' },
        { slug: 'message', name: 'About Your Project', type: 'text', required: true },
      ],
    },
  ],

  records: {
    person: [
      {
        name: 'Alex Thornton',
        role: 'Creative Director',
        bio: '<p>Alex founded the studio in 2019 after a decade at Pentagram and Collins. Specializes in brand systems that scale from business card to billboard.</p>',
        specialties: ['Brand Identity', 'Art Direction', 'Strategy'],
      },
      {
        name: 'Jordan Okafor',
        role: 'Design Lead',
        bio: '<p>Jordan brings digital-first thinking to every project. Previously led design at two YC startups and freelanced for Google, Stripe, and Notion.</p>',
        specialties: ['Web Design', 'UX/UI', 'Development'],
      },
      {
        name: 'Mika Sato',
        role: 'Senior Designer',
        bio: "<p>Mika's work lives at the intersection of print and digital. Award-winning packaging designer turned brand strategist with a knack for turning constraints into concepts.</p>",
        specialties: ['Packaging', 'Brand Identity', 'Photography'],
      },
    ],
    project: [
      {
        title: 'Solstice Coffee Roasters',
        client: 'Solstice Coffee',
        category: 'Brand Identity',
        year: 2026,
        description:
          '<h2>The Brief</h2><p>Solstice needed a complete rebrand to match their evolution from single-origin roaster to multi-city cafe chain. The old identity felt artisanal and local — the new one needed to feel premium and scalable without losing warmth.</p><h2>The Work</h2><p>We developed a flexible brand system anchored by a custom wordmark, a modular color palette that shifts by season, and packaging that tells the story of each origin. The system spans retail signage, digital menus, wholesale materials, and merch.</p><h2>The Result</h2><p>Solstice launched in 3 new cities within 6 months of rebrand. Brand recognition surveys showed 2.4x improvement in premium perception.</p>',
        tags: ['branding', 'packaging', 'strategy'],
        lead: PERSON_IDS.alex,
        testimonial_quote:
          "They didn't just make us look better — they helped us understand what we were becoming.",
        testimonial_author: 'Daniel Park, CEO, Solstice Coffee',
      },
      {
        title: 'Vectrix Platform',
        client: 'Vectrix',
        category: 'Web Design',
        year: 2026,
        description:
          '<h2>The Brief</h2><p>Vectrix, a Series B developer tools company, needed a marketing site that matched the quality of their product. Their existing site was a template — functional but generic. They needed something that communicated technical depth without intimidating non-technical buyers.</p><h2>The Work</h2><p>We designed and built a fully custom site with interactive product demos, a component-driven docs system, and a changelog that developers actually want to read. Every page was performance-optimized: 95+ Lighthouse scores across the board.</p><h2>The Result</h2><p>Demo requests increased 180% in the first quarter. The engineering team now ships docs alongside code — the system made it frictionless.</p>',
        tags: ['digital', 'development', 'strategy'],
        lead: PERSON_IDS.jordan,
        testimonial_quote:
          'Our site finally feels like it was built by a company that builds great software.',
        testimonial_author: 'Priya Sharma, VP Marketing, Vectrix',
      },
      {
        title: 'Noma Skincare',
        client: 'Noma',
        category: 'Packaging',
        year: 2025,
        description:
          '<h2>The Brief</h2><p>Noma launched as a DTC skincare brand with a clear thesis: minimal formulations, maximal transparency. They needed packaging that communicated clinical credibility while standing out on a shelf dominated by either "clean girl" aesthetics or medical sterility.</p><h2>The Work</h2><p>We developed a packaging system built on tactile contrast — soft-touch matte bottles with high-gloss ingredient callouts. The color system uses a single brand color (a deep teal) against pure white, with product differentiation handled by typography weight rather than color multiplication.</p><h2>The Result</h2><p>Noma\'s unboxing became their top-performing organic content. The packaging was featured in Monocle and It\'s Nice That within 3 months of launch.</p>',
        tags: ['packaging', 'branding', 'print'],
        lead: PERSON_IDS.mika,
        testimonial_quote:
          "People photograph our bottles. That's not an accident — it's the design.",
        testimonial_author: 'Lena Kowalski, Founder, Noma',
      },
      {
        title: 'City of Portland Wayfinding',
        client: 'City of Portland',
        category: 'Campaign',
        year: 2025,
        description:
          "<h2>The Brief</h2><p>Portland's downtown wayfinding system hadn't been updated since 2008. The city needed a cohesive system that worked for pedestrians, cyclists, and transit riders — in rain, at night, and at walking speed.</p><h2>The Work</h2><p>We designed a modular signage system with neighborhood-specific color coding, universal symbols that tested well across language barriers, and integrated digital kiosks with real-time transit data. The physical materials were selected for Pacific Northwest weather durability.</p><h2>The Result</h2><p>Pedestrian navigation surveys improved 40%. The system won a Core77 Design Award and is being adapted by two other cities.</p>",
        tags: ['strategy', 'print'],
        lead: PERSON_IDS.alex,
        testimonial_quote:
          'The new system makes Portland feel like a city that cares about the people walking through it.',
        testimonial_author: 'Commissioner Lisa Nguyen, City of Portland',
      },
      {
        title: 'Fieldwork Magazine Redesign',
        client: 'Fieldwork',
        category: 'Brand Identity',
        year: 2025,
        description:
          '<h2>The Brief</h2><p>Fieldwork, an independent architecture and urbanism quarterly, needed a visual overhaul for their 10th anniversary. The magazine had earned a loyal readership but looked dated — the design was competing with, not supporting, the writing.</p><h2>The Work</h2><p>We redesigned the magazine from masthead to margins. New type system (custom-commissioned serif for headlines, functional sans for body), a layout grid that gives photography room to breathe, and a cover strategy that treats each issue as a poster.</p><h2>The Result</h2><p>Subscriptions grew 25% in the year after redesign. The magazine won two SPD Merit Awards and was selected for the ADC Annual.</p>',
        tags: ['branding', 'print', 'photography'],
        lead: PERSON_IDS.mika,
        testimonial_quote:
          'They understood that a magazine redesign isn\'t about making it "modern" — it\'s about making the content sing.',
        testimonial_author: 'Tom Weaver, Editor, Fieldwork',
      },
    ],
  },

  pages: [
    {
      slug: '/',
      title: 'Home',
      page_type: 'home',
      show_in_nav: true,
      nav_label: 'Home',
      nav_order: 0,
      blocks: [
        {
          id: 'home-hero',
          _type: 'hero',
          heading: 'We design brands that outlast trends',
          subheading:
            'Strategy-led design studio specializing in brand identity, digital products, and packaging for companies that take craft seriously.',
          cta_text: 'See Our Work',
          cta_url: '/work',
          cta2_text: 'Start a Project',
          cta2_url: '/contact',
          alignment: 'left',
        },
        {
          id: 'home-projects',
          _type: 'entity_grid',
          heading: 'Selected Work',
          entity: 'project',
          sort: { field: 'year', dir: 'desc' },
          limit: 4,
          display_fields: ['title', 'client', 'category', 'cover_image'],
          layout: 'grid',
          columns: 2,
        },
        {
          id: 'home-clients',
          _type: 'testimonials',
          heading: 'What Clients Say',
          items: [
            {
              quote:
                "They didn't just make us look better — they helped us understand what we were becoming.",
              author: 'Daniel Park',
              role: 'CEO, Solstice Coffee',
            },
            {
              quote:
                'Our site finally feels like it was built by a company that builds great software.',
              author: 'Priya Sharma',
              role: 'VP Marketing, Vectrix',
            },
            {
              quote: "People photograph our bottles. That's not an accident — it's the design.",
              author: 'Lena Kowalski',
              role: 'Founder, Noma',
            },
          ],
        },
        {
          id: 'home-cta',
          _type: 'cta',
          heading: 'Have a project in mind?',
          text: 'We take on 4-6 projects per quarter to give each one the attention it deserves.',
          cta_text: 'Start a Conversation',
          cta_url: '/contact',
        },
      ],
    },
    {
      slug: '/work',
      title: 'Work',
      page_type: 'portfolio',
      show_in_nav: true,
      nav_label: 'Work',
      nav_order: 1,
      blocks: [
        {
          id: 'work-hero',
          _type: 'hero',
          heading: 'Our Work',
          subheading:
            'Brand identity, digital products, packaging, and campaigns for companies that take craft seriously.',
          alignment: 'left',
        },
        {
          id: 'work-grid',
          _type: 'entity_grid',
          entity: 'project',
          sort: { field: 'year', dir: 'desc' },
          limit: 20,
          display_fields: ['title', 'client', 'category', 'year', 'cover_image', 'tags'],
          layout: 'grid',
          columns: 2,
        },
      ],
    },
    {
      slug: '/about',
      title: 'About',
      page_type: 'about',
      show_in_nav: true,
      nav_label: 'About',
      nav_order: 2,
      blocks: [
        {
          id: 'about-hero',
          _type: 'hero',
          heading: 'A small studio doing work that matters',
          subheading: 'Founded in 2019. Three designers. Based in Portland, working everywhere.',
          alignment: 'left',
        },
        {
          id: 'about-story',
          _type: 'richtext',
          body: "<h2>How We Work</h2><p>We believe great design comes from understanding the problem deeply before touching a pixel. Every engagement starts with strategy — who are you, who are you for, and what does the world need to believe about you?</p><p>We keep the team small on purpose. Every project gets direct attention from senior designers, not junior executors working from a brief they didn't write. The tradeoff is capacity — we take on 4-6 projects per quarter, which means we sometimes say no.</p><h2>What We Value</h2><p><strong>Craft over trend.</strong> We design systems that last 10 years, not 10 months.</p><p><strong>Clarity over cleverness.</strong> If the audience doesn't get it immediately, it doesn't work.</p><p><strong>Partnership over service.</strong> We push back, we challenge, we collaborate. Clients hire us for opinions, not just execution.</p>",
        },
        {
          id: 'about-team',
          _type: 'entity_grid',
          heading: 'The Team',
          entity: 'person',
          display_fields: ['name', 'role', 'bio', 'photo', 'specialties'],
          layout: 'cards',
          columns: 3,
        },
        {
          id: 'about-features',
          _type: 'features',
          heading: 'Capabilities',
          items: [
            {
              title: 'Brand Identity',
              description:
                'Logos, type systems, color palettes, guidelines — the foundation that everything else builds on.',
            },
            {
              title: 'Digital Design',
              description:
                'Websites, apps, and digital products. Design + development under one roof.',
            },
            {
              title: 'Packaging',
              description: 'Physical product design that earns shelf space and social shares.',
            },
            {
              title: 'Strategy',
              description:
                'Positioning, naming, messaging, and brand architecture. Thinking before making.',
            },
            {
              title: 'Art Direction',
              description:
                'Photography, illustration, and motion direction that extends the brand into content.',
            },
            {
              title: 'Systems Design',
              description: 'Scalable design systems, component libraries, and brand documentation.',
            },
          ],
        },
      ],
    },
    {
      slug: '/contact',
      title: 'Contact',
      page_type: 'contact',
      show_in_nav: true,
      nav_label: 'Contact',
      nav_order: 3,
      blocks: [
        {
          id: 'contact-hero',
          _type: 'hero',
          heading: 'Start a project',
          subheading:
            "Tell us about what you're building. We respond to every inquiry within 2 business days.",
          alignment: 'left',
        },
        {
          id: 'contact-form',
          _type: 'form',
          heading: 'Project Inquiry',
          description:
            'The more detail you share upfront, the more useful our initial response will be.',
          entity_slug: 'project_inquiry',
          fields: [
            { name: 'name', type: 'text', label: 'Your Name', required: true },
            { name: 'email', type: 'email', label: 'Email', required: true },
            { name: 'company', type: 'text', label: 'Company / Organization' },
            {
              name: 'project_type',
              type: 'select',
              label: 'What do you need?',
              options: ['Brand Identity', 'Web Design', 'Packaging', 'Campaign', 'Other'],
            },
            {
              name: 'budget',
              type: 'select',
              label: 'Budget Range',
              options: ['Under $10k', '$10k-$25k', '$25k-$50k', '$50k-$100k', '$100k+'],
            },
            {
              name: 'timeline',
              type: 'text',
              label: 'Ideal Timeline',
              placeholder: 'e.g. Q3 2026',
            },
            {
              name: 'message',
              type: 'textarea',
              label: 'About Your Project',
              required: true,
              placeholder:
                "Tell us about your business, what you're trying to achieve, and any constraints we should know about.",
            },
          ],
          submit_label: 'Send Inquiry',
        },
        {
          id: 'contact-info',
          _type: 'richtext',
          body: '<h3>Other ways to reach us</h3><p><strong>Email:</strong> hello@example.com<br/><strong>Based in:</strong> Portland, OR<br/><strong>Working hours:</strong> Mon-Fri, 9am-6pm PT</p><p>For press inquiries, write to press@example.com.</p>',
        },
      ],
    },
  ],

  theme: {
    colors: {
      primary: '#111111',
      secondary: '#555555',
      accent: '#0066ff',
      background: '#ffffff',
      surface: '#f5f5f5',
      text: '#333333',
      heading: '#000000',
    },
    fonts: {
      heading: 'Inter, system-ui, sans-serif',
      body: 'Inter, system-ui, sans-serif',
    },
    radius: 'none',
    shadow: 'none',
    spacing: 'relaxed',
  },

  config: {
    title: 'Thornton Studio',
    description:
      'Strategy-led design studio specializing in brand identity, digital products, and packaging.',
  },

  nav: {
    logo_text: 'Thornton',
    style: 'minimal',
  },

  footer: {
    copyright: '2026 Thornton Studio',
    links: [
      { label: 'Instagram', url: 'https://instagram.com' },
      { label: 'LinkedIn', url: 'https://linkedin.com' },
      { label: 'Dribbble', url: 'https://dribbble.com' },
    ],
  },

  admin_views: [
    {
      entity_slug: 'project',
      label: 'Projects',
      icon: 'J',
      layout: 'cards',
      sort_order: 0,
      config: { image_field: 'cover_image', title_field: 'title', subtitle_field: 'client' },
    },
    {
      entity_slug: 'person',
      label: 'Team',
      icon: 'P',
      layout: 'cards',
      sort_order: 1,
      config: { image_field: 'photo', title_field: 'name', subtitle_field: 'role' },
    },
    {
      entity_slug: 'project_inquiry',
      label: 'Inquiries',
      icon: '✉',
      layout: 'table',
      sort_order: 2,
      config: { columns: ['name', 'email', 'project_type', 'budget'] },
    },
  ],
};
