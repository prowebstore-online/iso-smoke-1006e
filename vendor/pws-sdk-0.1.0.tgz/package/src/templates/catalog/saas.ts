import type { TemplateBundle } from '@pws/shared';

export const saasTemplate: TemplateBundle = {
  slug: 'saas',
  name: 'SaaS / Tech Product',
  description:
    'Software company marketing site with features, pricing, changelog, integrations, and demo request form. For SaaS, developer tools, and tech startups.',
  icon: 'T',
  verticals: ['SaaS', 'developer tools', 'mobile apps', 'tech startups', 'API products'],
  combines_with: ['blog', 'professional'],

  schemas: [
    {
      slug: 'feature',
      name: 'Feature',
      name_plural: 'Features',
      icon: 'F',
      fields: [
        { slug: 'title', name: 'Title', type: 'text', required: true },
        { slug: 'description', name: 'Description', type: 'richtext', required: true },
        { slug: 'icon', name: 'Icon', type: 'text' },
        { slug: 'image', name: 'Screenshot', type: 'image' },
        {
          slug: 'category',
          name: 'Category',
          type: 'select',
          options: ['Core', 'Collaboration', 'Automation', 'Analytics', 'Security', 'Integrations'],
        },
        { slug: 'sort_order', name: 'Sort Order', type: 'number', default: 0 },
      ],
    },
    {
      slug: 'changelog_entry',
      name: 'Changelog Entry',
      name_plural: 'Changelog',
      icon: 'C',
      fields: [
        { slug: 'title', name: 'Title', type: 'text', required: true },
        { slug: 'date', name: 'Date', type: 'date', required: true },
        { slug: 'description', name: 'Description', type: 'richtext', required: true },
        { slug: 'version', name: 'Version', type: 'text' },
        {
          slug: 'type',
          name: 'Type',
          type: 'select',
          options: ['Feature', 'Improvement', 'Fix', 'Breaking Change'],
          required: true,
        },
      ],
    },
    {
      slug: 'integration',
      name: 'Integration',
      name_plural: 'Integrations',
      icon: 'I',
      fields: [
        { slug: 'name', name: 'Name', type: 'text', required: true },
        { slug: 'description', name: 'Description', type: 'text', required: true },
        { slug: 'logo', name: 'Logo', type: 'image' },
        {
          slug: 'category',
          name: 'Category',
          type: 'select',
          options: [
            'CRM',
            'Communication',
            'Storage',
            'Analytics',
            'Development',
            'Marketing',
            'Finance',
          ],
        },
        { slug: 'url', name: 'Docs URL', type: 'url' },
      ],
    },
    {
      slug: 'demo_request',
      name: 'Demo Request',
      name_plural: 'Demo Requests',
      icon: 'D',
      public_writable: true,
      fields: [
        { slug: 'name', name: 'Name', type: 'text', required: true },
        { slug: 'email', name: 'Work Email', type: 'email', required: true },
        { slug: 'company', name: 'Company', type: 'text', required: true },
        {
          slug: 'company_size',
          name: 'Company Size',
          type: 'select',
          options: ['1-10', '11-50', '51-200', '201-1000', '1000+'],
        },
        {
          slug: 'role',
          name: 'Your Role',
          type: 'select',
          options: ['Engineering', 'Product', 'Design', 'Operations', 'Executive', 'Other'],
        },
        { slug: 'message', name: 'What are you looking to solve?', type: 'text' },
      ],
    },
  ],

  records: {
    feature: [
      {
        title: 'Real-Time Collaboration',
        description:
          '<p>Multiple team members can work in the same workspace simultaneously. See cursors, selections, and changes as they happen. Conflict resolution is automatic — no "someone else is editing" lockouts.</p>',
        icon: 'R',
        category: 'Collaboration',
        sort_order: 1,
      },
      {
        title: 'Workflow Automation',
        description:
          '<p>Build custom automation rules with a visual builder. When X happens, do Y. Connect triggers to actions across your entire workspace — no code required, but scriptable for power users.</p>',
        icon: 'A',
        category: 'Automation',
        sort_order: 2,
      },
      {
        title: 'Advanced Analytics',
        description:
          '<p>Understand how your team works. Track cycle time, throughput, bottlenecks, and trends. Pre-built dashboards for common workflows, or build custom views with our query language.</p>',
        icon: 'D',
        category: 'Analytics',
        sort_order: 3,
      },
      {
        title: 'Granular Permissions',
        description:
          '<p>Control who sees what at the workspace, project, and item level. Role-based defaults with per-item overrides. Audit log tracks every permission change. SSO and SCIM for enterprise.</p>',
        icon: 'S',
        category: 'Security',
        sort_order: 4,
      },
      {
        title: 'API & Webhooks',
        description:
          '<p>Full REST and GraphQL APIs for everything in the platform. Webhooks for real-time event streaming. Rate limits are generous (10k req/min on Pro) and documented honestly.</p>',
        icon: 'I',
        category: 'Integrations',
        sort_order: 5,
      },
      {
        title: 'Custom Fields & Views',
        description:
          '<p>Model your data the way your team thinks. Custom field types (text, number, date, select, relation, formula), custom views (board, table, timeline, calendar), and saved filters.</p>',
        icon: 'C',
        category: 'Core',
        sort_order: 6,
      },
    ],
    changelog_entry: [
      {
        title: 'Formula fields now support cross-project references',
        date: '2026-05-20',
        description:
          '<p>You can now reference fields from linked items in other projects inside formula fields. This enables computed roll-ups across projects (e.g., total budget across all active initiatives).</p>',
        version: '2.14.0',
        type: 'Feature',
      },
      {
        title: 'Board view: swimlane grouping',
        date: '2026-05-13',
        description:
          '<p>Board views can now be grouped into horizontal swimlanes by any select/relation field. Useful for seeing work grouped by team, priority, or sprint while still using a kanban layout.</p>',
        version: '2.13.0',
        type: 'Feature',
      },
      {
        title: 'Faster page loads for large workspaces',
        date: '2026-05-06',
        description:
          '<p>Workspaces with 10k+ items now load 3x faster. We rebuilt the query layer to use cursor-based pagination and lazy field hydration. Most pages are interactive within 400ms.</p>',
        version: '2.12.1',
        type: 'Improvement',
      },
      {
        title: 'Webhook payload includes field change diffs',
        date: '2026-04-29',
        description:
          '<p>Webhook payloads for item.updated events now include a <code>changes</code> array showing which fields changed, with before/after values. No more fetching the full item to see what happened.</p>',
        version: '2.12.0',
        type: 'Improvement',
      },
      {
        title: 'Fixed: automation triggers firing twice on bulk updates',
        date: '2026-04-22',
        description:
          '<p>Bulk status changes (e.g., marking 20 items as Done) were triggering individual automation runs for each item instead of a single batch. This caused duplicate notifications and incorrect counters. Fixed.</p>',
        version: '2.11.3',
        type: 'Fix',
      },
    ],
    integration: [
      {
        name: 'Slack',
        description: 'Get notifications, create items from messages, and update status from Slack.',
        category: 'Communication',
      },
      {
        name: 'GitHub',
        description:
          'Link PRs to items, auto-update status on merge, sync issues bi-directionally.',
        category: 'Development',
      },
      {
        name: 'Figma',
        description: 'Embed Figma files in items, get notified when designs are updated.',
        category: 'Development',
      },
      {
        name: 'Salesforce',
        description: 'Sync deals to projects, auto-create onboarding tasks when deals close.',
        category: 'CRM',
      },
      {
        name: 'Google Drive',
        description: 'Attach files from Drive, preview docs inline, sync folder structures.',
        category: 'Storage',
      },
      {
        name: 'Zapier',
        description: 'Connect to 5,000+ apps with pre-built templates or custom zaps.',
        category: 'Automation',
      },
      {
        name: 'Stripe',
        description: 'Track revenue alongside product work. Auto-tag items with MRR impact.',
        category: 'Finance',
      },
      {
        name: 'Datadog',
        description: 'Link incidents to items, auto-create post-mortem tasks from alerts.',
        category: 'Development',
      },
    ],
  },

  pages: [
    {
      slug: '/',
      title: 'Home',
      page_type: 'home',
      show_in_nav: true,
      nav_label: 'Home',
      nav_order: 0,
      blocks: [
        {
          id: 'home-hero',
          _type: 'hero',
          heading: 'Project management that stays out of your way',
          subheading:
            'Flexible enough for any workflow, fast enough for teams that ship daily. No 45-minute onboarding — just open it and start working.',
          cta_text: 'Start Free Trial',
          cta_url: '/contact',
          cta2_text: 'See Features',
          cta2_url: '/features',
          alignment: 'center',
        },
        {
          id: 'home-features',
          _type: 'features',
          heading: 'Built for teams that build',
          items: [
            {
              title: 'Fast by default',
              description: 'Sub-200ms interactions. No loading spinners between views.',
            },
            {
              title: 'Flexible data model',
              description: 'Custom fields, relations, formulas. Model your process, not ours.',
            },
            {
              title: 'Real-time collaboration',
              description: 'See changes as they happen. No refresh, no conflicts.',
            },
            {
              title: 'Powerful automation',
              description: 'Visual rule builder. When X happens, do Y. Zero code.',
            },
            {
              title: 'API-first',
              description: 'REST + GraphQL. 10k req/min. Build anything on top.',
            },
            {
              title: 'Enterprise-ready',
              description: 'SSO, SCIM, audit logs, granular permissions, SOC 2 Type II.',
            },
          ],
        },
        {
          id: 'home-testimonials',
          _type: 'testimonials',
          heading: 'Trusted by product teams',
          items: [
            {
              quote:
                "We moved from Jira and the team's velocity went up 30% in the first month. Not because the tool is magic — because people actually use it.",
              author: 'Sarah Lin',
              role: 'VP Engineering, Lightbend',
            },
            {
              quote:
                "Finally, a tool that doesn't force you into someone else's process. We run Shape Up and it actually works here.",
              author: 'Marcus Webb',
              role: 'Head of Product, Cartography',
            },
            {
              quote:
                'The API is what sold us. We built our entire sprint planning automation on top of it in a weekend.',
              author: 'Priya Kapoor',
              role: 'Staff Engineer, NovaTech',
            },
          ],
        },
        {
          id: 'home-logos',
          _type: 'features',
          heading: 'Used by teams at',
          subheading: 'From 5-person startups to Fortune 500 engineering orgs.',
          items: [
            { title: 'Lightbend', description: '' },
            { title: 'Cartography', description: '' },
            { title: 'NovaTech', description: '' },
            { title: 'Meridian', description: '' },
          ],
        },
        {
          id: 'home-cta',
          _type: 'cta',
          heading: 'Ready to try it?',
          text: '14-day free trial. No credit card required. Full feature access.',
          cta_text: 'Start Free Trial',
          cta_url: '/contact',
        },
      ],
    },
    {
      slug: '/features',
      title: 'Features',
      page_type: 'features',
      show_in_nav: true,
      nav_label: 'Features',
      nav_order: 1,
      blocks: [
        {
          id: 'features-hero',
          _type: 'hero',
          heading: 'Features',
          subheading: "Everything you need to plan, track, and ship. Nothing you don't.",
          alignment: 'left',
        },
        {
          id: 'features-grid',
          _type: 'entity_grid',
          entity: 'feature',
          sort: { field: 'sort_order', dir: 'asc' },
          display_fields: ['title', 'description', 'icon', 'category', 'image'],
          layout: 'cards',
          columns: 1,
        },
      ],
    },
    {
      slug: '/pricing',
      title: 'Pricing',
      page_type: 'pricing',
      show_in_nav: true,
      nav_label: 'Pricing',
      nav_order: 2,
      blocks: [
        {
          id: 'pricing-hero',
          _type: 'hero',
          heading: 'Simple, transparent pricing',
          subheading: 'No per-seat surprises. No feature gates that make the free plan useless.',
          alignment: 'center',
        },
        {
          id: 'pricing-table',
          _type: 'pricing_table',
          plans: [
            {
              name: 'Free',
              price: '$0',
              period: 'forever',
              features: [
                'Up to 5 users',
                'Unlimited items',
                'Core views (board, table, list)',
                'Basic automations (5 rules)',
                'API access (1k req/min)',
                'Community support',
              ],
              cta_text: 'Get Started',
              cta_url: '/contact',
            },
            {
              name: 'Pro',
              price: '$12',
              period: '/user/month',
              features: [
                'Unlimited users',
                'All views (+ timeline, calendar)',
                'Unlimited automations',
                'Custom fields & formulas',
                'Advanced analytics',
                'API (10k req/min)',
                'Priority support',
              ],
              cta_text: 'Start Free Trial',
              cta_url: '/contact',
              highlighted: true,
            },
            {
              name: 'Enterprise',
              price: 'Custom',
              features: [
                'Everything in Pro',
                'SSO (SAML/OIDC)',
                'SCIM provisioning',
                'Audit logs (1 year retention)',
                'Custom SLA',
                'Dedicated success manager',
                'On-prem deployment option',
              ],
              cta_text: 'Talk to Sales',
              cta_url: '/contact',
            },
          ],
        },
        {
          id: 'pricing-faq',
          _type: 'faq',
          heading: 'Pricing FAQ',
          items: [
            {
              question: 'What counts as a user?',
              answer:
                "Anyone who can log in and make changes. Read-only guests and API tokens don't count.",
            },
            {
              question: 'Can I switch plans?',
              answer: 'Yes, upgrade or downgrade anytime. Changes are prorated to the day.',
            },
            {
              question: 'Is there a discount for annual billing?',
              answer: 'Yes — 20% off. Pro annual is $10/user/month billed yearly.',
            },
            {
              question: 'What happens when the trial ends?',
              answer:
                'Your workspace switches to Free. No data is deleted. Upgrade anytime to restore Pro features.',
            },
          ],
        },
      ],
    },
    {
      slug: '/integrations',
      title: 'Integrations',
      page_type: 'integrations',
      show_in_nav: true,
      nav_label: 'Integrations',
      nav_order: 3,
      blocks: [
        {
          id: 'integrations-hero',
          _type: 'hero',
          heading: 'Integrations',
          subheading:
            'Connect your stack. Native integrations for the tools your team already uses.',
          alignment: 'left',
        },
        {
          id: 'integrations-grid',
          _type: 'entity_grid',
          entity: 'integration',
          display_fields: ['name', 'description', 'logo', 'category'],
          layout: 'grid',
          columns: 3,
        },
        {
          id: 'integrations-api',
          _type: 'cta',
          heading: 'Build your own',
          text: "Full REST and GraphQL APIs, webhooks, and an SDK. If there's no native integration, build one in an afternoon.",
          cta_text: 'View API Docs',
          cta_url: '/contact',
        },
      ],
    },
    {
      slug: '/changelog',
      title: 'Changelog',
      page_type: 'changelog',
      show_in_nav: true,
      nav_label: 'Changelog',
      nav_order: 4,
      blocks: [
        {
          id: 'changelog-hero',
          _type: 'hero',
          heading: 'Changelog',
          subheading: 'What we shipped, when we shipped it. Updated every Tuesday.',
          alignment: 'left',
        },
        {
          id: 'changelog-list',
          _type: 'entity_grid',
          entity: 'changelog_entry',
          sort: { field: 'date', dir: 'desc' },
          display_fields: ['title', 'date', 'description', 'version', 'type'],
          layout: 'cards',
          columns: 1,
        },
      ],
    },
    {
      slug: '/contact',
      title: 'Contact',
      page_type: 'contact',
      show_in_nav: true,
      nav_label: 'Get Started',
      nav_order: 5,
      blocks: [
        {
          id: 'contact-hero',
          _type: 'hero',
          heading: 'Get Started',
          subheading: 'Start a free trial, or talk to us about Enterprise.',
          alignment: 'left',
        },
        {
          id: 'contact-form',
          _type: 'form',
          heading: 'Request a Demo',
          description:
            "We'll set up a workspace tailored to your workflow and walk you through it live.",
          entity_slug: 'demo_request',
          fields: [
            { name: 'name', type: 'text', label: 'Name', required: true },
            { name: 'email', type: 'email', label: 'Work Email', required: true },
            { name: 'company', type: 'text', label: 'Company', required: true },
            {
              name: 'company_size',
              type: 'select',
              label: 'Team Size',
              options: ['1-10', '11-50', '51-200', '201-1000', '1000+'],
            },
            {
              name: 'role',
              type: 'select',
              label: 'Your Role',
              options: ['Engineering', 'Product', 'Design', 'Operations', 'Executive', 'Other'],
            },
            {
              name: 'message',
              type: 'textarea',
              label: 'What are you looking to solve?',
              placeholder: "Tell us about your current workflow and what's not working.",
            },
          ],
          submit_label: 'Request Demo',
        },
      ],
    },
  ],

  theme: {
    colors: {
      primary: '#6366f1',
      secondary: '#818cf8',
      accent: '#06b6d4',
      background: '#0f172a',
      surface: '#1e293b',
      text: '#e2e8f0',
      heading: '#f8fafc',
    },
    fonts: {
      heading: 'Inter, system-ui, sans-serif',
      body: 'Inter, system-ui, sans-serif',
    },
    radius: 'md',
    shadow: 'md',
    spacing: 'normal',
  },

  config: {
    title: 'Planform',
    description:
      'Project management that stays out of your way. Flexible, fast, and built for teams that ship.',
  },

  nav: {
    logo_text: 'Planform',
    style: 'standard',
  },

  footer: {
    copyright: '2026 Planform, Inc.',
    links: [{ label: 'Status', url: 'https://status.example.com' }],
  },

  admin_views: [
    {
      entity_slug: 'feature',
      label: 'Features',
      icon: 'F',
      layout: 'table',
      sort_order: 0,
      config: { columns: ['title', 'category', 'sort_order'] },
    },
    {
      entity_slug: 'changelog_entry',
      label: 'Changelog',
      icon: 'C',
      layout: 'table',
      sort_order: 1,
      config: { columns: ['title', 'date', 'version', 'type'] },
    },
    {
      entity_slug: 'integration',
      label: 'Integrations',
      icon: 'I',
      layout: 'cards',
      sort_order: 2,
      config: { image_field: 'logo', title_field: 'name', subtitle_field: 'category' },
    },
    {
      entity_slug: 'demo_request',
      label: 'Demo Requests',
      icon: '✉',
      layout: 'table',
      sort_order: 3,
      config: { columns: ['name', 'email', 'company', 'company_size'] },
    },
  ],
};
