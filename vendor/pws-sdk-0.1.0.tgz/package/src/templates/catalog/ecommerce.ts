import type { TemplateBundle } from '@pws/shared';

const CATEGORY_IDS = {
  bags: 'f0000000-0000-0000-0000-000000000001',
  wallets: 'f0000000-0000-0000-0000-000000000002',
  accessories: 'f0000000-0000-0000-0000-000000000003',
  care: 'f0000000-0000-0000-0000-000000000004',
};

export const ecommerceTemplate: TemplateBundle = {
  slug: 'ecommerce',
  name: 'E-commerce Storefront',
  description:
    'Product catalog with categories, inquiry-based sales, and customer testimonials. For boutiques, artisan goods, wholesale, and B2B catalogs.',
  icon: 'E',
  verticals: ['retail', 'boutique', 'wholesale', 'B2B catalog', 'artisan', 'furniture'],
  combines_with: ['blog', 'professional', 'membership'],

  schemas: [
    {
      slug: 'category',
      name: 'Category',
      name_plural: 'Categories',
      icon: 'C',
      fields: [
        { slug: 'name', name: 'Name', type: 'text', required: true },
        { slug: 'description', name: 'Description', type: 'text' },
        { slug: 'image', name: 'Image', type: 'image' },
        { slug: 'sort_order', name: 'Sort Order', type: 'number', default: 0 },
      ],
    },
    {
      slug: 'product',
      name: 'Product',
      name_plural: 'Products',
      icon: 'P',
      fields: [
        { slug: 'name', name: 'Name', type: 'text', required: true },
        { slug: 'description', name: 'Description', type: 'richtext', required: true },
        { slug: 'price', name: 'Price', type: 'number', required: true },
        { slug: 'sale_price', name: 'Sale Price', type: 'number' },
        { slug: 'image', name: 'Image', type: 'image' },
        { slug: 'sku', name: 'SKU', type: 'text' },
        { slug: 'category', name: 'Category', type: 'reference', reference_to: 'category' },
        { slug: 'in_stock', name: 'In Stock', type: 'boolean', default: true },
        {
          slug: 'stock',
          name: 'Stock on hand',
          type: 'number',
          default: 0,
          description:
            'Units available. Checkout decrements this and marks the item sold out at 0.',
        },
        { slug: 'featured', name: 'Featured', type: 'boolean', default: false },
        {
          slug: 'tags',
          name: 'Tags',
          type: 'multiselect',
          options: ['New Arrival', 'Best Seller', 'Limited Edition', 'Gift Idea', 'Sale'],
        },
        {
          slug: 'material',
          name: 'Material',
          type: 'select',
          options: [
            'Full-Grain Leather',
            'Top-Grain Leather',
            'Vegetable-Tanned',
            'Canvas',
            'Waxed Cotton',
          ],
        },
        {
          slug: 'color',
          name: 'Color',
          type: 'select',
          options: ['Black', 'Brown', 'Tan', 'Navy', 'Olive', 'Natural'],
        },
      ],
    },
    {
      slug: 'person',
      name: 'Team Member',
      name_plural: 'Team',
      icon: 'T',
      fields: [
        { slug: 'name', name: 'Name', type: 'text', required: true },
        { slug: 'role', name: 'Role', type: 'text', required: true },
        { slug: 'photo', name: 'Photo', type: 'image' },
        { slug: 'bio', name: 'Bio', type: 'richtext' },
      ],
    },
    {
      slug: 'order_inquiry',
      name: 'Order Inquiry',
      name_plural: 'Order Inquiries',
      icon: 'O',
      public_writable: true,
      fields: [
        { slug: 'name', name: 'Name', type: 'text', required: true },
        { slug: 'email', name: 'Email', type: 'email', required: true },
        {
          slug: 'inquiry_type',
          name: 'Inquiry Type',
          type: 'select',
          options: ['Product Question', 'Custom Order', 'Wholesale', 'Return/Exchange', 'Other'],
        },
        { slug: 'product_name', name: 'Product (if applicable)', type: 'text' },
        { slug: 'message', name: 'Message', type: 'text', required: true },
      ],
    },
    {
      slug: 'order',
      name: 'Order',
      name_plural: 'Orders',
      icon: '$',
      fields: [
        { slug: 'customer_name', name: 'Customer Name', type: 'text' },
        { slug: 'customer_email', name: 'Customer Email', type: 'text' },
        { slug: 'shipping_address', name: 'Shipping Address', type: 'text' },
        { slug: 'items', name: 'Items (JSON)', type: 'text' },
        { slug: 'item_count', name: 'Item Count', type: 'number' },
        { slug: 'subtotal', name: 'Subtotal', type: 'number' },
        { slug: 'total', name: 'Total', type: 'number', required: true },
        {
          slug: 'status',
          name: 'Status',
          type: 'select',
          options: ['Pending', 'Paid', 'Paid (test)', 'Fulfilled', 'Cancelled', 'Refunded'],
        },
        { slug: 'payment_ref', name: 'Payment Reference', type: 'text' },
      ],
    },
  ],

  records: {
    category: [
      { name: 'Bags', description: 'Totes, weekenders, backpacks, and messengers.', sort_order: 1 },
      {
        name: 'Wallets & Small Goods',
        description: 'Wallets, card holders, and key fobs.',
        sort_order: 2,
      },
      {
        name: 'Accessories',
        description: 'Belts, watch straps, and journal covers.',
        sort_order: 3,
      },
      {
        name: 'Care Products',
        description: 'Leather conditioner, polish, and cleaning kits.',
        sort_order: 4,
      },
    ],
    product: [
      {
        name: 'The Commuter Tote',
        description:
          '<p>Our flagship everyday bag. Structured enough for a laptop, soft enough to toss in the passenger seat. Made from vegetable-tanned leather that develops a rich patina over years of use.</p><ul><li>Fits 15" laptop in padded interior sleeve</li><li>Two interior pockets, one zippered</li><li>Reinforced handles with copper rivets</li><li>Dimensions: 16" x 12" x 5"</li></ul>',
        price: 28500,
        image: null,
        sku: 'BAG-COMMUTER-001',
        category: CATEGORY_IDS.bags,
        in_stock: true,
        stock: 25,
        featured: true,
        tags: ['Best Seller'],
        material: 'Vegetable-Tanned',
        color: 'Tan',
      },
      {
        name: 'The Weekender',
        description:
          '<p>A holdall that gets better with every trip. Full-grain leather body with a waxed cotton base that shrugs off wet airport floors. Sized to fit in overhead compartments.</p><ul><li>Full-grain leather with waxed cotton base</li><li>Interior shoe compartment</li><li>Detachable shoulder strap</li><li>Dimensions: 21" x 11" x 10"</li></ul>',
        price: 42500,
        sku: 'BAG-WEEKEND-001',
        category: CATEGORY_IDS.bags,
        in_stock: true,
        stock: 25,
        featured: true,
        tags: ['Best Seller', 'Gift Idea'],
        material: 'Full-Grain Leather',
        color: 'Brown',
      },
      {
        name: 'The Slim Bifold',
        description:
          '<p>Minimalist wallet for people who hate bulky wallets. Six card slots, two bill compartments, and a slim profile that actually fits in your front pocket. The leather starts firm and softens beautifully over the first month.</p>',
        price: 8500,
        sku: 'WAL-SLIM-001',
        category: CATEGORY_IDS.wallets,
        in_stock: true,
        stock: 3,
        featured: false,
        tags: ['Best Seller'],
        material: 'Full-Grain Leather',
        color: 'Black',
      },
      {
        name: 'The Card Holder',
        description:
          '<p>Four card slots on the outside, a center pocket for cash or additional cards. The simplest thing we make, and one of the most popular. Makes a perfect gift.</p>',
        price: 4500,
        sku: 'WAL-CARD-001',
        category: CATEGORY_IDS.wallets,
        in_stock: true,
        stock: 25,
        featured: false,
        tags: ['Gift Idea', 'New Arrival'],
        material: 'Full-Grain Leather',
        color: 'Natural',
      },
      {
        name: 'The Everyday Belt',
        description:
          '<p>A belt that does its job without calling attention to itself. 1.25" width works with both dress and casual. Solid brass buckle with a matte finish. Cut to size at home with the included instructions.</p>',
        price: 9500,
        sku: 'ACC-BELT-001',
        category: CATEGORY_IDS.accessories,
        in_stock: true,
        stock: 25,
        featured: false,
        tags: [],
        material: 'Full-Grain Leather',
        color: 'Brown',
      },
      {
        name: 'Leather Journal Cover',
        description:
          "<p>Fits A5 notebooks (Moleskine, Leuchtturm, or similar). Interior pen loop, business card slot, and a bookmark ribbon. The cover outlasts dozens of notebooks — it's the last one you'll buy.</p>",
        price: 6500,
        sku: 'ACC-JOURNAL-001',
        category: CATEGORY_IDS.accessories,
        in_stock: true,
        stock: 25,
        featured: true,
        tags: ['Gift Idea'],
        material: 'Vegetable-Tanned',
        color: 'Tan',
      },
      {
        name: 'Leather Care Kit',
        description:
          '<p>Everything you need to keep your leather goods looking their best. Includes our house-blend conditioner (beeswax + neatsfoot oil), a horsehair brush, and a polishing cloth. One kit lasts about 2 years of regular use.</p>',
        price: 3500,
        sku: 'CARE-KIT-001',
        category: CATEGORY_IDS.care,
        in_stock: true,
        stock: 25,
        featured: false,
        tags: [],
        material: 'Full-Grain Leather',
      },
    ],
    person: [
      {
        name: 'Tom Hargrove',
        role: 'Founder & Leatherworker',
        bio: '<p>Tom started making bags in his garage in 2017 after 10 years in product design at a major outdoor brand. He was tired of designing things meant to be replaced. Hargrove Goods exists because he wanted to make things that last.</p>',
      },
      {
        name: 'Nina Vasquez',
        role: 'Studio Manager',
        bio: '<p>Nina runs the workshop — cutting, stitching, finishing, quality control, and shipping. She trained as a saddler in Argentina before moving to Portland. Her standards are higher than ours.</p>',
      },
    ],
  },

  pages: [
    {
      slug: '/',
      title: 'Home',
      page_type: 'home',
      show_in_nav: true,
      nav_label: 'Home',
      nav_order: 0,
      blocks: [
        {
          id: 'home-hero',
          _type: 'hero',
          heading: 'Leather goods built to outlast you',
          subheading:
            'Handmade in Portland from full-grain leather. No logos, no shortcuts, no planned obsolescence. Just things that get better with age.',
          cta_text: 'Shop All',
          cta_url: '/shop',
          cta2_text: 'Our Story',
          cta2_url: '/about',
          alignment: 'center',
        },
        {
          id: 'home-featured',
          _type: 'product_grid',
          heading: 'Featured',
          entity: 'product',
          filter: { featured: true },
          columns: 3,
          cart_url: '/cart',
        },
        {
          id: 'home-categories',
          _type: 'entity_grid',
          heading: 'Shop by Category',
          entity: 'category',
          display_fields: ['name', 'description', 'image'],
          layout: 'grid',
          columns: 4,
        },
        {
          id: 'home-testimonials',
          _type: 'testimonials',
          heading: 'What Customers Say',
          items: [
            {
              quote:
                "I've had the Commuter Tote for 3 years. It looks better now than the day I bought it.",
              author: 'Alex K.',
              rating: 5,
            },
            {
              quote:
                'Bought the Weekender for a trip to Japan. Got more compliments on my bag than anything else I was wearing.',
              author: 'Priya S.',
              rating: 5,
            },
            {
              quote:
                "The quality is immediately obvious when you pick it up. Heavy, substantial, built right. I'm done buying cheap wallets.",
              author: 'Marcus T.',
              rating: 5,
            },
          ],
        },
        {
          id: 'home-usp',
          _type: 'features',
          heading: 'Why Hargrove',
          items: [
            {
              title: 'Full-Grain Leather',
              description:
                'The top layer of the hide, unaltered. Strongest, most durable, develops the best patina.',
            },
            {
              title: 'Handmade in Portland',
              description:
                'Every piece is cut, stitched, and finished by hand in our Portland workshop.',
            },
            {
              title: 'Lifetime Guarantee',
              description:
                "If it breaks from normal use, we'll repair or replace it. No questions, no time limit.",
            },
          ],
        },
      ],
    },
    {
      slug: '/shop',
      title: 'Shop',
      page_type: 'shop',
      show_in_nav: true,
      nav_label: 'Shop',
      nav_order: 1,
      blocks: [
        {
          id: 'shop-hero',
          _type: 'hero',
          heading: 'All Products',
          subheading: 'Every piece is handmade to order. Current lead time: 5-7 business days.',
          alignment: 'left',
        },
        {
          id: 'shop-grid',
          _type: 'product_grid',
          entity: 'product',
          columns: 3,
          cart_url: '/cart',
        },
      ],
    },
    {
      slug: '/cart',
      title: 'Cart',
      page_type: 'cart',
      show_in_nav: true,
      nav_label: 'Cart',
      nav_order: 5,
      blocks: [
        {
          id: 'cart-block',
          _type: 'cart',
          heading: 'Your Cart',
          empty_message: 'Your cart is empty. Browse our collection and add items to get started.',
          checkout_text: 'Proceed to Checkout',
          continue_shopping_url: '/shop',
          checkout_url: '/checkout',
        },
      ],
    },
    {
      slug: '/checkout',
      title: 'Checkout',
      page_type: 'checkout',
      show_in_nav: false,
      nav_label: 'Checkout',
      nav_order: 8,
      blocks: [
        {
          id: 'checkout-block',
          _type: 'checkout',
          heading: 'Checkout',
          continue_shopping_url: '/shop',
        },
      ],
    },
    {
      slug: '/about',
      title: 'About',
      page_type: 'about',
      show_in_nav: true,
      nav_label: 'About',
      nav_order: 2,
      blocks: [
        {
          id: 'about-hero',
          _type: 'hero',
          heading: 'Our Story',
          alignment: 'left',
        },
        {
          id: 'about-story',
          _type: 'richtext',
          body: "<h2>Why We Make Things</h2><p>In 2017, Tom Hargrove left a comfortable product design job to make bags in his garage. He'd spent a decade designing consumer goods engineered to last 2-3 years — just long enough to survive the warranty, short enough to drive repeat purchases. He hated it.</p><p>Hargrove Goods is the opposite. We use the best materials we can source, the most durable construction methods we know, and we back everything with a lifetime guarantee. Not because it's good marketing — because it's the only way we want to work.</p><h2>The Workshop</h2><p>Everything is made by hand in our Portland workshop. We don't batch-produce overseas. Tom and Nina cut, stitch, and finish every piece themselves. This means we're slow (5-7 day lead time) but precise. Your bag is made after you order it, not pulled from a warehouse.</p><h2>The Materials</h2><p>We use exclusively full-grain leather from tanneries we've visited personally. Full-grain is the outermost layer of the hide — it's the strongest, most durable, and the only leather that develops a real patina over time. Most \"leather\" products use corrected-grain or bonded leather. We don't.</p>",
        },
        {
          id: 'about-team',
          _type: 'entity_grid',
          heading: 'The People',
          entity: 'person',
          display_fields: ['name', 'role', 'bio', 'photo'],
          layout: 'cards',
          columns: 2,
        },
      ],
    },
    {
      slug: '/faq',
      title: 'FAQ',
      page_type: 'faq',
      show_in_nav: true,
      nav_label: 'FAQ',
      nav_order: 3,
      blocks: [
        {
          id: 'faq-hero',
          _type: 'hero',
          heading: 'Frequently Asked Questions',
          alignment: 'left',
        },
        {
          id: 'faq-list',
          _type: 'faq',
          heading: 'Ordering & Shipping',
          items: [
            {
              question: 'How long does shipping take?',
              answer:
                'Every piece is made to order. Production takes 5-7 business days, then shipping is 3-5 days within the US. International orders take 7-14 days.',
            },
            {
              question: 'Do you ship internationally?',
              answer:
                'Yes, we ship worldwide. International customers are responsible for any customs duties or taxes.',
            },
            {
              question: 'Can I return or exchange a product?',
              answer:
                "If you're not satisfied, email us within 30 days for a full refund or exchange. The item must be in unused condition. Personalized items are final sale.",
            },
            {
              question: 'What does the lifetime guarantee cover?',
              answer:
                "If your item fails from normal use — stitching comes undone, hardware breaks, leather tears at a stress point — we'll repair it for free or replace it. This doesn't cover damage from misuse, accidents, or normal patina development (that's a feature, not a defect).",
            },
          ],
        },
        {
          id: 'faq-care',
          _type: 'faq',
          heading: 'Care & Maintenance',
          items: [
            {
              question: 'How do I care for my leather goods?',
              answer:
                'Condition with our leather balm (or any quality leather conditioner) every 3-6 months. Avoid prolonged exposure to water. If it gets wet, let it dry naturally — never use heat. Store in the included dust bag.',
            },
            {
              question: 'Will the leather change color?',
              answer:
                "Yes, and that's the point. Full-grain leather develops a patina — it darkens, softens, and takes on the character of how you use it. This is a sign of quality, not a defect.",
            },
          ],
        },
        {
          id: 'faq-wholesale',
          _type: 'faq',
          heading: 'Wholesale & Custom',
          items: [
            {
              question: 'Do you offer wholesale?',
              answer:
                'Yes, we work with a small number of retail partners. Minimum order is 12 units. Email us at wholesale@example.com for a line sheet.',
            },
            {
              question: 'Can you make custom products?',
              answer:
                "We do limited custom work — monogramming, custom colors, and bespoke pieces for special occasions. Use the contact form and describe what you're looking for.",
            },
          ],
        },
      ],
    },
    {
      slug: '/contact',
      title: 'Contact',
      page_type: 'contact',
      show_in_nav: true,
      nav_label: 'Contact',
      nav_order: 4,
      blocks: [
        {
          id: 'contact-hero',
          _type: 'hero',
          heading: 'Get in Touch',
          subheading:
            'Questions about a product, custom orders, wholesale — we respond within 24 hours.',
          alignment: 'left',
        },
        {
          id: 'contact-form',
          _type: 'form',
          heading: 'Send us a message',
          entity_slug: 'order_inquiry',
          fields: [
            { name: 'name', type: 'text', label: 'Your Name', required: true },
            { name: 'email', type: 'email', label: 'Email', required: true },
            {
              name: 'inquiry_type',
              type: 'select',
              label: 'What is this about?',
              options: [
                'Product Question',
                'Custom Order',
                'Wholesale',
                'Return/Exchange',
                'Other',
              ],
            },
            {
              name: 'product_name',
              type: 'text',
              label: 'Product (if applicable)',
              placeholder: 'e.g. The Commuter Tote',
            },
            {
              name: 'message',
              type: 'textarea',
              label: 'Message',
              required: true,
              placeholder: 'How can we help?',
            },
          ],
          submit_label: 'Send Message',
        },
      ],
    },
  ],

  theme: {
    colors: {
      primary: '#5c4033',
      secondary: '#8b7355',
      accent: '#c17817',
      background: '#fdfbf7',
      surface: '#f5f0e8',
      text: '#3d3029',
      heading: '#1a1410',
    },
    fonts: {
      heading: 'Inter, system-ui, sans-serif',
      body: 'Inter, system-ui, sans-serif',
    },
    radius: 'sm',
    shadow: 'sm',
    spacing: 'relaxed',
  },

  config: {
    title: 'Hargrove Goods',
    description:
      'Handmade leather goods built to outlast you. Bags, wallets, and accessories from full-grain leather, made in Portland.',
  },

  nav: {
    logo_text: 'Hargrove',
    style: 'minimal',
  },

  footer: {
    copyright: '2026 Hargrove Goods',
    links: [
      { label: 'Instagram', url: 'https://instagram.com' },
      { label: 'Shipping & Returns', url: '/faq' },
      { label: 'Wholesale', url: '/contact' },
    ],
  },

  admin_views: [
    {
      entity_slug: 'product',
      label: 'Products',
      icon: 'P',
      layout: 'cards',
      sort_order: 0,
      config: { image_field: 'image', title_field: 'name', subtitle_field: 'material' },
    },
    {
      entity_slug: 'category',
      label: 'Categories',
      icon: 'C',
      layout: 'cards',
      sort_order: 1,
      config: { image_field: 'image', title_field: 'name', subtitle_field: 'description' },
    },
    {
      entity_slug: 'order',
      label: 'Orders',
      icon: '$',
      layout: 'table',
      sort_order: 2,
      config: { columns: ['customer_name', 'customer_email', 'item_count', 'total', 'status'] },
    },
    {
      entity_slug: 'order_inquiry',
      label: 'Inquiries',
      icon: '✉',
      layout: 'table',
      sort_order: 3,
      config: { columns: ['name', 'email', 'inquiry_type', 'message'] },
    },
    {
      entity_slug: 'person',
      label: 'Team',
      icon: '👤',
      layout: 'cards',
      sort_order: 4,
      config: { image_field: 'photo', title_field: 'name', subtitle_field: 'role' },
    },
  ],
};
