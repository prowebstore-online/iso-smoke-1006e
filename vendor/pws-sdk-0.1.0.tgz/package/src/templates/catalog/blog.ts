import type { TemplateBundle } from '@pws/shared';

const AUTHOR_IDS = {
  sarah: 'a0000000-0000-0000-0000-000000000001',
  marcus: 'a0000000-0000-0000-0000-000000000002',
};

export const blogTemplate: TemplateBundle = {
  slug: 'blog',
  name: 'Blog / Magazine',
  description:
    'Content publishing platform with posts, authors, categories, and newsletter signup. The canonical CMS use case.',
  icon: 'B',
  verticals: ['blog', 'magazine', 'news', 'content marketing'],
  combines_with: ['portfolio', 'professional', 'ecommerce', 'nonprofit'],

  schemas: [
    {
      slug: 'person',
      name: 'Author',
      name_plural: 'Authors',
      icon: 'P',
      fields: [
        { slug: 'name', name: 'Name', type: 'text', required: true },
        { slug: 'role', name: 'Role', type: 'text' },
        { slug: 'bio', name: 'Bio', type: 'richtext' },
        { slug: 'photo', name: 'Photo', type: 'image' },
        { slug: 'email', name: 'Email', type: 'email' },
        { slug: 'twitter', name: 'Twitter', type: 'url' },
        { slug: 'linkedin', name: 'LinkedIn', type: 'url' },
      ],
    },
    {
      slug: 'post',
      name: 'Post',
      name_plural: 'Posts',
      icon: 'A',
      fields: [
        { slug: 'title', name: 'Title', type: 'text', required: true },
        { slug: 'excerpt', name: 'Excerpt', type: 'text' },
        { slug: 'body', name: 'Body', type: 'richtext', required: true },
        { slug: 'featured_image', name: 'Featured Image', type: 'image' },
        { slug: 'author', name: 'Author', type: 'reference', reference_to: 'person' },
        {
          slug: 'category',
          name: 'Category',
          type: 'select',
          options: ['Industry News', 'Guides', 'Opinion', 'Case Studies', 'Announcements'],
        },
        {
          slug: 'tags',
          name: 'Tags',
          type: 'multiselect',
          options: [
            'strategy',
            'growth',
            'marketing',
            'technology',
            'leadership',
            'culture',
            'product',
            'design',
          ],
        },
        { slug: 'published_at', name: 'Published', type: 'date', required: true },
        {
          slug: 'status',
          name: 'Status',
          type: 'select',
          options: ['draft', 'published'],
          default: 'published',
        },
      ],
    },
    {
      slug: 'contact_inquiry',
      name: 'Contact Inquiry',
      name_plural: 'Contact Inquiries',
      icon: 'M',
      public_writable: true,
      fields: [
        { slug: 'name', name: 'Name', type: 'text', required: true },
        { slug: 'email', name: 'Email', type: 'email', required: true },
        { slug: 'subject', name: 'Subject', type: 'text' },
        { slug: 'message', name: 'Message', type: 'text', required: true },
      ],
    },
  ],

  records: {
    person: [
      {
        name: 'Sarah Chen',
        role: 'Editor-in-Chief',
        bio: '<p>Sarah has spent 15 years in tech journalism, covering the intersection of business strategy and emerging technology. Previously at Wired and The Information.</p>',
        email: 'sarah@example.com',
      },
      {
        name: 'Marcus Rivera',
        role: 'Senior Writer',
        bio: '<p>Marcus covers growth strategy, marketing, and the creator economy. His work has appeared in Harvard Business Review and Fast Company.</p>',
        email: 'marcus@example.com',
      },
    ],
    post: [
      {
        title: 'Why Most Content Strategies Fail (And What to Do Instead)',
        excerpt:
          'The gap between content that performs and content that fills space comes down to three decisions made before a single word is written.',
        body: '<h2>The Problem With "More Content"</h2><p>Every quarter, teams produce more blog posts, more videos, more newsletters. Yet engagement flatlines. The issue isn\'t volume — it\'s the absence of strategic constraints.</p><h2>Three Decisions That Matter</h2><p><strong>1. Who are you writing for?</strong> Not "our target audience" — pick one specific person with one specific problem. Write for them.</p><p><strong>2. What will they do after reading?</strong> If you can\'t answer this in one sentence, the piece has no purpose.</p><p><strong>3. Why now?</strong> Tie your content to a moment — a trend, a season, a trigger event. Timeless content is a myth; timely content compounds.</p><h2>The Constraint Framework</h2><p>Before writing anything, fill in: "This post helps [specific person] solve [specific problem] so they can [specific outcome] because [specific timing reason]." If any blank stays vague, you\'re not ready to write.</p>',
        author: AUTHOR_IDS.sarah,
        category: 'Guides',
        tags: ['strategy', 'marketing'],
        published_at: '2026-05-18',
        status: 'published',
      },
      {
        title: 'The Rise of the Solo Operator: Building a $1M Business With AI Tools',
        excerpt:
          'A new class of entrepreneur is emerging — individuals running million-dollar operations with AI handling what used to require a team of ten.',
        body: "<h2>One Person, Ten Roles</h2><p>In 2024, building a million-dollar business solo was a lifestyle blog fantasy. In 2026, it's a structural shift. AI tools haven't just improved productivity — they've eliminated entire job functions.</p><h2>The Stack That Enables It</h2><p>The solo operators we interviewed share a common pattern:</p><ul><li><strong>AI writing + editing</strong> for all content production</li><li><strong>Automated customer support</strong> handling 80% of inquiries</li><li><strong>AI-assisted development</strong> shipping features weekly</li><li><strong>Automated bookkeeping</strong> with human review quarterly</li></ul><h2>What Still Requires a Human</h2><p>Strategy. Taste. Relationships. The operators who thrive aren't trying to automate everything — they're automating execution to spend more time on judgment calls that compound.</p>",
        author: AUTHOR_IDS.marcus,
        category: 'Industry News',
        tags: ['technology', 'growth', 'leadership'],
        published_at: '2026-05-15',
        status: 'published',
      },
      {
        title: 'Design Systems Are Strategy Documents (Treat Them Like One)',
        excerpt:
          "Your design system isn't a component library. It's a set of opinionated constraints that encode your product's values.",
        body: '<h2>Components vs. Decisions</h2><p>Most design systems document what exists. The good ones document what was decided — and why. The difference matters because the "why" is what makes the system extensible without drift.</p><h2>Three Layers of a Strategic Design System</h2><p><strong>Principles</strong> — the non-negotiable values (e.g., "density over whitespace" or "progressive disclosure always"). These are arguments, not descriptions.</p><p><strong>Tokens</strong> — the constrained palette. When you limit spacing to 8 options, you\'re not restricting creativity — you\'re eliminating the 40-minute debate about whether 14px or 16px is "better."</p><p><strong>Patterns</strong> — the composed solutions. These emerge from principles + tokens applied to real problems. They\'re discovered, not designed.</p><h2>The Test</h2><p>Can a new designer, reading only your design system docs, make the same decision you would? If not, you\'ve documented a library, not a system.</p>',
        author: AUTHOR_IDS.sarah,
        category: 'Opinion',
        tags: ['design', 'product', 'strategy'],
        published_at: '2026-05-12',
        status: 'published',
      },
      {
        title: 'How Meridian Consulting Doubled Revenue by Narrowing Their Focus',
        excerpt:
          'When Meridian stopped serving "all businesses" and went deep on healthcare SaaS, everything changed in 18 months.',
        body: '<h2>The Counterintuitive Move</h2><p>In Q1 2025, Meridian Consulting served 47 clients across 12 industries. Revenue was $2.1M. The team was exhausted, margins thin, and every proposal started from scratch.</p><p>Their CEO made what felt like a reckless decision: fire 60% of clients and focus exclusively on healthcare SaaS companies in growth stage.</p><h2>What Happened Next</h2><p>Within six months:</p><ul><li>Proposals went from 3 weeks to 3 days (same playbook, adapted)</li><li>Win rate jumped from 22% to 58% (deep expertise signals)</li><li>Average deal size grew 3x (they could charge for specialization)</li><li>Referrals became the primary channel (network effects in a niche)</li></ul><h2>The 18-Month Result</h2><p>Revenue hit $4.3M with fewer clients, higher margins, and a team that could finally build institutional knowledge that compounded.</p>',
        author: AUTHOR_IDS.marcus,
        category: 'Case Studies',
        tags: ['strategy', 'growth'],
        published_at: '2026-05-08',
        status: 'published',
      },
      {
        title: 'Introducing Our 2026 State of Content Report',
        excerpt:
          "We surveyed 1,200 content teams to understand what's working, what's broken, and where the industry is heading.",
        body: '<h2>The Survey</h2><p>Every year, we survey content leaders across B2B and B2C to understand how the profession is evolving. This year, 1,247 respondents from companies ranging from 10 to 10,000 employees shared their data.</p><h2>Key Findings</h2><p><strong>67% of teams</strong> now use AI in their content workflow (up from 31% in 2025).</p><p><strong>Average time to publish</strong> dropped from 12 days to 4 days — but quality scores (measured by engagement) stayed flat.</p><p><strong>The #1 challenge</strong> shifted from "producing enough content" to "differentiating from AI-generated competitors."</p><h2>Download the Full Report</h2><p>The complete 48-page report includes benchmarks by industry, team size, and content type. Free for subscribers.</p>',
        author: AUTHOR_IDS.sarah,
        category: 'Announcements',
        tags: ['marketing', 'strategy'],
        published_at: '2026-05-05',
        status: 'published',
      },
    ],
  },

  pages: [
    {
      slug: '/',
      title: 'Home',
      page_type: 'home',
      show_in_nav: true,
      nav_label: 'Home',
      nav_order: 0,
      blocks: [
        {
          id: 'home-hero',
          _type: 'hero',
          heading: 'Sharp thinking for people who build things',
          subheading:
            'Strategy, growth, and technology insights for operators and builders. No fluff, no filler — just ideas worth your time.',
          cta_text: 'Read the Latest',
          cta_url: '/blog',
          alignment: 'center',
        },
        {
          id: 'home-posts',
          _type: 'entity_grid',
          heading: 'Recent Posts',
          entity: 'post',
          sort: { field: 'published_at', dir: 'desc' },
          limit: 6,
          display_fields: ['title', 'excerpt', 'category', 'published_at', 'featured_image'],
          layout: 'cards',
          columns: 3,
        },
        {
          id: 'home-newsletter',
          _type: 'cta',
          heading: 'Get the weekly digest',
          text: 'One email per week with our best thinking. No spam, unsubscribe anytime.',
          cta_text: 'Subscribe',
          cta_url: '/contact',
        },
      ],
    },
    {
      slug: '/blog',
      title: 'Blog',
      page_type: 'blog_index',
      show_in_nav: true,
      nav_label: 'Blog',
      nav_order: 1,
      blocks: [
        {
          id: 'blog-hero',
          _type: 'hero',
          heading: 'All Posts',
          subheading: 'Strategy, growth, and technology insights.',
          alignment: 'left',
        },
        {
          id: 'blog-grid',
          _type: 'entity_grid',
          entity: 'post',
          sort: { field: 'published_at', dir: 'desc' },
          limit: 20,
          display_fields: [
            'title',
            'excerpt',
            'author',
            'category',
            'published_at',
            'featured_image',
          ],
          layout: 'cards',
          columns: 2,
        },
      ],
    },
    {
      slug: '/about',
      title: 'About',
      page_type: 'about',
      show_in_nav: true,
      nav_label: 'About',
      nav_order: 2,
      blocks: [
        {
          id: 'about-hero',
          _type: 'hero',
          heading: 'About Us',
          subheading:
            'We write for builders — the people making decisions about products, teams, and strategy every day.',
          alignment: 'left',
        },
        {
          id: 'about-story',
          _type: 'richtext',
          body: '<h2>Our Mission</h2><p>We started this publication because most business content is either too generic to be useful or too academic to be actionable. We write for the person in the middle — experienced enough to know the basics, busy enough to need the signal without the noise.</p><p>Every piece we publish passes a simple test: would we send this to a friend who asked for advice? If the answer is no, it doesn\'t ship.</p><h2>What We Cover</h2><p>Content strategy, growth marketing, product thinking, technology trends, and leadership — always through the lens of "what would a smart operator actually do with this information?"</p>',
        },
        {
          id: 'about-team',
          _type: 'entity_grid',
          heading: 'The Team',
          entity: 'person',
          display_fields: ['name', 'role', 'bio', 'photo'],
          layout: 'cards',
          columns: 2,
        },
        {
          id: 'about-cta',
          _type: 'cta',
          heading: 'Want to contribute?',
          text: 'We accept guest posts from practitioners with real-world experience. No thought leaders, no ghostwriters.',
          cta_text: 'Get in Touch',
          cta_url: '/contact',
        },
      ],
    },
    {
      slug: '/contact',
      title: 'Contact',
      page_type: 'contact',
      show_in_nav: true,
      nav_label: 'Contact',
      nav_order: 3,
      blocks: [
        {
          id: 'contact-hero',
          _type: 'hero',
          heading: 'Get in Touch',
          subheading: 'Questions, guest post pitches, partnership inquiries — we read everything.',
          alignment: 'left',
        },
        {
          id: 'contact-form',
          _type: 'form',
          heading: 'Send us a message',
          entity_slug: 'contact_inquiry',
          fields: [
            { name: 'name', type: 'text', label: 'Your Name', required: true },
            { name: 'email', type: 'email', label: 'Email', required: true },
            {
              name: 'subject',
              type: 'select',
              label: 'Subject',
              options: [
                'General inquiry',
                'Guest post pitch',
                'Partnership',
                'Advertising',
                'Other',
              ],
            },
            {
              name: 'message',
              type: 'textarea',
              label: 'Message',
              required: true,
              placeholder: 'What can we help with?',
            },
          ],
          submit_label: 'Send Message',
        },
      ],
    },
  ],

  theme: {
    colors: {
      primary: '#1a1a2e',
      secondary: '#16213e',
      accent: '#e94560',
      background: '#ffffff',
      surface: '#f8f9fa',
      text: '#2d3436',
      heading: '#0c0c0c',
    },
    fonts: {
      heading: 'Newsreader, Georgia, serif',
      body: 'Inter, system-ui, sans-serif',
    },
    radius: 'sm',
    shadow: 'sm',
    spacing: 'relaxed',
  },

  config: {
    title: "The Builder's Journal",
    description:
      'Sharp thinking for people who build things. Strategy, growth, and technology insights.',
  },

  nav: {
    logo_text: "The Builder's Journal",
    style: 'minimal',
  },

  footer: {
    copyright: "2026 The Builder's Journal. All rights reserved.",
    links: [{ label: 'RSS', url: '/feed.xml' }],
  },

  admin_views: [
    {
      entity_slug: 'post',
      label: 'Posts',
      icon: 'P',
      layout: 'table',
      sort_order: 0,
      config: {
        columns: ['title', 'category', 'published_at', 'status'],
        actions: ['edit', 'delete'],
      },
    },
    {
      entity_slug: 'person',
      label: 'Authors',
      icon: 'A',
      layout: 'cards',
      sort_order: 1,
      config: { image_field: 'image', title_field: 'name', subtitle_field: 'title' },
    },
    {
      entity_slug: 'contact_inquiry',
      label: 'Inquiries',
      icon: '✉',
      layout: 'table',
      sort_order: 2,
      config: { columns: ['name', 'email', 'message', 'status'] },
    },
  ],

  admin_widgets: [
    {
      widget_type: 'stat',
      label: 'Published Posts',
      config: { entity_slug: 'post' },
      sort_order: 0,
    },
    { widget_type: 'stat', label: 'Authors', config: { entity_slug: 'person' }, sort_order: 1 },
    {
      widget_type: 'recent',
      label: 'Latest Posts',
      config: { entity_slug: 'post', limit: 5, fields: ['title', 'published_at'] },
      sort_order: 2,
    },
    {
      widget_type: 'inbox',
      label: 'New Inquiries',
      config: { entity_slug: 'contact_inquiry' },
      sort_order: 3,
    },
  ],
};
