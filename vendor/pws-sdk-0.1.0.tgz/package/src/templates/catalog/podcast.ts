import type { TemplateBundle } from '@pws/shared';

export const podcastTemplate: TemplateBundle = {
  slug: 'podcast',
  name: 'Podcast / Media',
  description:
    'Show platform with episode archive, guest profiles, show notes, and sponsorship inquiry. For podcasters and media creators.',
  icon: 'M',
  verticals: ['podcast', 'interview show', 'video series', 'audio content'],
  combines_with: ['blog', 'portfolio', 'professional'],

  schemas: [
    {
      slug: 'person',
      name: 'Person',
      name_plural: 'People',
      icon: 'P',
      fields: [
        { slug: 'name', name: 'Name', type: 'text', required: true },
        { slug: 'title', name: 'Title', type: 'text' },
        { slug: 'company', name: 'Company', type: 'text' },
        { slug: 'photo', name: 'Photo', type: 'image' },
        { slug: 'bio', name: 'Bio', type: 'richtext' },
        {
          slug: 'role_type',
          name: 'Role',
          type: 'select',
          options: ['Host', 'Guest', 'Producer'],
        },
        { slug: 'twitter', name: 'Twitter/X', type: 'url' },
        { slug: 'linkedin', name: 'LinkedIn', type: 'url' },
        { slug: 'website', name: 'Website', type: 'url' },
      ],
    },
    {
      slug: 'episode',
      name: 'Episode',
      name_plural: 'Episodes',
      icon: 'E',
      fields: [
        { slug: 'title', name: 'Title', type: 'text', required: true },
        { slug: 'episode_number', name: 'Episode #', type: 'number', required: true },
        { slug: 'season', name: 'Season', type: 'number', default: 1 },
        { slug: 'description', name: 'Description', type: 'text', required: true },
        { slug: 'show_notes', name: 'Show Notes', type: 'richtext' },
        { slug: 'guest', name: 'Guest', type: 'reference', reference_to: 'person' },
        { slug: 'published_at', name: 'Published', type: 'date', required: true },
        { slug: 'duration', name: 'Duration', type: 'text' },
        { slug: 'audio_url', name: 'Audio URL', type: 'url' },
        { slug: 'video_url', name: 'Video URL', type: 'url' },
        { slug: 'transcript', name: 'Transcript', type: 'richtext' },
        { slug: 'cover_image', name: 'Cover Image', type: 'image' },
        {
          slug: 'topics',
          name: 'Topics',
          type: 'multiselect',
          options: [
            'Startups',
            'Product',
            'Engineering',
            'Design',
            'Leadership',
            'AI',
            'Growth',
            'Culture',
            'Fundraising',
            'Career',
          ],
        },
      ],
    },
    {
      slug: 'sponsorship_inquiry',
      name: 'Sponsorship Inquiry',
      name_plural: 'Sponsorship Inquiries',
      icon: 'S',
      public_writable: true,
      fields: [
        { slug: 'name', name: 'Name', type: 'text', required: true },
        { slug: 'email', name: 'Email', type: 'email', required: true },
        { slug: 'company', name: 'Company', type: 'text', required: true },
        {
          slug: 'type',
          name: 'Inquiry Type',
          type: 'select',
          options: ['Sponsorship', 'Guest Pitch', 'Partnership', 'Press', 'Other'],
        },
        { slug: 'message', name: 'Message', type: 'text', required: true },
      ],
    },
  ],

  records: {
    person: [
      {
        name: 'Elena Vasquez',
        title: 'Host & Producer',
        company: 'The Operators Podcast',
        bio: '<p>Elena spent 8 years as a product leader at Shopify and Figma before starting The Operators. She interviews the people behind the products — not about their success, but about the decisions that almost killed the company.</p>',
        role_type: 'Host',
      },
      {
        name: 'David Kim',
        title: 'Co-Host',
        company: 'The Operators Podcast',
        bio: "<p>David is a 3x founder (one exit, one failure, one in progress). He brings the builder's perspective — asking the questions that operators actually care about, not the ones that make good headlines.</p>",
        role_type: 'Host',
      },
      {
        name: 'Amara Osei',
        title: 'VP Engineering',
        company: 'Retool',
        bio: '<p>Amara leads a 200-person engineering org at Retool. Previously built and scaled infrastructure teams at Stripe and Square. Known for her framework on "engineering as a product org."</p>',
        role_type: 'Guest',
      },
      {
        name: 'Jason Fried',
        title: 'Co-Founder & CEO',
        company: '37signals',
        bio: "<p>Jason co-founded 37signals (makers of Basecamp and HEY) and has been writing about calm, profitable software companies for 20 years. Author of Rework, Remote, and It Doesn't Have to Be Crazy at Work.</p>",
        role_type: 'Guest',
      },
      {
        name: 'Riya Patel',
        title: 'Chief Product Officer',
        company: 'Notion',
        bio: '<p>Riya joined Notion at 50 employees and helped scale the product org to 500+. She talks about the tension between platform ambition and product simplicity — and how Notion navigates it.</p>',
        role_type: 'Guest',
      },
    ],
    episode: [
      {
        title: 'The Eng Org as a Product (with Amara Osei)',
        episode_number: 47,
        season: 3,
        description:
          'Amara Osei (VP Eng, Retool) explains why she runs her engineering org like a product — with roadmaps, user research, and NPS scores for internal developer tools.',
        show_notes:
          '<h3>Key Topics</h3><ul><li>Why Amara treats internal tooling as a "product" with its own PM</li><li>The framework for deciding what to build vs. buy for developer productivity</li><li>How she measures engineering happiness without surveillance</li><li>The "eng org roadmap" — planning organizational capabilities like product features</li></ul><h3>Links</h3><ul><li>Amara\'s blog post: "Your Eng Org Needs a Product Manager"</li><li>Retool careers page</li></ul>',
        guest: 'c0000000-0000-0000-0000-000000000003',
        published_at: '2026-05-20',
        duration: '58 min',
        topics: ['Engineering', 'Leadership', 'Product'],
      },
      {
        title: 'Why We Stayed Small on Purpose (with Jason Fried)',
        episode_number: 46,
        season: 3,
        description:
          'Jason Fried makes the case for building a calm, profitable company in an era of hypergrowth — and why 37signals turned down acquisition offers that would have made everyone rich.',
        show_notes:
          '<h3>Key Topics</h3><ul><li>The economics of a 80-person company doing $100M+ revenue</li><li>Why Jason thinks most companies are "playing house"</li><li>How to say no to growth that doesn\'t serve the team</li><li>The decision to leave the cloud (spending $500k/year on servers instead)</li><li>What "enough" means when everyone around you wants "more"</li></ul><h3>Links</h3><ul><li>37signals.com</li><li>Jason\'s book: "It Doesn\'t Have to Be Crazy at Work"</li></ul>',
        guest: 'c0000000-0000-0000-0000-000000000004',
        published_at: '2026-05-13',
        duration: '72 min',
        topics: ['Startups', 'Leadership', 'Culture'],
      },
      {
        title: "Platform vs. Product: Notion's Balancing Act (with Riya Patel)",
        episode_number: 45,
        season: 3,
        description:
          'Riya Patel (CPO, Notion) on the hardest product decision at scale: when do you let users build whatever they want, and when do you impose structure?',
        show_notes:
          '<h3>Key Topics</h3><ul><li>The "blank page problem" — why flexibility can be paralyzing</li><li>How Notion decides what to build into the core vs. leave to templates</li><li>The role of AI in reducing the gap between power users and beginners</li><li>What Riya learned scaling the product org from 10 to 200</li><li>Why Notion killed features that users loved (and how they communicated it)</li></ul><h3>Links</h3><ul><li>Notion\'s engineering blog</li><li>Riya\'s talk at Config 2025</li></ul>',
        guest: 'c0000000-0000-0000-0000-000000000005',
        published_at: '2026-05-06',
        duration: '64 min',
        topics: ['Product', 'AI', 'Leadership'],
      },
      {
        title: 'When to Quit Your Startup (a frank conversation)',
        episode_number: 44,
        season: 3,
        description:
          "Elena and David get personal about the hardest question in startups: how do you know when to keep going vs. when you're just sunk-costing? David shares the story of shutting down his second company.",
        show_notes:
          '<h3>Key Topics</h3><ul><li>The signals David missed (and the one he finally couldn\'t ignore)</li><li>The difference between a "pivot" and denial</li><li>How to shut down with integrity — to your team, investors, and yourself</li><li>Elena\'s framework: "Would I start this company today with what I know?"</li><li>What comes after — the grief, the relief, and the rebuild</li></ul>',
        published_at: '2026-04-29',
        duration: '51 min',
        topics: ['Startups', 'Career', 'Culture'],
      },
      {
        title: 'Hiring Your First 10 Engineers (lessons from doing it wrong)',
        episode_number: 43,
        season: 3,
        description:
          'David and Elena break down the most common mistakes in early-stage technical hiring — from over-indexing on pedigree to the "senior engineer trap" that kills velocity.',
        show_notes:
          '<h3>Key Topics</h3><ul><li>Why your first 10 hires should be generalists, not specialists</li><li>The "senior engineer trap" — when experience becomes a liability</li><li>How to interview for ownership instead of credentials</li><li>Compensation strategy when you can\'t compete on salary</li><li>The one interview question David asks every candidate</li></ul>',
        published_at: '2026-04-22',
        duration: '45 min',
        topics: ['Startups', 'Engineering', 'Culture'],
      },
    ],
  },

  pages: [
    {
      slug: '/',
      title: 'Home',
      page_type: 'home',
      show_in_nav: true,
      nav_label: 'Home',
      nav_order: 0,
      blocks: [
        {
          id: 'home-hero',
          _type: 'hero',
          heading: 'The Operators',
          subheading:
            "Honest conversations with the people building technology companies. No highlight reels — just the real decisions, tradeoffs, and lessons that don't make it into the press release.",
          cta_text: 'Latest Episode',
          cta_url: '/episodes',
          cta2_text: 'Subscribe',
          cta2_url: '/subscribe',
          alignment: 'center',
        },
        {
          id: 'home-latest',
          _type: 'entity_grid',
          heading: 'Recent Episodes',
          entity: 'episode',
          sort: { field: 'episode_number', dir: 'desc' },
          limit: 3,
          display_fields: ['title', 'description', 'guest', 'duration', 'published_at', 'topics'],
          layout: 'cards',
          columns: 1,
        },
        {
          id: 'home-stats',
          _type: 'features',
          heading: 'The Show',
          items: [
            {
              icon: '47',
              title: 'Episodes',
              description: 'Three seasons of in-depth conversations with operators and builders.',
            },
            {
              icon: '12K',
              title: 'Weekly Listeners',
              description:
                'Product leaders, founders, and engineers who want the unfiltered version.',
            },
            {
              icon: '60m',
              title: 'Avg. Length',
              description: "Long enough to go deep. We don't do 15-minute hot takes.",
            },
          ],
        },
        {
          id: 'home-cta',
          _type: 'cta',
          heading: 'Never miss an episode',
          text: 'New episodes every Tuesday. Available on Apple Podcasts, Spotify, YouTube, and everywhere you listen.',
          cta_text: 'Subscribe',
          cta_url: '/subscribe',
        },
      ],
    },
    {
      slug: '/episodes',
      title: 'Episodes',
      page_type: 'episodes',
      show_in_nav: true,
      nav_label: 'Episodes',
      nav_order: 1,
      blocks: [
        {
          id: 'episodes-hero',
          _type: 'hero',
          heading: 'All Episodes',
          subheading: 'Every conversation, from episode 1 to today.',
          alignment: 'left',
        },
        {
          id: 'episodes-list',
          _type: 'entity_grid',
          entity: 'episode',
          sort: { field: 'episode_number', dir: 'desc' },
          limit: 50,
          display_fields: [
            'title',
            'episode_number',
            'description',
            'guest',
            'duration',
            'published_at',
            'topics',
            'cover_image',
          ],
          layout: 'cards',
          columns: 1,
        },
      ],
    },
    {
      slug: '/guests',
      title: 'Guests',
      page_type: 'guests',
      show_in_nav: true,
      nav_label: 'Guests',
      nav_order: 2,
      blocks: [
        {
          id: 'guests-hero',
          _type: 'hero',
          heading: 'Our Guests',
          subheading:
            'Founders, product leaders, engineers, and operators who shared their real stories.',
          alignment: 'left',
        },
        {
          id: 'guests-grid',
          _type: 'entity_grid',
          entity: 'person',
          filter: { role_type: 'Guest' },
          display_fields: ['name', 'title', 'company', 'photo', 'bio'],
          layout: 'cards',
          columns: 3,
        },
      ],
    },
    {
      slug: '/about',
      title: 'About',
      page_type: 'about',
      show_in_nav: true,
      nav_label: 'About',
      nav_order: 3,
      blocks: [
        {
          id: 'about-hero',
          _type: 'hero',
          heading: 'About The Show',
          alignment: 'left',
        },
        {
          id: 'about-story',
          _type: 'richtext',
          body: "<h2>Why We Started This</h2><p>Most business podcasts fall into two categories: celebrity founders telling their highlight reel, or consultants promoting frameworks. Neither is useful to the person in the trenches making real decisions every day.</p><p>The Operators exists for that person. We interview people who are actively building — and we ask the uncomfortable questions. What almost killed the company? What decision do you regret? What do you know now that you wish you knew then?</p><h2>Our Format</h2><p>Each episode is a single, in-depth conversation (typically 45-75 minutes). No ads mid-roll. No rapid-fire questions. Just two people talking honestly about the craft of building technology companies.</p><h2>Who Listens</h2><p>Our audience is primarily product leaders, engineering managers, founders, and senior ICs at technology companies. People who've shipped things and want to get better at shipping things.</p>",
        },
        {
          id: 'about-hosts',
          _type: 'entity_grid',
          heading: 'Your Hosts',
          entity: 'person',
          filter: { role_type: 'Host' },
          display_fields: ['name', 'title', 'bio', 'photo'],
          layout: 'cards',
          columns: 2,
        },
      ],
    },
    {
      slug: '/subscribe',
      title: 'Subscribe',
      page_type: 'subscribe',
      show_in_nav: true,
      nav_label: 'Subscribe',
      nav_order: 4,
      blocks: [
        {
          id: 'subscribe-hero',
          _type: 'hero',
          heading: 'Listen Everywhere',
          subheading: 'New episodes drop every Tuesday at 6am PT.',
          alignment: 'center',
        },
        {
          id: 'subscribe-links',
          _type: 'features',
          heading: 'Choose Your Platform',
          items: [
            {
              title: 'Apple Podcasts',
              description: 'Subscribe on Apple Podcasts for automatic downloads.',
            },
            {
              title: 'Spotify',
              description: 'Follow on Spotify to get notified of new episodes.',
            },
            {
              title: 'YouTube',
              description: 'Watch the video version with full guest reactions.',
            },
            {
              title: 'RSS Feed',
              description: 'Add our RSS feed to your preferred podcast app.',
            },
          ],
        },
        {
          id: 'subscribe-newsletter',
          _type: 'cta',
          heading: 'Get the show notes by email',
          text: 'Every Tuesday we send the episode link, key takeaways, and links mentioned. No spam.',
          cta_text: 'Subscribe to Newsletter',
          cta_url: '/contact',
        },
      ],
    },
    {
      slug: '/contact',
      title: 'Contact',
      page_type: 'contact',
      show_in_nav: false,
      nav_order: 5,
      blocks: [
        {
          id: 'contact-hero',
          _type: 'hero',
          heading: 'Get in Touch',
          subheading: 'Sponsorship inquiries, guest pitches, or just want to say hi.',
          alignment: 'left',
        },
        {
          id: 'contact-form',
          _type: 'form',
          heading: 'Send us a message',
          entity_slug: 'sponsorship_inquiry',
          fields: [
            { name: 'name', type: 'text', label: 'Your Name', required: true },
            { name: 'email', type: 'email', label: 'Email', required: true },
            { name: 'company', type: 'text', label: 'Company', required: true },
            {
              name: 'type',
              type: 'select',
              label: "What's this about?",
              options: ['Sponsorship', 'Guest Pitch', 'Partnership', 'Press', 'Other'],
            },
            {
              name: 'message',
              type: 'textarea',
              label: 'Message',
              required: true,
              placeholder: 'Tell us more...',
            },
          ],
          submit_label: 'Send',
        },
        {
          id: 'contact-faq',
          _type: 'faq',
          heading: 'Common Questions',
          items: [
            {
              question: 'How do I pitch myself or someone as a guest?',
              answer:
                'Use the form above with "Guest Pitch" selected. Tell us who, what they\'d talk about, and why our audience would care. We book 2-3 months ahead.',
            },
            {
              question: 'What are your sponsorship rates?',
              answer:
                "We offer pre-roll and post-roll sponsorships on a per-episode or quarterly basis. Reach out via the form and we'll send our media kit.",
            },
            {
              question: 'Can I get a transcript of an episode?',
              answer:
                "Yes — full transcripts are available on each episode's detail page. We publish them within 48 hours of the episode going live.",
            },
            {
              question: 'Do you do live shows or events?',
              answer:
                "Occasionally! We've done live recordings at conferences (SaaStr, Config). Follow us on Twitter for announcements.",
            },
          ],
        },
      ],
    },
  ],

  theme: {
    colors: {
      primary: '#7c3aed',
      secondary: '#a78bfa',
      accent: '#fbbf24',
      background: '#0f0f0f',
      surface: '#1a1a1a',
      text: '#e5e5e5',
      heading: '#ffffff',
    },
    fonts: {
      heading: 'Inter, system-ui, sans-serif',
      body: 'Inter, system-ui, sans-serif',
    },
    radius: 'md',
    shadow: 'md',
    spacing: 'normal',
  },

  config: {
    title: 'The Operators',
    description:
      'Honest conversations with the people building technology companies. No highlight reels — just real decisions and lessons.',
  },

  nav: {
    logo_text: 'The Operators',
    style: 'standard',
  },

  footer: {
    copyright: '2026 The Operators Podcast',
    links: [
      { label: 'Apple Podcasts', url: 'https://podcasts.apple.com' },
      { label: 'Spotify', url: 'https://spotify.com' },
      { label: 'YouTube', url: 'https://youtube.com' },
      { label: 'Twitter', url: 'https://twitter.com' },
    ],
  },

  admin_views: [
    {
      entity_slug: 'episode',
      label: 'Episodes',
      icon: 'E',
      layout: 'table',
      sort_order: 0,
      config: { columns: ['title', 'episode_number', 'season', 'published_at', 'duration'] },
    },
    {
      entity_slug: 'person',
      label: 'People',
      icon: 'P',
      layout: 'cards',
      sort_order: 1,
      config: { image_field: 'photo', title_field: 'name', subtitle_field: 'role_type' },
    },
    {
      entity_slug: 'sponsorship_inquiry',
      label: 'Sponsors',
      icon: '✉',
      layout: 'table',
      sort_order: 2,
      config: { columns: ['name', 'email', 'company', 'budget'] },
    },
  ],
};
