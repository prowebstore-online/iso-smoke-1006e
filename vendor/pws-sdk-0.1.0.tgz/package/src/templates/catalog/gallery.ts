import type { TemplateBundle } from '@pws/shared';

// Art-gallery storefront: a catalog of original artworks by represented artists,
// with a real shopping cart + (test) checkout. Sellable entity is `product` so
// it reuses the platform cart/checkout machinery. Demo content is original.

const CATEGORY_IDS = {
  landscape: 'a0000000-0000-0000-0000-000000000001',
  birds_flowers: 'a0000000-0000-0000-0000-000000000002',
  figures: 'a0000000-0000-0000-0000-000000000003',
  calligraphy: 'a0000000-0000-0000-0000-000000000004',
};

export const galleryTemplate: TemplateBundle = {
  slug: 'gallery',
  name: 'Art Gallery',
  description:
    'A fine-art gallery storefront: represented artists, an artwork catalog by genre, and a real cart + checkout. For galleries, studios, and independent artists selling originals and prints.',
  icon: 'G',
  verticals: ['art gallery', 'studio', 'artist', 'prints', 'fine art', 'collectibles'],
  combines_with: ['blog', 'professional'],

  schemas: [
    {
      slug: 'category',
      name: 'Genre',
      name_plural: 'Genres',
      icon: 'G',
      fields: [
        { slug: 'name', name: 'Name', type: 'text', required: true },
        { slug: 'description', name: 'Description', type: 'text' },
        { slug: 'image', name: 'Image', type: 'image' },
        { slug: 'sort_order', name: 'Sort Order', type: 'number', default: 0 },
      ],
    },
    {
      slug: 'artist',
      name: 'Artist',
      name_plural: 'Artists',
      icon: 'A',
      fields: [
        { slug: 'name', name: 'Name', type: 'text', required: true },
        { slug: 'specialty', name: 'Specialty', type: 'text' },
        { slug: 'bio', name: 'Biography', type: 'richtext' },
        { slug: 'photo', name: 'Photo', type: 'image' },
      ],
    },
    {
      slug: 'product',
      name: 'Artwork',
      name_plural: 'Artworks',
      icon: 'P',
      fields: [
        { slug: 'name', name: 'Title', type: 'text', required: true },
        { slug: 'artist', name: 'Artist', type: 'text' },
        { slug: 'description', name: 'Description', type: 'richtext' },
        { slug: 'price', name: 'Price', type: 'number', required: true },
        { slug: 'image', name: 'Image', type: 'image' },
        { slug: 'dimensions', name: 'Dimensions', type: 'text' },
        { slug: 'year', name: 'Year', type: 'text' },
        {
          slug: 'medium',
          name: 'Medium',
          type: 'select',
          options: [
            'Ink on Paper',
            'Ink & Color on Paper',
            'Oil on Canvas',
            'Watercolor',
            'Calligraphy',
            'Mixed Media',
          ],
        },
        { slug: 'category', name: 'Genre', type: 'reference', reference_to: 'category' },
        { slug: 'in_stock', name: 'Available', type: 'boolean', default: true },
        { slug: 'featured', name: 'Featured', type: 'boolean', default: false },
        {
          slug: 'tags',
          name: 'Tags',
          type: 'multiselect',
          options: ['New Acquisition', 'Featured', 'Original', 'Limited Print', 'Commission'],
        },
      ],
    },
    {
      slug: 'inquiry',
      name: 'Inquiry',
      name_plural: 'Inquiries',
      icon: '✉',
      public_writable: true,
      fields: [
        { slug: 'name', name: 'Name', type: 'text', required: true },
        { slug: 'email', name: 'Email', type: 'email', required: true },
        { slug: 'artwork', name: 'Artwork of interest', type: 'text' },
        { slug: 'message', name: 'Message', type: 'text', required: true },
      ],
    },
    {
      slug: 'order',
      name: 'Order',
      name_plural: 'Orders',
      icon: '$',
      fields: [
        { slug: 'customer_name', name: 'Customer Name', type: 'text' },
        { slug: 'customer_email', name: 'Customer Email', type: 'text' },
        { slug: 'shipping_address', name: 'Shipping Address', type: 'text' },
        { slug: 'items', name: 'Items (JSON)', type: 'text' },
        { slug: 'item_count', name: 'Item Count', type: 'number' },
        { slug: 'subtotal', name: 'Subtotal', type: 'number' },
        { slug: 'total', name: 'Total', type: 'number', required: true },
        {
          slug: 'status',
          name: 'Status',
          type: 'select',
          options: ['Paid (test)', 'Pending', 'Fulfilled', 'Cancelled', 'Refunded'],
        },
        { slug: 'payment_ref', name: 'Payment Reference', type: 'text' },
      ],
    },
  ],

  records: {
    category: [
      {
        name: 'Landscapes',
        description: 'Mountains, rivers, and mist — the classical shan shui tradition.',
        sort_order: 1,
      },
      {
        name: 'Birds & Flowers',
        description: 'Studies of the natural world, from plum blossoms to magpies.',
        sort_order: 2,
      },
      {
        name: 'Figures',
        description: 'Portraits and figure studies in ink and oil.',
        sort_order: 3,
      },
      {
        name: 'Calligraphy',
        description: 'Brushwork and the written character as fine art.',
        sort_order: 4,
      },
    ],
    artist: [
      {
        name: 'Lin Wanqing',
        specialty: 'Landscape · Ink & Color',
        bio: '<p>Lin Wanqing studied at the China Academy of Art and has spent three decades reinterpreting the shan shui landscape for a contemporary eye. Her work pairs traditional layered-ink technique with unexpected, luminous color.</p>',
      },
      {
        name: 'Chen Mu',
        specialty: 'Birds & Flowers',
        bio: '<p>Chen Mu is known for spare, confident brushwork in the xieyi (freehand) style. A single magpie on a branch, a few strokes of plum blossom — his economy is the point.</p>',
      },
      {
        name: 'Sofia Auer',
        specialty: 'Figures · Oil',
        bio: '<p>Vienna-born and Shanghai-based, Sofia Auer brings a European oil-portrait sensibility into dialogue with East Asian composition. She exhibits internationally and accepts a small number of commissions each year.</p>',
      },
      {
        name: 'Wei Zhao',
        specialty: 'Calligraphy',
        bio: '<p>A calligrapher in the running-script tradition, Wei Zhao treats each scroll as a single, unrepeatable gesture. His pieces are held in several private collections across Asia.</p>',
      },
    ],
    product: [
      {
        name: 'Morning Mist Over Green Peaks',
        artist: 'Lin Wanqing',
        description:
          '<p>A layered ink-and-color landscape in the shan shui tradition. Receding ranges dissolve into rice-paper mist, with a single fishing skiff anchoring the foreground. Mounted as a hanging scroll.</p>',
        price: 480000,
        dimensions: '68 × 136 cm',
        year: '2024',
        medium: 'Ink & Color on Paper',
        category: CATEGORY_IDS.landscape,
        in_stock: true,
        featured: true,
        tags: ['Featured', 'Original'],
      },
      {
        name: 'River Village in Autumn',
        artist: 'Lin Wanqing',
        description:
          '<p>Warm ochres and cool grey ink describe a quiet riverbank at the turn of the season. The composition leaves generous empty space — the breath of the painting.</p>',
        price: 360000,
        dimensions: '50 × 100 cm',
        year: '2023',
        medium: 'Ink & Color on Paper',
        category: CATEGORY_IDS.landscape,
        in_stock: true,
        featured: true,
        tags: ['Original'],
      },
      {
        name: 'Magpie on a Plum Branch',
        artist: 'Chen Mu',
        description:
          '<p>A freehand (xieyi) study: one magpie, a spray of early plum blossom, and the confidence to stop. Ink on raw xuan paper.</p>',
        price: 145000,
        dimensions: '34 × 96 cm',
        year: '2024',
        medium: 'Ink on Paper',
        category: CATEGORY_IDS.birds_flowers,
        in_stock: true,
        featured: true,
        tags: ['New Acquisition', 'Original'],
      },
      {
        name: 'Lotus After Rain',
        artist: 'Chen Mu',
        description:
          '<p>Broad wet strokes for the lotus leaves, fine line for the stems. A meditation on impermanence rendered in a single sitting.</p>',
        price: 120000,
        dimensions: '45 × 68 cm',
        year: '2022',
        medium: 'Ink on Paper',
        category: CATEGORY_IDS.birds_flowers,
        in_stock: true,
        featured: false,
        tags: ['Original'],
      },
      {
        name: 'Portrait in Lamplight',
        artist: 'Sofia Auer',
        description:
          '<p>An oil portrait built from warm shadow, in the manner of the old masters but composed with the asymmetry of an ink scroll. Framed.</p>',
        price: 520000,
        dimensions: '60 × 80 cm',
        year: '2023',
        medium: 'Oil on Canvas',
        category: CATEGORY_IDS.figures,
        in_stock: true,
        featured: true,
        tags: ['Featured', 'Original'],
      },
      {
        name: 'The Reader',
        artist: 'Sofia Auer',
        description:
          '<p>A quiet figure study — a young woman absorbed in a book by a window. Oil on canvas, gallery-wrapped.</p>',
        price: 290000,
        dimensions: '50 × 65 cm',
        year: '2024',
        medium: 'Oil on Canvas',
        category: CATEGORY_IDS.figures,
        in_stock: true,
        featured: false,
        tags: ['New Acquisition'],
      },
      {
        name: 'Still Waters Run Deep',
        artist: 'Wei Zhao',
        description:
          '<p>A four-character idiom rendered in running script, brushed in a single breath on a vertical scroll. The ink tone shifts from saturated black to dry飞白 (flying-white) as the brush empties.</p>',
        price: 98000,
        dimensions: '35 × 138 cm',
        year: '2024',
        medium: 'Calligraphy',
        category: CATEGORY_IDS.calligraphy,
        in_stock: true,
        featured: false,
        tags: ['Original'],
      },
      {
        name: 'Wind and Pine — Limited Print',
        artist: 'Wei Zhao',
        description:
          '<p>A giclée print of a celebrated calligraphic work, in an edition of 50, each stamped with the studio seal. An accessible way to begin a collection.</p>',
        price: 24000,
        dimensions: '40 × 60 cm',
        year: '2024',
        medium: 'Calligraphy',
        category: CATEGORY_IDS.calligraphy,
        in_stock: true,
        featured: false,
        tags: ['Limited Print'],
      },
    ],
  },

  pages: [
    {
      slug: '/',
      title: 'Home',
      page_type: 'home',
      show_in_nav: true,
      nav_label: 'Home',
      nav_order: 0,
      blocks: [
        {
          id: 'home-hero',
          _type: 'hero',
          heading: 'Xiang Jiang Gallery',
          subheading:
            'Original ink, oil, and calligraphy from our represented artists. Browse the collection, then take a piece home.',
          cta_text: 'View the Collection',
          cta_url: '/gallery',
          cta2_text: 'Our Artists',
          cta2_url: '/artists',
          alignment: 'center',
        },
        {
          id: 'home-featured',
          _type: 'product_grid',
          heading: 'Featured Works',
          entity: 'product',
          filter: { featured: true },
          columns: 3,
          cart_url: '/cart',
          image_fit: 'contain',
        },
        {
          id: 'home-genres',
          _type: 'entity_grid',
          heading: 'Browse by Genre',
          entity: 'category',
          display_fields: ['name', 'description', 'image'],
          layout: 'grid',
          columns: 4,
        },
        {
          id: 'home-artists',
          _type: 'entity_grid',
          heading: 'Represented Artists',
          entity: 'artist',
          display_fields: ['name', 'specialty', 'photo'],
          layout: 'cards',
          columns: 4,
        },
      ],
    },
    {
      slug: '/gallery',
      title: 'Gallery',
      page_type: 'shop',
      show_in_nav: true,
      nav_label: 'Gallery',
      nav_order: 1,
      blocks: [
        {
          id: 'gallery-hero',
          _type: 'hero',
          heading: 'The Collection',
          subheading:
            'Original works and limited prints. Prices include certificate of authenticity.',
          alignment: 'left',
        },
        {
          id: 'gallery-grid',
          _type: 'product_grid',
          entity: 'product',
          columns: 3,
          cart_url: '/cart',
          image_fit: 'contain',
        },
      ],
    },
    {
      slug: '/artists',
      title: 'Artists',
      page_type: 'artists',
      show_in_nav: true,
      nav_label: 'Artists',
      nav_order: 2,
      blocks: [
        {
          id: 'artists-hero',
          _type: 'hero',
          heading: 'Our Artists',
          subheading: 'The painters and calligraphers represented by the gallery.',
          alignment: 'left',
        },
        {
          id: 'artists-grid',
          _type: 'entity_grid',
          entity: 'artist',
          display_fields: ['name', 'specialty', 'bio', 'photo'],
          layout: 'cards',
          columns: 2,
        },
      ],
    },
    {
      slug: '/about',
      title: 'About',
      page_type: 'about',
      show_in_nav: true,
      nav_label: 'About',
      nav_order: 3,
      blocks: [
        {
          id: 'about-hero',
          _type: 'hero',
          heading: 'About the Gallery',
          alignment: 'left',
        },
        {
          id: 'about-story',
          _type: 'richtext',
          body: "<h2>A house for original work</h2><p>Xiang Jiang Gallery represents a small group of painters and calligraphers working across the ink, oil, and calligraphic traditions. We show original work — and a handful of carefully produced limited prints — and we believe a serious painting should be lived with, not just looked at.</p><h2>How buying works</h2><p>Every piece on this site can be reserved and purchased directly. Originals ship rolled or framed, insured, with a certificate of authenticity. For commissions or to view a work in person, use the inquiry form and we'll be in touch within two business days.</p><h2>Visiting</h2><p>The gallery is open by appointment. We're happy to walk you through the current collection and discuss anything you're considering for your home or collection.</p>",
        },
      ],
    },
    {
      slug: '/news',
      title: 'News',
      page_type: 'news',
      show_in_nav: true,
      nav_label: 'News',
      nav_order: 4,
      blocks: [
        {
          id: 'news-hero',
          _type: 'hero',
          heading: 'Gallery News',
          alignment: 'left',
        },
        {
          id: 'news-items',
          _type: 'cards',
          items: [
            {
              title: 'New acquisitions from Chen Mu',
              description:
                'Two new freehand ink studies have joined the collection this season, including "Magpie on a Plum Branch."',
            },
            {
              title: 'Sofia Auer — commissions open',
              description:
                'Sofia is accepting a small number of portrait commissions for the coming year. Inquire for details and timelines.',
            },
            {
              title: 'Limited prints now available',
              description:
                'A first run of studio-stamped giclée prints makes several signature works available at an accessible price.',
            },
          ],
        },
      ],
    },
    {
      slug: '/cart',
      title: 'Cart',
      page_type: 'cart',
      show_in_nav: true,
      nav_label: 'Cart',
      nav_order: 5,
      blocks: [
        {
          id: 'cart-block',
          _type: 'cart',
          heading: 'Your Cart',
          empty_message:
            'Your cart is empty. Browse the collection and add a piece to get started.',
          checkout_text: 'Proceed to Checkout',
          continue_shopping_url: '/gallery',
          checkout_url: '/checkout',
        },
      ],
    },
    {
      slug: '/contact',
      title: 'Contact',
      page_type: 'contact',
      show_in_nav: true,
      nav_label: 'Contact',
      nav_order: 6,
      blocks: [
        {
          id: 'contact-hero',
          _type: 'hero',
          heading: 'Inquire',
          subheading:
            'Questions about a piece, a commission, or a private viewing? Send a note and we’ll reply within two business days.',
          alignment: 'left',
        },
        {
          id: 'contact-form',
          _type: 'form',
          heading: 'Send an inquiry',
          entity_slug: 'inquiry',
          fields: [
            { name: 'name', type: 'text', label: 'Your Name', required: true },
            { name: 'email', type: 'email', label: 'Email', required: true },
            {
              name: 'artwork',
              type: 'text',
              label: 'Artwork of interest',
              placeholder: 'e.g. Morning Mist Over Green Peaks',
            },
            {
              name: 'message',
              type: 'textarea',
              label: 'Message',
              required: true,
              placeholder: 'How can we help?',
            },
          ],
          submit_label: 'Send Inquiry',
        },
      ],
    },
    {
      slug: '/checkout',
      title: 'Checkout',
      page_type: 'checkout',
      show_in_nav: false,
      nav_label: 'Checkout',
      nav_order: 9,
      blocks: [
        {
          id: 'checkout-block',
          _type: 'checkout',
          heading: 'Checkout',
          continue_shopping_url: '/gallery',
        },
      ],
    },
  ],

  theme: {
    // Museum aesthetic: warm gallery-white walls, near-black ink, a single
    // restrained seal-red accent. Flat (no radius/shadow) so artwork sits on the
    // wall, not in a UI card. Hairlines are warm, not cold grey.
    colors: {
      primary: '#8a1c1c',
      secondary: '#6f6a62',
      accent: '#8a1c1c',
      background: '#f5f3ee',
      surface: '#faf8f3',
      text: '#26221d',
      heading: '#15120e',
      neutral: { '200': '#e4ddd0' },
    },
    fonts: {
      heading: 'Noto Serif SC, Georgia, serif',
      body: 'Noto Sans SC, system-ui, sans-serif',
    },
    radius: 'none',
    shadow: 'none',
    spacing: 'relaxed',
  },

  config: {
    title: 'Xiang Jiang Gallery',
    description:
      'A fine-art gallery: original ink, oil, and calligraphy from represented artists, available to browse and purchase online.',
  },

  nav: {
    logo_text: 'Xiang Jiang Gallery',
    style: 'minimal',
  },

  footer: {
    copyright: '2026 Xiang Jiang Gallery',
    links: [
      { label: 'The Collection', url: '/gallery' },
      { label: 'Artists', url: '/artists' },
      { label: 'Inquire', url: '/contact' },
    ],
  },

  admin_views: [
    {
      entity_slug: 'product',
      label: 'Artworks',
      icon: 'P',
      layout: 'cards',
      sort_order: 0,
      config: { image_field: 'image', title_field: 'name', subtitle_field: 'artist' },
    },
    {
      entity_slug: 'artist',
      label: 'Artists',
      icon: 'A',
      layout: 'cards',
      sort_order: 1,
      config: { image_field: 'photo', title_field: 'name', subtitle_field: 'specialty' },
    },
    {
      entity_slug: 'category',
      label: 'Genres',
      icon: 'G',
      layout: 'cards',
      sort_order: 2,
      config: { image_field: 'image', title_field: 'name', subtitle_field: 'description' },
    },
    {
      entity_slug: 'order',
      label: 'Orders',
      icon: '$',
      layout: 'table',
      sort_order: 3,
      config: { columns: ['customer_name', 'customer_email', 'item_count', 'total', 'status'] },
    },
    {
      entity_slug: 'inquiry',
      label: 'Inquiries',
      icon: '✉',
      layout: 'table',
      sort_order: 4,
      config: { columns: ['name', 'email', 'artwork', 'message'] },
    },
  ],
};
