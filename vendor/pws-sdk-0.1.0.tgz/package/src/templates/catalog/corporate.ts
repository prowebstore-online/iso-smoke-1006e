import type { TemplateBundle } from '@pws/shared';

const PERSON_IDS = {
  ceo: 'c2000000-0000-0000-0000-000000000001',
  cto: 'c2000000-0000-0000-0000-000000000002',
  coo: 'c2000000-0000-0000-0000-000000000003',
  head_sales: 'c2000000-0000-0000-0000-000000000004',
  head_marketing: 'c2000000-0000-0000-0000-000000000005',
};

export const corporateTemplate: TemplateBundle = {
  slug: 'corporate',
  name: 'Corporate / Organization',
  description:
    'Multi-page corporate website with deep hierarchical navigation, team directory, service pages, case studies, blog, careers, press releases, and contact forms. For companies, agencies, NGOs, and institutions.',
  icon: 'O',
  verticals: [
    'corporate',
    'agency',
    'NGO',
    'institution',
    'foundation',
    'association',
    'government',
  ],
  combines_with: ['blog', 'professional', 'ecommerce'],

  schemas: [
    {
      slug: 'team_member',
      name: 'Team Member',
      name_plural: 'Team',
      icon: 'T',
      fields: [
        { slug: 'name', name: 'Name', type: 'text', required: true },
        { slug: 'title', name: 'Job Title', type: 'text', required: true },
        { slug: 'photo', name: 'Photo', type: 'image' },
        { slug: 'bio', name: 'Bio', type: 'richtext' },
        {
          slug: 'department',
          name: 'Department',
          type: 'select',
          options: [
            'Leadership',
            'Engineering',
            'Sales',
            'Marketing',
            'Operations',
            'Finance',
            'HR',
          ],
        },
        { slug: 'email', name: 'Email', type: 'email' },
        { slug: 'linkedin', name: 'LinkedIn', type: 'url' },
        { slug: 'sort_order', name: 'Sort Order', type: 'number', default: 0 },
      ],
    },
    {
      slug: 'service',
      name: 'Service',
      name_plural: 'Services',
      icon: 'S',
      fields: [
        { slug: 'name', name: 'Name', type: 'text', required: true },
        { slug: 'description', name: 'Description', type: 'richtext', required: true },
        { slug: 'icon', name: 'Icon', type: 'text' },
        { slug: 'image', name: 'Image', type: 'image' },
        {
          slug: 'category',
          name: 'Category',
          type: 'select',
          options: ['Consulting', 'Training', 'Support', 'Development', 'Strategy'],
        },
        { slug: 'featured', name: 'Featured', type: 'boolean', default: false },
      ],
    },
    {
      slug: 'case_study',
      name: 'Case Study',
      name_plural: 'Case Studies',
      icon: 'C',
      fields: [
        { slug: 'title', name: 'Title', type: 'text', required: true },
        { slug: 'client', name: 'Client', type: 'text', required: true },
        { slug: 'industry', name: 'Industry', type: 'text' },
        { slug: 'image', name: 'Cover Image', type: 'image' },
        { slug: 'challenge', name: 'Challenge', type: 'richtext' },
        { slug: 'solution', name: 'Solution', type: 'richtext' },
        { slug: 'results', name: 'Results', type: 'richtext' },
        { slug: 'year', name: 'Year', type: 'number' },
        { slug: 'service', name: 'Service', type: 'reference', reference_to: 'service' },
        { slug: 'testimonial', name: 'Client Quote', type: 'text' },
        { slug: 'testimonial_author', name: 'Quote Author', type: 'text' },
      ],
    },
    {
      slug: 'blog_post',
      name: 'Blog Post',
      name_plural: 'Blog Posts',
      icon: 'B',
      fields: [
        { slug: 'title', name: 'Title', type: 'text', required: true },
        { slug: 'body', name: 'Body', type: 'richtext', required: true },
        { slug: 'date', name: 'Date', type: 'date', required: true },
        { slug: 'image', name: 'Cover Image', type: 'image' },
        { slug: 'author', name: 'Author', type: 'reference', reference_to: 'team_member' },
        { slug: 'excerpt', name: 'Excerpt', type: 'text' },
        {
          slug: 'category',
          name: 'Category',
          type: 'select',
          options: ['Industry Insights', 'Company News', 'How-To', 'Case Study', 'Opinion'],
        },
      ],
    },
    {
      slug: 'press_release',
      name: 'Press Release',
      name_plural: 'Press Releases',
      icon: 'P',
      fields: [
        { slug: 'title', name: 'Headline', type: 'text', required: true },
        { slug: 'date', name: 'Date', type: 'date', required: true },
        { slug: 'body', name: 'Body', type: 'richtext', required: true },
        {
          slug: 'category',
          name: 'Category',
          type: 'select',
          options: ['Product Launch', 'Partnership', 'Award', 'Funding', 'Leadership', 'Event'],
        },
        { slug: 'pdf_url', name: 'PDF Download', type: 'url' },
      ],
    },
    {
      slug: 'job_opening',
      name: 'Job Opening',
      name_plural: 'Job Openings',
      icon: 'J',
      fields: [
        { slug: 'title', name: 'Title', type: 'text', required: true },
        { slug: 'department', name: 'Department', type: 'text', required: true },
        { slug: 'location', name: 'Location', type: 'text', required: true },
        {
          slug: 'type',
          name: 'Type',
          type: 'select',
          options: ['Full-time', 'Part-time', 'Contract', 'Internship'],
        },
        { slug: 'description', name: 'Description', type: 'richtext', required: true },
        { slug: 'requirements', name: 'Requirements', type: 'richtext' },
        { slug: 'salary_range', name: 'Salary Range', type: 'text' },
        { slug: 'open', name: 'Open', type: 'boolean', default: true },
      ],
    },
    {
      slug: 'contact_inquiry',
      name: 'Contact Inquiry',
      name_plural: 'Contact Inquiries',
      icon: 'Q',
      public_writable: true,
      fields: [
        { slug: 'name', name: 'Name', type: 'text', required: true },
        { slug: 'email', name: 'Email', type: 'email', required: true },
        { slug: 'company', name: 'Company', type: 'text' },
        { slug: 'phone', name: 'Phone', type: 'phone' },
        {
          slug: 'subject',
          name: 'Subject',
          type: 'select',
          options: ['General Inquiry', 'Partnership', 'Sales', 'Support', 'Press', 'Careers'],
        },
        { slug: 'message', name: 'Message', type: 'text', required: true },
      ],
    },
    {
      slug: 'job_application',
      name: 'Job Application',
      name_plural: 'Job Applications',
      icon: 'A',
      public_writable: true,
      fields: [
        { slug: 'name', name: 'Name', type: 'text', required: true },
        { slug: 'email', name: 'Email', type: 'email', required: true },
        { slug: 'phone', name: 'Phone', type: 'phone' },
        { slug: 'position', name: 'Position Applied For', type: 'text', required: true },
        { slug: 'linkedin', name: 'LinkedIn URL', type: 'url' },
        { slug: 'cover_letter', name: 'Cover Letter', type: 'text', required: true },
      ],
    },
  ],

  records: {
    team_member: [
      {
        name: 'Sarah Chen',
        title: 'Chief Executive Officer',
        department: 'Leadership',
        bio: '<p>Sarah founded the company in 2018 after 15 years at McKinsey. She leads our strategic vision and client relationships, with a focus on making enterprise-grade solutions accessible to mid-market companies.</p>',
        sort_order: 1,
      },
      {
        name: 'James Okafor',
        title: 'Chief Technology Officer',
        department: 'Leadership',
        bio: '<p>James brings two decades of engineering leadership from AWS and Stripe. He oversees our product architecture and engineering team, driving our platform toward enterprise reliability with startup agility.</p>',
        sort_order: 2,
      },
      {
        name: 'Maria Rodriguez',
        title: 'Chief Operating Officer',
        department: 'Leadership',
        bio: '<p>Maria joined from Bain & Company where she specialized in operational transformation. She ensures our internal operations match the quality we deliver to clients.</p>',
        sort_order: 3,
      },
      {
        name: 'David Kim',
        title: 'Head of Sales',
        department: 'Sales',
        bio: '<p>David leads our sales organization across North America and Europe. Previously VP Sales at HubSpot, he focuses on consultative selling and long-term client partnerships.</p>',
        sort_order: 4,
      },
      {
        name: 'Priya Patel',
        title: 'Head of Marketing',
        department: 'Marketing',
        bio: '<p>Priya runs our brand, content, and demand generation. Former CMO of two YC-backed startups, she brings a data-driven approach to B2B marketing.</p>',
        sort_order: 5,
      },
    ],
    service: [
      {
        name: 'Strategy Consulting',
        description:
          '<p>We work with leadership teams to define their digital strategy, identify opportunities, and build roadmaps that connect technology investments to business outcomes.</p><p>Engagements typically run 6-12 weeks and include stakeholder interviews, competitive analysis, and a prioritized implementation plan.</p>',
        category: 'Consulting',
        featured: true,
      },
      {
        name: 'Platform Development',
        description:
          '<p>Custom platform development for companies that have outgrown off-the-shelf solutions. We build scalable, maintainable systems using modern cloud architecture.</p><p>Our engineering teams embed with yours — same standups, same Slack channels, same codebase standards.</p>',
        category: 'Development',
        featured: true,
      },
      {
        name: 'Training & Enablement',
        description:
          '<p>Upskill your team on modern practices. We run workshops on cloud architecture, DevOps, product management, and data-driven decision making.</p><p>Programs range from 2-day intensives to 12-week embedded coaching engagements.</p>',
        category: 'Training',
        featured: true,
      },
    ],
    case_study: [
      {
        title: 'Digital Transformation for Nordic Insurance',
        client: 'Nordic Insurance Group',
        industry: 'Insurance',
        year: 2025,
        challenge:
          '<p>Nordic Insurance was processing claims through a 15-year-old mainframe system. Average claim resolution took 22 days. Customer satisfaction was declining, and the company was losing market share to digital-native competitors.</p>',
        solution:
          '<p>We designed and built a cloud-native claims platform that automated 70% of routine claims while routing complex cases to specialist adjusters with full context. The system integrated with their existing policy database via event-driven architecture.</p>',
        results:
          '<p>Average claim resolution dropped from 22 days to 4. Customer satisfaction increased 35%. The company recaptured 8% market share within 18 months of launch.</p>',
        testimonial:
          'They understood our business before they wrote a line of code. That made all the difference.',
        testimonial_author: 'Erik Lindqvist, COO, Nordic Insurance Group',
        service: PERSON_IDS.ceo, // Will reference service once created
      },
    ],
    blog_post: [
      {
        title: 'Why Most Digital Transformations Fail (And How to Avoid It)',
        date: '2026-06-01',
        excerpt:
          'The pattern is predictable: big vision, big budget, big consulting firm, big failure. Here is what actually works.',
        category: 'Industry Insights',
        body: '<p>The pattern is predictable: a company announces a digital transformation initiative, hires a big consulting firm, spends millions on new technology, and two years later has nothing to show for it.</p><p>We have seen this play out dozens of times. The root cause is almost always the same: the transformation was technology-led instead of outcome-led.</p><h2>Start with the outcome</h2><p>Before selecting any technology, answer one question: what business outcome would justify this investment? Not "modernize our stack" — that is an activity, not an outcome. Something measurable: reduce claim resolution from 22 days to 5. Increase self-service from 15% to 60%.</p><h2>Go narrow before going wide</h2><p>Pick one process, one team, one customer segment. Prove the model works there before scaling. This is counterintuitive for enterprise leaders who want to "transform everything at once," but it is the only approach that consistently works.</p>',
        author: PERSON_IDS.ceo,
      },
      {
        title: 'Joining the Team: Our Engineering Culture',
        date: '2026-05-15',
        excerpt: 'What it is actually like to work here — from the CTO.',
        category: 'Company News',
        body: '<p>People ask me what makes our engineering culture different. The honest answer: we are not trying to be different. We are trying to be correct.</p><p>We write tests. We review code. We document decisions. We deploy frequently. We own our services. None of this is revolutionary — it is just disciplined.</p><h2>What we look for</h2><p>Technical skill matters, but we optimize for two things: judgment and communication. Can you make good tradeoffs under uncertainty? Can you explain your reasoning to someone who disagrees?</p>',
        author: PERSON_IDS.cto,
      },
    ],
    press_release: [
      {
        title: 'Company Raises $25M Series B to Expand Enterprise Platform',
        date: '2026-04-10',
        category: 'Funding',
        body: '<p><strong>SAN FRANCISCO</strong> — The company today announced a $25 million Series B round led by Accel, with participation from existing investors Sequoia and First Round Capital.</p><p>The funding will be used to expand the enterprise platform, grow the engineering team, and open a European office. The company has grown revenue 3x year-over-year and now serves over 200 enterprise clients.</p><p>"Enterprise companies need partners who can move at startup speed without startup risk," said Sarah Chen, CEO. "This funding lets us scale our team while maintaining the quality that earned our clients\' trust."</p>',
      },
    ],
    job_opening: [
      {
        title: 'Senior Software Engineer',
        department: 'Engineering',
        location: 'San Francisco / Remote',
        type: 'Full-time',
        description:
          '<p>We are looking for senior engineers who want to build enterprise-grade platforms with startup-speed iteration. You will work directly with clients, own services end-to-end, and ship to production daily.</p>',
        requirements:
          '<p>5+ years of experience with TypeScript, distributed systems, and cloud platforms (AWS/GCP/CF). Strong opinions about testing, code review, and documentation. Experience with event-driven architecture is a plus.</p>',
        salary_range: '$180K-$220K + equity',
        open: true,
      },
      {
        title: 'Product Designer',
        department: 'Engineering',
        location: 'San Francisco / Remote',
        type: 'Full-time',
        description:
          '<p>Design enterprise software that people actually enjoy using. You will own the full design process from research through implementation review, working embedded with engineering teams.</p>',
        requirements:
          '<p>4+ years of product design experience, preferably B2B/SaaS. Strong systems thinking. Comfortable with Figma, prototyping, and front-end code review. Portfolio required.</p>',
        salary_range: '$160K-$200K + equity',
        open: true,
      },
    ],
  },

  // ── Pages: hierarchical navigation ──────────────────────────────────────
  // Nested slugs like /about/team create dropdown menus automatically.
  pages: [
    // ── Home ──
    {
      slug: '/',
      title: 'Home',
      page_type: 'home',
      show_in_nav: false,
      nav_order: 0,
      blocks: [
        {
          id: 'home-hero',
          _type: 'hero',
          heading: 'We help companies build what matters',
          subheading:
            'Strategy consulting, platform development, and team enablement for companies that take technology seriously.',
          cta_text: 'Our Services',
          cta_url: '/services',
          cta2_text: 'Get in Touch',
          cta2_url: '/contact',
          alignment: 'left',
        },
        {
          id: 'home-services',
          _type: 'entity_grid',
          heading: 'What We Do',
          entity: 'service',
          filter: { featured: true },
          display_fields: ['name', 'description', 'category'],
          layout: 'cards',
          columns: 3,
        },
        {
          id: 'home-stats',
          _type: 'features',
          heading: 'By the Numbers',
          items: [
            { title: '200+', description: 'Enterprise clients across 15 countries' },
            { title: '95%', description: 'Client retention rate over 5 years' },
            { title: '4 days', description: 'Average claims resolution (down from 22)' },
            { title: '$2.1B', description: 'Client revenue influenced by our work' },
          ],
        },
        {
          id: 'home-testimonial',
          _type: 'testimonials',
          items: [
            {
              quote:
                'They understood our business before they wrote a line of code. That made all the difference.',
              author: 'Erik Lindqvist',
              role: 'COO, Nordic Insurance Group',
            },
          ],
        },
        {
          id: 'home-blog',
          _type: 'entity_grid',
          heading: 'Latest Insights',
          entity: 'blog_post',
          sort: { field: 'date', dir: 'desc' },
          limit: 3,
          display_fields: ['title', 'date', 'excerpt', 'category'],
          layout: 'cards',
          columns: 3,
        },
        {
          id: 'home-cta',
          _type: 'cta',
          heading: 'Ready to start?',
          text: 'Tell us about your challenge. We respond within one business day.',
          cta_text: 'Contact Us',
          cta_url: '/contact',
        },
      ],
    },

    // ── About (parent) ──
    {
      slug: '/about',
      title: 'About',
      page_type: 'about',
      show_in_nav: true,
      nav_label: 'About',
      nav_order: 1,
      blocks: [
        {
          id: 'about-hero',
          _type: 'hero',
          heading: 'About Us',
          subheading:
            'Founded in 2018 to bridge the gap between enterprise ambition and execution. We are 85 people across San Francisco, London, and Singapore.',
          alignment: 'left',
        },
        {
          id: 'about-story',
          _type: 'richtext',
          body: '<h2>Our Story</h2><p>We started with a simple observation: most digital transformation projects fail not because of technology, but because of misalignment between business goals and technical execution. The big consultancies understood business but outsourced engineering. The dev shops understood code but not context.</p><p>We built a company that does both — strategy and execution, under one roof, with senior people on every engagement. No bait-and-switch staffing, no offshore handoffs, no 200-page decks that gather dust.</p><h2>Our Approach</h2><p>Every engagement starts with outcomes, not technology. We work backward from what success looks like for your business, then build the shortest path to get there. We embed with your team, not replace them. And we measure everything — time to value, adoption rates, business impact — because vanity metrics help nobody.</p>',
        },
      ],
    },

    // ── About > Team ──
    {
      slug: '/about/team',
      title: 'Team',
      page_type: 'team',
      show_in_nav: true,
      nav_label: 'Team',
      nav_order: 2,
      blocks: [
        {
          id: 'team-hero',
          _type: 'hero',
          heading: 'Our Team',
          subheading: '85 people. No juniors on client work. Everyone ships.',
          alignment: 'left',
        },
        {
          id: 'team-leadership',
          _type: 'entity_grid',
          heading: 'Leadership',
          entity: 'team_member',
          filter: { department: 'Leadership' },
          display_fields: ['name', 'title', 'photo', 'bio'],
          layout: 'cards',
          columns: 3,
        },
      ],
    },

    // ── About > Careers ──
    {
      slug: '/about/careers',
      title: 'Careers',
      page_type: 'careers',
      show_in_nav: true,
      nav_label: 'Careers',
      nav_order: 3,
      blocks: [
        {
          id: 'careers-hero',
          _type: 'hero',
          heading: 'Careers',
          subheading:
            'Build enterprise platforms with startup energy. Remote-first, senior-heavy, no bureaucracy.',
          alignment: 'left',
        },
        {
          id: 'careers-openings',
          _type: 'entity_grid',
          heading: 'Open Positions',
          entity: 'job_opening',
          filter: { open: true },
          display_fields: ['title', 'department', 'location', 'type', 'salary_range'],
          layout: 'cards',
          columns: 2,
        },
        {
          id: 'careers-form',
          _type: 'form',
          heading: 'General Application',
          description:
            "Don't see a fit? Send us your details and we'll reach out when something opens.",
          entity_slug: 'job_application',
          fields: [
            { name: 'name', type: 'text', label: 'Name', required: true },
            { name: 'email', type: 'email', label: 'Email', required: true },
            { name: 'phone', type: 'text', label: 'Phone' },
            { name: 'position', type: 'text', label: 'Position of Interest', required: true },
            { name: 'linkedin', type: 'text', label: 'LinkedIn URL' },
            {
              name: 'cover_letter',
              type: 'textarea',
              label: 'Tell us about yourself',
              required: true,
              placeholder: 'What are you great at? What do you want to work on?',
            },
          ],
          submit_label: 'Submit Application',
        },
      ],
    },

    // ── About > Press ──
    {
      slug: '/about/press',
      title: 'Press',
      page_type: 'press',
      show_in_nav: true,
      nav_label: 'Press',
      nav_order: 4,
      blocks: [
        {
          id: 'press-hero',
          _type: 'hero',
          heading: 'Press & News',
          subheading: 'For media inquiries, contact press@example.com.',
          alignment: 'left',
        },
        {
          id: 'press-releases',
          _type: 'entity_grid',
          entity: 'press_release',
          sort: { field: 'date', dir: 'desc' },
          display_fields: ['title', 'date', 'category'],
          layout: 'cards',
          columns: 2,
        },
      ],
    },

    // ── Services (parent) ──
    {
      slug: '/services',
      title: 'Services',
      page_type: 'services',
      show_in_nav: true,
      nav_label: 'Services',
      nav_order: 5,
      blocks: [
        {
          id: 'services-hero',
          _type: 'hero',
          heading: 'Services',
          subheading: 'Strategy, development, and enablement — from diagnosis to deployment.',
          alignment: 'left',
        },
        {
          id: 'services-grid',
          _type: 'entity_grid',
          entity: 'service',
          display_fields: ['name', 'description', 'category', 'image'],
          layout: 'cards',
          columns: 2,
        },
      ],
    },

    // ── Services > Consulting ──
    {
      slug: '/services/consulting',
      title: 'Consulting',
      page_type: 'service-detail',
      show_in_nav: true,
      nav_label: 'Consulting',
      nav_order: 6,
      blocks: [
        {
          id: 'consulting-hero',
          _type: 'hero',
          heading: 'Strategy Consulting',
          subheading: 'Define the right problem before building the right solution.',
          alignment: 'left',
        },
        {
          id: 'consulting-body',
          _type: 'richtext',
          body: '<h2>How It Works</h2><p>Every consulting engagement starts with discovery: 2-3 weeks of stakeholder interviews, data analysis, and competitive review. We map your current state, define target outcomes, and build a prioritized roadmap.</p><h2>What You Get</h2><p>A clear strategy document with measurable goals, a phased implementation plan, technology recommendations grounded in your reality (not vendor preferences), and executive alignment on priorities and tradeoffs.</p><h2>Typical Engagements</h2><p>Digital strategy definition (6 weeks), technology due diligence for M&A (3-4 weeks), organizational readiness assessment (4 weeks), vendor selection and architecture review (4-6 weeks).</p>',
        },
        {
          id: 'consulting-cta',
          _type: 'cta',
          heading: 'Start a conversation',
          text: 'Tell us about your challenge and we will scope an engagement.',
          cta_text: 'Contact Us',
          cta_url: '/contact',
        },
      ],
    },

    // ── Services > Development ──
    {
      slug: '/services/development',
      title: 'Development',
      page_type: 'service-detail',
      show_in_nav: true,
      nav_label: 'Development',
      nav_order: 7,
      blocks: [
        {
          id: 'dev-hero',
          _type: 'hero',
          heading: 'Platform Development',
          subheading: 'Custom platforms built by senior engineers who embed with your team.',
          alignment: 'left',
        },
        {
          id: 'dev-body',
          _type: 'richtext',
          body: '<h2>Our Approach</h2><p>We do not throw code over a wall. Our engineers join your standups, your Slack, your codebase. They pair with your team, write tests, review PRs, and transfer knowledge continuously — not in a "handoff" at the end.</p><h2>Technology</h2><p>We are opinionated about architecture (event-driven, API-first, cloud-native) and flexible about language and framework. TypeScript, Go, Python, Rust — we choose what fits the problem, not what is trending.</p><h2>What We Build</h2><p>Claims processing platforms, customer portals, data pipelines, internal tools, API gateways, real-time systems. If it needs to be reliable, scalable, and maintainable — that is our sweet spot.</p>',
        },
      ],
    },

    // ── Services > Training ──
    {
      slug: '/services/training',
      title: 'Training',
      page_type: 'service-detail',
      show_in_nav: true,
      nav_label: 'Training',
      nav_order: 8,
      blocks: [
        {
          id: 'training-hero',
          _type: 'hero',
          heading: 'Training & Enablement',
          subheading: 'Upskill your team on modern practices that stick.',
          alignment: 'left',
        },
        {
          id: 'training-body',
          _type: 'richtext',
          body: '<h2>Programs</h2><p><strong>2-Day Intensives:</strong> Cloud architecture, DevOps fundamentals, product management, data-driven decision making. Hands-on, workshop-style, with your real systems.</p><p><strong>Embedded Coaching (12 weeks):</strong> Our senior engineers and PMs embed with your teams, working on real projects while teaching modern practices. Pairing, code review, architecture guidance.</p><p><strong>Leadership Workshops:</strong> For CTOs and VPs — technology strategy, team structure, build-vs-buy decisions, vendor management. Half-day or full-day formats.</p>',
        },
      ],
    },

    // ── Resources (parent) ──
    {
      slug: '/resources',
      title: 'Resources',
      page_type: 'resources',
      show_in_nav: true,
      nav_label: 'Resources',
      nav_order: 9,
      blocks: [
        {
          id: 'resources-hero',
          _type: 'hero',
          heading: 'Resources',
          subheading: 'Insights, case studies, and practical guides from our team.',
          alignment: 'left',
        },
        {
          id: 'resources-latest',
          _type: 'entity_grid',
          heading: 'Latest Posts',
          entity: 'blog_post',
          sort: { field: 'date', dir: 'desc' },
          limit: 6,
          display_fields: ['title', 'date', 'excerpt', 'category', 'image'],
          layout: 'cards',
          columns: 3,
        },
      ],
    },

    // ── Resources > Blog ──
    {
      slug: '/resources/blog',
      title: 'Blog',
      page_type: 'blog',
      show_in_nav: true,
      nav_label: 'Blog',
      nav_order: 10,
      blocks: [
        {
          id: 'blog-hero',
          _type: 'hero',
          heading: 'Blog',
          alignment: 'left',
        },
        {
          id: 'blog-list',
          _type: 'entity_grid',
          entity: 'blog_post',
          sort: { field: 'date', dir: 'desc' },
          display_fields: ['title', 'date', 'excerpt', 'category', 'image'],
          layout: 'cards',
          columns: 2,
        },
      ],
    },

    // ── Resources > Case Studies ──
    {
      slug: '/resources/case-studies',
      title: 'Case Studies',
      page_type: 'case-studies',
      show_in_nav: true,
      nav_label: 'Case Studies',
      nav_order: 11,
      blocks: [
        {
          id: 'cases-hero',
          _type: 'hero',
          heading: 'Case Studies',
          subheading: 'How we helped our clients solve hard problems.',
          alignment: 'left',
        },
        {
          id: 'cases-grid',
          _type: 'entity_grid',
          entity: 'case_study',
          sort: { field: 'year', dir: 'desc' },
          display_fields: ['title', 'client', 'industry', 'image'],
          layout: 'cards',
          columns: 2,
        },
      ],
    },

    // ── Contact ──
    {
      slug: '/contact',
      title: 'Contact',
      page_type: 'contact',
      show_in_nav: true,
      nav_label: 'Contact',
      nav_order: 12,
      blocks: [
        {
          id: 'contact-hero',
          _type: 'hero',
          heading: 'Get in Touch',
          subheading: 'Tell us about your challenge. We respond within one business day.',
          alignment: 'left',
        },
        {
          id: 'contact-form',
          _type: 'form',
          heading: 'Contact Us',
          entity_slug: 'contact_inquiry',
          fields: [
            { name: 'name', type: 'text', label: 'Name', required: true },
            { name: 'email', type: 'email', label: 'Email', required: true },
            { name: 'company', type: 'text', label: 'Company' },
            { name: 'phone', type: 'text', label: 'Phone' },
            {
              name: 'subject',
              type: 'select',
              label: 'Subject',
              options: ['General Inquiry', 'Partnership', 'Sales', 'Support', 'Press', 'Careers'],
            },
            {
              name: 'message',
              type: 'textarea',
              label: 'Message',
              required: true,
              placeholder: 'Tell us about your project, challenge, or question.',
            },
          ],
          submit_label: 'Send Message',
        },
        {
          id: 'contact-info',
          _type: 'richtext',
          body: '<h3>Offices</h3><p><strong>San Francisco</strong> (HQ)<br/>100 Market Street, Suite 400<br/>San Francisco, CA 94105</p><p><strong>London</strong><br/>1 Finsbury Avenue<br/>London EC2M 2PF</p><p><strong>Singapore</strong><br/>One Raffles Place, Tower 2<br/>Singapore 048616</p><h3>Email</h3><p>General: hello@example.com<br/>Sales: sales@example.com<br/>Press: press@example.com</p>',
        },
      ],
    },
  ],

  theme: {
    colors: {
      primary: '#1e3a5f',
      secondary: '#4a6fa5',
      accent: '#2563eb',
      background: '#ffffff',
      surface: '#f8fafc',
      text: '#334155',
      heading: '#0f172a',
    },
    fonts: {
      heading: 'Inter, system-ui, sans-serif',
      body: 'Inter, system-ui, sans-serif',
    },
    radius: 'md',
    shadow: 'sm',
    spacing: 'normal',
  },

  config: {
    title: 'Apex Partners',
    description:
      'Strategy consulting, platform development, and team enablement for companies that take technology seriously.',
  },

  nav: {
    logo_text: 'Apex Partners',
    style: 'standard',
    breadcrumbs: true,
  },

  footer: {
    copyright: '2026 Apex Partners',
    links: [
      { label: 'LinkedIn', url: 'https://linkedin.com' },
      { label: 'GitHub', url: 'https://github.com' },
      { label: 'Careers', url: '/about/careers' },
      { label: 'Contact', url: '/contact' },
    ],
  },

  admin_views: [
    {
      entity_slug: 'team_member',
      label: 'Team',
      icon: 'T',
      layout: 'cards',
      sort_order: 0,
      config: { image_field: 'photo', title_field: 'name', subtitle_field: 'title' },
    },
    {
      entity_slug: 'service',
      label: 'Services',
      icon: 'S',
      layout: 'cards',
      sort_order: 1,
      config: { title_field: 'name', subtitle_field: 'category' },
    },
    {
      entity_slug: 'case_study',
      label: 'Case Studies',
      icon: 'C',
      layout: 'cards',
      sort_order: 2,
      config: { image_field: 'image', title_field: 'title', subtitle_field: 'client' },
    },
    {
      entity_slug: 'blog_post',
      label: 'Blog',
      icon: 'B',
      layout: 'table',
      sort_order: 3,
      config: { columns: ['title', 'date', 'category'] },
    },
    {
      entity_slug: 'press_release',
      label: 'Press',
      icon: 'P',
      layout: 'table',
      sort_order: 4,
      config: { columns: ['title', 'date', 'category'] },
    },
    {
      entity_slug: 'job_opening',
      label: 'Careers',
      icon: 'J',
      layout: 'table',
      sort_order: 5,
      config: { columns: ['title', 'department', 'location', 'type', 'open'] },
    },
    {
      entity_slug: 'contact_inquiry',
      label: 'Inquiries',
      icon: 'Q',
      layout: 'table',
      sort_order: 6,
      config: { columns: ['name', 'email', 'subject', 'company'] },
    },
    {
      entity_slug: 'job_application',
      label: 'Applications',
      icon: 'A',
      layout: 'table',
      sort_order: 7,
      config: { columns: ['name', 'email', 'position'] },
    },
  ],
};
