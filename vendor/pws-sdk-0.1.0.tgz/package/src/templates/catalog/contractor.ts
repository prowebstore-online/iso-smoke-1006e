import type { TemplateBundle } from '@pws/shared';

const SERVICE_IDS = {
  kitchen: 'h0000000-0000-0000-0000-000000000001',
  bathroom: 'h0000000-0000-0000-0000-000000000002',
  addition: 'h0000000-0000-0000-0000-000000000003',
  deck: 'h0000000-0000-0000-0000-000000000004',
};

export const contractorTemplate: TemplateBundle = {
  slug: 'contractor',
  name: 'Contractor / Trades',
  description:
    'Home service business with services, project gallery, testimonials, and free estimate request. For contractors, plumbers, electricians, landscapers, and trades.',
  icon: 'T',
  verticals: ['contractor', 'plumber', 'electrician', 'HVAC', 'landscaper', 'roofer', 'painter'],
  combines_with: ['blog', 'ecommerce'],

  schemas: [
    {
      slug: 'service',
      name: 'Service',
      name_plural: 'Services',
      icon: 'S',
      fields: [
        { slug: 'name', name: 'Name', type: 'text', required: true },
        { slug: 'description', name: 'Description', type: 'richtext', required: true },
        { slug: 'image', name: 'Image', type: 'image' },
        { slug: 'starting_price', name: 'Starting Price', type: 'number' },
        {
          slug: 'includes',
          name: 'Includes',
          type: 'multiselect',
          options: [
            'Free Estimate',
            'Design Consultation',
            'Permit Handling',
            '3D Rendering',
            'Warranty',
            'Cleanup',
          ],
        },
      ],
    },
    {
      slug: 'project',
      name: 'Project',
      name_plural: 'Projects',
      icon: 'J',
      fields: [
        { slug: 'title', name: 'Title', type: 'text', required: true },
        { slug: 'description', name: 'Description', type: 'richtext' },
        { slug: 'image', name: 'Main Photo', type: 'image', required: true },
        { slug: 'before_image', name: 'Before Photo', type: 'image' },
        {
          slug: 'category',
          name: 'Category',
          type: 'select',
          options: [
            'Kitchen',
            'Bathroom',
            'Addition',
            'Deck & Outdoor',
            'Whole Home',
            'Commercial',
          ],
        },
        { slug: 'location', name: 'Location', type: 'text' },
        { slug: 'service', name: 'Service', type: 'reference', reference_to: 'service' },
        { slug: 'duration', name: 'Project Duration', type: 'text' },
        { slug: 'year', name: 'Year', type: 'number' },
        { slug: 'client_testimonial', name: 'Client Quote', type: 'text' },
        { slug: 'client_name', name: 'Client Name', type: 'text' },
      ],
    },
    {
      slug: 'person',
      name: 'Team Member',
      name_plural: 'Team',
      icon: 'P',
      fields: [
        { slug: 'name', name: 'Name', type: 'text', required: true },
        { slug: 'role', name: 'Role', type: 'text', required: true },
        { slug: 'photo', name: 'Photo', type: 'image' },
        {
          slug: 'certifications',
          name: 'Certifications',
          type: 'multiselect',
          options: [
            'Licensed General Contractor',
            'EPA Lead-Safe',
            'OSHA 30',
            'Master Electrician',
            'Master Plumber',
            'NARI Certified',
          ],
        },
        { slug: 'bio', name: 'Bio', type: 'richtext' },
      ],
    },
    {
      slug: 'estimate_request',
      name: 'Estimate Request',
      name_plural: 'Estimate Requests',
      icon: 'E',
      public_writable: true,
      fields: [
        { slug: 'name', name: 'Name', type: 'text', required: true },
        { slug: 'email', name: 'Email', type: 'email', required: true },
        { slug: 'phone', name: 'Phone', type: 'phone', required: true },
        { slug: 'address', name: 'Property Address', type: 'text', required: true },
        {
          slug: 'service_type',
          name: 'Service Type',
          type: 'select',
          options: [
            'Kitchen Remodel',
            'Bathroom Remodel',
            'Addition',
            'Deck & Outdoor',
            'Whole Home',
            'Other',
          ],
        },
        { slug: 'description', name: 'Describe Your Project', type: 'text', required: true },
        {
          slug: 'timeline',
          name: 'Desired Timeline',
          type: 'select',
          options: ['ASAP', '1-3 months', '3-6 months', '6-12 months', 'Just planning'],
        },
        {
          slug: 'budget',
          name: 'Budget Range',
          type: 'select',
          options: ['Under $25k', '$25k-$50k', '$50k-$100k', '$100k-$200k', '$200k+', 'Not sure'],
        },
      ],
    },
  ],

  records: {
    service: [
      {
        name: 'Kitchen Remodels',
        description:
          '<h2>The Heart of the Home, Done Right</h2><p>From galley refreshes to full gut renovations, we design and build kitchens that work as hard as you do. Custom cabinetry, stone countertops, professional-grade appliances — all installed by our in-house crew.</p><h3>Our Process</h3><ul><li>Free on-site consultation and measurements</li><li>3D design rendering so you see it before we build it</li><li>All permits, inspections, and code compliance handled</li><li>Typical timeline: 6-10 weeks from permit to punch list</li></ul>',
        starting_price: 4500000,
        includes: [
          'Free Estimate',
          'Design Consultation',
          '3D Rendering',
          'Permit Handling',
          'Warranty',
          'Cleanup',
        ],
      },
      {
        name: 'Bathroom Remodels',
        description:
          '<h2>Small Space, Big Impact</h2><p>Bathrooms punch above their weight in ROI and daily quality of life. We handle everything — waterproofing, tile, plumbing, electrical, ventilation, and fixtures — so you deal with one team, not five subcontractors.</p><h3>Popular Upgrades</h3><ul><li>Walk-in showers with linear drains</li><li>Heated floors (radiant, electric)</li><li>Custom vanities and storage</li><li>Freestanding tubs</li></ul>',
        starting_price: 2500000,
        includes: [
          'Free Estimate',
          'Design Consultation',
          'Permit Handling',
          'Warranty',
          'Cleanup',
        ],
      },
      {
        name: 'Home Additions',
        description:
          '<h2>More Space Without Moving</h2><p>Need a bedroom, home office, or in-law suite? We design additions that look like they were always part of the house — matching rooflines, siding, and architectural details. Full structural engineering included.</p>',
        starting_price: 8000000,
        includes: [
          'Free Estimate',
          'Design Consultation',
          '3D Rendering',
          'Permit Handling',
          'Warranty',
          'Cleanup',
        ],
      },
      {
        name: 'Decks & Outdoor Living',
        description:
          '<h2>Bring the Inside Out</h2><p>Composite decks, cedar pergolas, outdoor kitchens, and fire pits. We build outdoor spaces that extend your living area year-round (yes, even in the Pacific Northwest — covered structures are our specialty).</p>',
        starting_price: 1500000,
        includes: [
          'Free Estimate',
          'Design Consultation',
          'Permit Handling',
          'Warranty',
          'Cleanup',
        ],
      },
    ],
    project: [
      {
        title: 'Modern Farmhouse Kitchen',
        description:
          '<p>Complete gut renovation of a 1960s kitchen. Removed a load-bearing wall to open the space to the dining room, installed custom white oak cabinets, quartzite counters, and a 48" range. The island seats five.</p>',
        category: 'Kitchen',
        location: 'Lake Oswego, OR',
        service: SERVICE_IDS.kitchen,
        duration: '8 weeks',
        year: 2026,
        client_testimonial:
          'We cook together as a family now. The old kitchen was too cramped for two people, let alone four. Cascade made it happen on time and on budget.',
        client_name: 'The Patterson Family',
      },
      {
        title: 'Spa Bathroom Suite',
        description:
          '<p>Master bathroom renovation: removed the dated jetted tub, added a walk-in shower with floor-to-ceiling marble tile, heated floors, and a freestanding soaking tub by the window. Custom double vanity with undermount sinks.</p>',
        category: 'Bathroom',
        location: 'NW Portland, OR',
        service: SERVICE_IDS.bathroom,
        duration: '5 weeks',
        year: 2026,
        client_testimonial:
          "It feels like a hotel, but it's our home. The heated floors alone were worth the renovation.",
        client_name: 'David & Kim Chen',
      },
      {
        title: 'Second-Story Addition',
        description:
          '<p>Added 600 sqft above the existing garage: a primary bedroom suite with walk-in closet and full bathroom. Matched the existing craftsman roofline perfectly. Includes a private balcony overlooking the backyard.</p>',
        category: 'Addition',
        location: 'Sellwood, Portland, OR',
        service: SERVICE_IDS.addition,
        duration: '14 weeks',
        year: 2025,
        client_testimonial:
          "Our neighbors thought we'd always had a second story. That's the best compliment a contractor can get.",
        client_name: 'Maria Gonzalez',
      },
      {
        title: 'Covered Outdoor Kitchen & Deck',
        description:
          '<p>1,200 sqft composite deck with a covered outdoor kitchen area — built-in grill, mini fridge, bar seating, and a wood-fired pizza oven. Cedar pergola with retractable shade. Wired for audio and lighting.</p>',
        category: 'Deck & Outdoor',
        location: 'West Linn, OR',
        service: SERVICE_IDS.deck,
        duration: '6 weeks',
        year: 2025,
        client_testimonial:
          "We basically live outside from May to October now. Best investment we've made in the house.",
        client_name: 'The Nguyen Family',
      },
    ],
    person: [
      {
        name: 'Matt Caldwell',
        role: 'Owner & Lead Contractor',
        certifications: [
          'Licensed General Contractor',
          'EPA Lead-Safe',
          'OSHA 30',
          'NARI Certified',
        ],
        bio: '<p>Matt founded Cascade in 2014 after 12 years working for large residential builders. He got tired of the "build cheap, build fast" mentality and started a company focused on craftsmanship. He\'s personally overseen 200+ projects in the Portland metro area.</p>',
      },
      {
        name: 'Angela Reeves',
        role: 'Design & Client Relations',
        certifications: ['NARI Certified'],
        bio: '<p>Angela is your first point of contact. She handles design consultations, 3D renderings, material selection, and manages the project timeline. Before Cascade, she was an interior designer with 8 years of residential experience.</p>',
      },
      {
        name: 'Carlos Mendez',
        role: 'Site Foreman',
        certifications: ['Licensed General Contractor', 'OSHA 30', 'Master Electrician'],
        bio: '<p>Carlos runs the crew on-site. 20 years of hands-on experience in framing, electrical, and finish carpentry. He holds a master electrician license, which means we handle electrical in-house instead of subbing it out.</p>',
      },
    ],
  },

  pages: [
    {
      slug: '/',
      title: 'Home',
      page_type: 'home',
      show_in_nav: true,
      nav_label: 'Home',
      nav_order: 0,
      blocks: [
        {
          id: 'home-hero',
          _type: 'hero',
          heading: 'Remodeling done right, on time, on budget',
          subheading:
            "Portland's trusted residential contractor since 2014. Kitchens, bathrooms, additions, and outdoor living — one crew, one point of contact, no surprises.",
          cta_text: 'Get a Free Estimate',
          cta_url: '/contact',
          cta2_text: 'See Our Work',
          cta2_url: '/projects',
          alignment: 'left',
        },
        {
          id: 'home-services',
          _type: 'entity_grid',
          heading: 'What We Do',
          entity: 'service',
          display_fields: ['name', 'description', 'image', 'starting_price'],
          layout: 'cards',
          columns: 2,
        },
        {
          id: 'home-stats',
          _type: 'features',
          heading: 'Why Cascade',
          items: [
            { title: '200+', description: 'Projects completed in the Portland metro area' },
            { title: '12 years', description: 'In business, same ownership, same crew' },
            { title: '4.9 stars', description: 'Average rating across Google and Houzz' },
            { title: '5 year', description: 'Warranty on all workmanship' },
          ],
        },
        {
          id: 'home-testimonials',
          _type: 'testimonials',
          heading: 'What Clients Say',
          items: [
            {
              quote:
                'We cook together as a family now. Cascade made it happen on time and on budget.',
              author: 'The Pattersons',
              role: 'Kitchen Remodel, Lake Oswego',
              rating: 5,
            },
            {
              quote:
                "Our neighbors thought we'd always had a second story. That's the best compliment a contractor can get.",
              author: 'Maria Gonzalez',
              role: 'Addition, Sellwood',
              rating: 5,
            },
            {
              quote: "Best investment we've made in the house. We basically live outside now.",
              author: 'The Nguyens',
              role: 'Deck & Outdoor Kitchen, West Linn',
              rating: 5,
            },
          ],
        },
        {
          id: 'home-cta',
          _type: 'cta',
          heading: 'Ready to start your project?',
          text: 'Free on-site estimates. No pressure, no sales pitch — just honest advice on scope, timeline, and budget.',
          cta_text: 'Get a Free Estimate',
          cta_url: '/contact',
        },
      ],
    },
    {
      slug: '/services',
      title: 'Services',
      page_type: 'services',
      show_in_nav: true,
      nav_label: 'Services',
      nav_order: 1,
      blocks: [
        {
          id: 'services-hero',
          _type: 'hero',
          heading: 'Our Services',
          subheading:
            'Full-service residential remodeling. Design, permits, construction, and cleanup — all handled by one team.',
          alignment: 'left',
        },
        {
          id: 'services-grid',
          _type: 'entity_grid',
          entity: 'service',
          display_fields: ['name', 'description', 'image', 'starting_price', 'includes'],
          layout: 'cards',
          columns: 1,
        },
      ],
    },
    {
      slug: '/projects',
      title: 'Projects',
      page_type: 'portfolio',
      show_in_nav: true,
      nav_label: 'Projects',
      nav_order: 2,
      blocks: [
        {
          id: 'projects-hero',
          _type: 'hero',
          heading: 'Our Work',
          subheading:
            'Recent projects from the Portland metro area. Every project shown was managed by our in-house crew.',
          alignment: 'left',
        },
        {
          id: 'projects-grid',
          _type: 'entity_grid',
          entity: 'project',
          display_fields: [
            'title',
            'category',
            'location',
            'image',
            'duration',
            'year',
            'client_testimonial',
            'client_name',
          ],
          layout: 'cards',
          columns: 2,
        },
      ],
    },
    {
      slug: '/about',
      title: 'About',
      page_type: 'about',
      show_in_nav: true,
      nav_label: 'About',
      nav_order: 3,
      blocks: [
        {
          id: 'about-hero',
          _type: 'hero',
          heading: 'About Cascade',
          alignment: 'left',
        },
        {
          id: 'about-story',
          _type: 'richtext',
          body: "<h2>Built on Craftsmanship</h2><p>Matt Caldwell started Cascade Building Co. in 2014 with a simple thesis: homeowners deserve a contractor who shows up when they say they will, communicates clearly, and takes pride in the details. After 12 years working for large production builders, he'd seen enough corners cut.</p><p>Today we're a team of 12 — carpenters, an electrician, a designer, and a project manager. We keep everything in-house so we control quality at every stage. No revolving door of subcontractors, no \"we're waiting on the other guy.\"</p><h2>Our Process</h2><p><strong>1. Consultation (free)</strong> — We visit your home, listen to what you want, take measurements, and give you an honest assessment of scope and budget range.</p><p><strong>2. Design & Proposal</strong> — Angela creates a detailed design with 3D renderings. You see exactly what you're getting before we start. The proposal is fixed-price, not an estimate that creeps.</p><p><strong>3. Build</strong> — Carlos and the crew take over. You get weekly progress updates with photos. We clean up every day — you can live in your home during the project.</p><p><strong>4. Punch List & Warranty</strong> — We walk through together, fix anything that isn't perfect, and hand you a 5-year workmanship warranty.</p>",
        },
        {
          id: 'about-team',
          _type: 'entity_grid',
          heading: 'The Team',
          entity: 'person',
          display_fields: ['name', 'role', 'bio', 'photo', 'certifications'],
          layout: 'cards',
          columns: 3,
        },
      ],
    },
    {
      slug: '/contact',
      title: 'Contact',
      page_type: 'contact',
      show_in_nav: true,
      nav_label: 'Free Estimate',
      nav_order: 4,
      blocks: [
        {
          id: 'contact-hero',
          _type: 'hero',
          heading: 'Get a Free Estimate',
          subheading:
            "Tell us about your project and we'll schedule an on-site visit. No pressure, no obligation.",
          alignment: 'left',
        },
        {
          id: 'contact-form',
          _type: 'form',
          heading: 'Estimate Request',
          description:
            'We respond within 1 business day and schedule the on-site visit within a week.',
          entity_slug: 'estimate_request',
          fields: [
            { name: 'name', type: 'text', label: 'Your Name', required: true },
            { name: 'email', type: 'email', label: 'Email', required: true },
            { name: 'phone', type: 'tel', label: 'Phone', required: true },
            {
              name: 'address',
              type: 'text',
              label: 'Property Address',
              required: true,
              placeholder: '123 Main St, Portland, OR',
            },
            {
              name: 'service_type',
              type: 'select',
              label: 'What kind of project?',
              options: [
                'Kitchen Remodel',
                'Bathroom Remodel',
                'Addition',
                'Deck & Outdoor',
                'Whole Home',
                'Other',
              ],
            },
            {
              name: 'description',
              type: 'textarea',
              label: 'Tell us about your project',
              required: true,
              placeholder:
                'What are you looking to do? Any specific goals, concerns, or constraints?',
            },
            {
              name: 'timeline',
              type: 'select',
              label: 'When do you want to start?',
              options: ['ASAP', '1-3 months', '3-6 months', '6-12 months', 'Just planning'],
            },
            {
              name: 'budget',
              type: 'select',
              label: 'Budget Range',
              options: [
                'Under $25k',
                '$25k-$50k',
                '$50k-$100k',
                '$100k-$200k',
                '$200k+',
                'Not sure',
              ],
            },
          ],
          submit_label: 'Request Free Estimate',
        },
        {
          id: 'contact-info',
          _type: 'features',
          heading: 'Other Ways to Reach Us',
          items: [
            { title: 'Phone', description: '(503) 555-0234' },
            { title: 'Email', description: 'hello@cascadebuilding.com' },
            { title: 'Office', description: '4200 SE Division St, Portland, OR 97202' },
          ],
        },
      ],
    },
  ],

  theme: {
    colors: {
      primary: '#1b4332',
      secondary: '#40916c',
      accent: '#d4a373',
      background: '#ffffff',
      surface: '#f5f5f0',
      text: '#2d3436',
      heading: '#1a1a1a',
    },
    fonts: {
      heading: 'Inter, system-ui, sans-serif',
      body: 'Inter, system-ui, sans-serif',
    },
    radius: 'sm',
    shadow: 'sm',
    spacing: 'normal',
  },

  config: {
    title: 'Cascade Building Co.',
    description:
      "Portland's trusted residential contractor. Kitchens, bathrooms, additions, and outdoor living.",
  },

  nav: {
    logo_text: 'Cascade',
    style: 'standard',
  },

  footer: {
    copyright: '2026 Cascade Building Co. | CCB# 201847',
    links: [
      { label: 'Google Reviews', url: 'https://google.com' },
      { label: 'Houzz', url: 'https://houzz.com' },
      { label: 'Instagram', url: 'https://instagram.com' },
    ],
  },

  admin_views: [
    {
      entity_slug: 'project',
      label: 'Projects',
      icon: 'J',
      layout: 'cards',
      sort_order: 0,
      config: { image_field: 'image', title_field: 'title', subtitle_field: 'category' },
    },
    {
      entity_slug: 'service',
      label: 'Services',
      icon: 'S',
      layout: 'table',
      sort_order: 1,
      config: { columns: ['name', 'starting_price', 'includes'] },
    },
    {
      entity_slug: 'person',
      label: 'Team',
      icon: 'P',
      layout: 'cards',
      sort_order: 2,
      config: { image_field: 'photo', title_field: 'name', subtitle_field: 'role' },
    },
    {
      entity_slug: 'estimate_request',
      label: 'Estimates',
      icon: '✉',
      layout: 'table',
      sort_order: 3,
      config: { columns: ['name', 'email', 'phone', 'service_interest', 'timeline'] },
    },
  ],
};
