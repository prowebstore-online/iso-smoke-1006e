import type { TemplateBundle } from '@pws/shared';

const PERSON_IDS = {
  rachel: 'e0000000-0000-0000-0000-000000000001',
  michael: 'e0000000-0000-0000-0000-000000000002',
  aisha: 'e0000000-0000-0000-0000-000000000003',
};

export const professionalTemplate: TemplateBundle = {
  slug: 'professional',
  name: 'Professional Services',
  description:
    'Service-based business with team profiles, case studies, testimonials, and consultation request form. For law firms, consultancies, agencies, and advisors.',
  icon: 'S',
  verticals: [
    'law firm',
    'consulting',
    'agency',
    'accounting',
    'architecture',
    'financial advisor',
  ],
  combines_with: ['blog', 'portfolio', 'events'],

  schemas: [
    {
      slug: 'service',
      name: 'Service',
      name_plural: 'Services',
      icon: 'S',
      fields: [
        { slug: 'title', name: 'Title', type: 'text', required: true },
        { slug: 'description', name: 'Description', type: 'richtext', required: true },
        { slug: 'icon', name: 'Icon', type: 'text' },
        { slug: 'image', name: 'Image', type: 'image' },
        { slug: 'price', name: 'Starting Price', type: 'number' },
        { slug: 'price_unit', name: 'Price Unit', type: 'text' },
        {
          slug: 'features',
          name: 'Includes',
          type: 'multiselect',
          options: [
            'Strategy',
            'Implementation',
            'Training',
            'Ongoing Support',
            'Documentation',
            'Workshops',
            'Audits',
            'Reporting',
          ],
        },
      ],
    },
    {
      slug: 'case_study',
      name: 'Case Study',
      name_plural: 'Case Studies',
      icon: 'K',
      fields: [
        { slug: 'title', name: 'Title', type: 'text', required: true },
        { slug: 'client', name: 'Client', type: 'text', required: true },
        { slug: 'industry', name: 'Industry', type: 'text' },
        { slug: 'image', name: 'Cover Image', type: 'image' },
        { slug: 'challenge', name: 'Challenge', type: 'richtext', required: true },
        { slug: 'solution', name: 'Solution', type: 'richtext', required: true },
        { slug: 'results', name: 'Results', type: 'text', required: true },
        { slug: 'lead', name: 'Project Lead', type: 'reference', reference_to: 'person' },
        { slug: 'testimonial_quote', name: 'Client Quote', type: 'text' },
        { slug: 'testimonial_author', name: 'Quote Author', type: 'text' },
      ],
    },
    {
      slug: 'person',
      name: 'Team Member',
      name_plural: 'Team',
      icon: 'P',
      fields: [
        { slug: 'name', name: 'Name', type: 'text', required: true },
        { slug: 'title', name: 'Title', type: 'text', required: true },
        { slug: 'photo', name: 'Photo', type: 'image' },
        { slug: 'bio', name: 'Bio', type: 'richtext' },
        {
          slug: 'specialties',
          name: 'Specialties',
          type: 'multiselect',
          options: [
            'Growth Strategy',
            'Operations',
            'M&A',
            'Digital Transformation',
            'Go-to-Market',
            'Org Design',
            'Pricing',
            'Due Diligence',
          ],
        },
        { slug: 'linkedin', name: 'LinkedIn', type: 'url' },
      ],
    },
    {
      slug: 'consultation_request',
      name: 'Consultation Request',
      name_plural: 'Consultation Requests',
      icon: 'Q',
      public_writable: true,
      fields: [
        { slug: 'name', name: 'Name', type: 'text', required: true },
        { slug: 'email', name: 'Email', type: 'email', required: true },
        { slug: 'company', name: 'Company', type: 'text', required: true },
        { slug: 'phone', name: 'Phone', type: 'phone' },
        {
          slug: 'service_interest',
          name: 'Service Interest',
          type: 'select',
          options: [
            'Growth Strategy',
            'Operations',
            'M&A Advisory',
            'Digital Transformation',
            'Not Sure Yet',
          ],
        },
        {
          slug: 'company_size',
          name: 'Company Size',
          type: 'select',
          options: ['1-10', '11-50', '51-200', '201-1000', '1000+'],
        },
        { slug: 'message', name: 'How Can We Help?', type: 'text', required: true },
      ],
    },
  ],

  records: {
    person: [
      {
        name: 'Rachel Torres',
        title: 'Managing Partner',
        bio: "<p>Rachel founded Altitude in 2018 after 15 years at McKinsey, where she was a partner in the growth practice. She works primarily with Series B-D technology companies navigating the transition from startup to scale-up.</p><p>She's advised over 40 companies through their growth inflection points, with a specialty in go-to-market strategy and organizational design.</p>",
        specialties: ['Growth Strategy', 'Go-to-Market', 'Org Design'],
      },
      {
        name: 'Michael Park',
        title: 'Partner, Operations',
        bio: "<p>Michael spent a decade as COO at two high-growth SaaS companies (one acquired by Salesforce, one IPO) before joining Altitude. He brings operator experience to consulting — every recommendation he makes, he's implemented himself.</p><p>His focus areas are operational efficiency, pricing strategy, and post-merger integration.</p>",
        specialties: ['Operations', 'Pricing', 'M&A'],
      },
      {
        name: 'Aisha Patel',
        title: 'Principal',
        bio: "<p>Aisha leads Altitude's digital transformation practice. Previously she was VP of Product at a Fortune 500 retailer, where she led a $200M technology modernization. She understands both the strategic and technical dimensions of transformation work.</p>",
        specialties: ['Digital Transformation', 'Due Diligence', 'Growth Strategy'],
      },
    ],
    service: [
      {
        title: 'Growth Strategy',
        description:
          "<h2>Accelerate What's Working</h2><p>We help technology companies identify their highest-leverage growth opportunities and build the go-to-market engine to capture them. This isn't strategy on a slide deck — it's a 90-day plan with named owners and measurable milestones.</p><h3>What's Included</h3><ul><li>Market sizing and segmentation analysis</li><li>Competitive positioning workshop</li><li>Go-to-market playbook with channel strategy</li><li>Pricing architecture review</li><li>90-day execution roadmap</li></ul>",
        icon: 'G',
        features: ['Strategy', 'Workshops', 'Documentation', 'Reporting'],
      },
      {
        title: 'Operational Excellence',
        description:
          "<h2>Scale Without Breaking</h2><p>Growth exposes every crack in your operations. We help companies redesign their operating model — processes, tools, team structure, and metrics — so they can 3x headcount without 3x chaos.</p><h3>What's Included</h3><ul><li>Operating model assessment</li><li>Process mapping and optimization</li><li>KPI framework design</li><li>Team structure and role clarity</li><li>Implementation support (12 weeks)</li></ul>",
        icon: 'O',
        features: ['Strategy', 'Implementation', 'Training', 'Ongoing Support'],
      },
      {
        title: 'M&A Advisory',
        description:
          "<h2>Acquisitions That Actually Work</h2><p>70% of acquisitions fail to create value. We help companies on both sides of the table — buy-side due diligence for acquirers, and exit preparation for founders — with a focus on post-merger integration planning.</p><h3>What's Included</h3><ul><li>Strategic rationale validation</li><li>Operational due diligence</li><li>Integration planning and execution</li><li>Cultural alignment assessment</li><li>First 100 days roadmap</li></ul>",
        icon: 'M',
        features: ['Strategy', 'Due Diligence', 'Documentation', 'Implementation'],
      },
      {
        title: 'Digital Transformation',
        description:
          "<h2>Modernize With Purpose</h2><p>Digital transformation isn't about technology — it's about capability. We help companies understand which capabilities they need, which technology enables them, and how to build organizational readiness for the change.</p><h3>What's Included</h3><ul><li>Capability maturity assessment</li><li>Technology landscape evaluation</li><li>Transformation roadmap</li><li>Change management strategy</li><li>Vendor selection support</li></ul>",
        icon: 'D',
        features: ['Strategy', 'Audits', 'Documentation', 'Workshops'],
      },
    ],
    case_study: [
      {
        title: 'Scaling Revenue 4x Without Scaling Headcount',
        client: 'Relay (Series C SaaS)',
        industry: 'Developer Tools',
        challenge:
          '<p>Relay had strong product-market fit but was growing linearly — every $1M in new ARR required 3 new sales hires. The GTM motion was high-touch, high-cost, and unscalable. They needed to reach $40M ARR with the team they had.</p>',
        solution:
          "<p>We redesigned Relay's GTM from the ground up. Key moves: (1) identified a self-serve motion for their mid-market segment that required zero sales touches, (2) rebuilt pricing to encourage annual contracts with built-in expansion, (3) created a partner channel that generated 30% of pipeline within 6 months.</p>",
        results: '$12M to $48M ARR in 18 months with only 4 additional hires',
        lead: PERSON_IDS.rachel,
        testimonial_quote:
          "Altitude didn't give us a strategy deck — they gave us an engine. The self-serve motion alone changed the economics of our business.",
        testimonial_author: 'James Chen, CEO, Relay',
      },
      {
        title: 'Post-Merger Integration for a 400-Person Acquisition',
        client: 'NovaTech (Public Company)',
        industry: 'Enterprise Software',
        challenge:
          "<p>NovaTech acquired a 400-person company to expand into a new vertical. The cultures were different, the tech stacks were incompatible, and the acquired company's best people were already interviewing elsewhere. NovaTech had 100 days to prove the acquisition wasn't a mistake.</p>",
        solution:
          '<p>We ran a structured 100-day integration: (1) cultural alignment workshops with both leadership teams in week 1, (2) identified 12 "quick win" integration points that showed progress without requiring full platform merges, (3) designed a retention package that kept 94% of the acquired team through the first year.</p>',
        results: '94% talent retention, $18M in synergies realized within 12 months',
        lead: PERSON_IDS.michael,
        testimonial_quote:
          'The integration could have gone very badly. Altitude kept both teams focused on what mattered and prevented the political dynamics that kill most mergers.',
        testimonial_author: 'Sarah Kim, COO, NovaTech',
      },
      {
        title: 'From Legacy to Cloud in 18 Months',
        client: 'Pacific Mutual Insurance',
        industry: 'Insurance',
        challenge:
          '<p>Pacific Mutual was running critical policy and claims systems on 20-year-old on-premise infrastructure. Every quarter, an outage would cost $2-5M. They had tried twice before to modernize and failed both times — once with a Big Four firm, once internally.</p>',
        solution:
          "<p>Unlike previous attempts that tried to rebuild everything at once, we took a strangler fig approach: (1) identified the 5 highest-risk legacy systems, (2) designed cloud-native replacements that could run in parallel, (3) migrated traffic gradually with automated rollback. We also embedded a change management lead to handle the human side — the team's previous failures had created deep skepticism.</p>",
        results: 'Zero unplanned outages in 12 months, 60% reduction in infrastructure costs',
        lead: PERSON_IDS.aisha,
        testimonial_quote:
          "The third time was the charm. Altitude understood that our problem wasn't technical — it was organizational. They solved both.",
        testimonial_author: 'David Okafor, CTO, Pacific Mutual',
      },
    ],
  },

  pages: [
    {
      slug: '/',
      title: 'Home',
      page_type: 'home',
      show_in_nav: true,
      nav_label: 'Home',
      nav_order: 0,
      blocks: [
        {
          id: 'home-hero',
          _type: 'hero',
          heading: 'Strategy consulting for technology companies',
          subheading:
            'We help growth-stage and enterprise technology companies solve their hardest strategic and operational problems. No frameworks — just results.',
          cta_text: 'Our Services',
          cta_url: '/services',
          cta2_text: 'Talk to Us',
          cta2_url: '/contact',
          alignment: 'left',
        },
        {
          id: 'home-services',
          _type: 'entity_grid',
          heading: 'What We Do',
          entity: 'service',
          display_fields: ['title', 'description', 'icon'],
          layout: 'cards',
          columns: 2,
        },
        {
          id: 'home-stats',
          _type: 'features',
          heading: 'Track Record',
          items: [
            { title: '40+', description: 'Companies advised through growth inflection points' },
            { title: '$2.8B', description: 'Combined client revenue influenced' },
            { title: '94%', description: 'Client retention rate year-over-year' },
            { title: '18mo', description: 'Average engagement duration' },
          ],
        },
        {
          id: 'home-testimonials',
          _type: 'testimonials',
          heading: 'Client Results',
          items: [
            {
              quote: "Altitude didn't give us a strategy deck — they gave us an engine.",
              author: 'James Chen',
              role: 'CEO, Relay',
            },
            {
              quote:
                'The integration could have gone very badly. Altitude kept both teams focused on what mattered.',
              author: 'Sarah Kim',
              role: 'COO, NovaTech',
            },
            {
              quote: "They understood that our problem wasn't technical — it was organizational.",
              author: 'David Okafor',
              role: 'CTO, Pacific Mutual',
            },
          ],
        },
        {
          id: 'home-cta',
          _type: 'cta',
          heading: 'Ready to talk?',
          text: "We take on 6-8 engagements at a time. Tell us about your challenge and we'll schedule an initial conversation.",
          cta_text: 'Schedule a Consultation',
          cta_url: '/contact',
        },
      ],
    },
    {
      slug: '/services',
      title: 'Services',
      page_type: 'services',
      show_in_nav: true,
      nav_label: 'Services',
      nav_order: 1,
      blocks: [
        {
          id: 'services-hero',
          _type: 'hero',
          heading: 'Our Services',
          subheading: 'Four practice areas, one goal: make your company meaningfully better.',
          alignment: 'left',
        },
        {
          id: 'services-grid',
          _type: 'entity_grid',
          entity: 'service',
          display_fields: ['title', 'description', 'icon', 'features'],
          layout: 'cards',
          columns: 1,
        },
      ],
    },
    {
      slug: '/work',
      title: 'Case Studies',
      page_type: 'case_studies',
      show_in_nav: true,
      nav_label: 'Work',
      nav_order: 2,
      blocks: [
        {
          id: 'work-hero',
          _type: 'hero',
          heading: 'Case Studies',
          subheading: 'Real results from real engagements. Names used with permission.',
          alignment: 'left',
        },
        {
          id: 'work-grid',
          _type: 'entity_grid',
          entity: 'case_study',
          display_fields: ['title', 'client', 'industry', 'results', 'image'],
          layout: 'cards',
          columns: 1,
        },
      ],
    },
    {
      slug: '/team',
      title: 'Team',
      page_type: 'team',
      show_in_nav: true,
      nav_label: 'Team',
      nav_order: 3,
      blocks: [
        {
          id: 'team-hero',
          _type: 'hero',
          heading: 'Our Team',
          subheading:
            'Senior practitioners, not junior analysts. Every person on your engagement has done the work themselves.',
          alignment: 'left',
        },
        {
          id: 'team-grid',
          _type: 'entity_grid',
          entity: 'person',
          display_fields: ['name', 'title', 'bio', 'photo', 'specialties'],
          layout: 'cards',
          columns: 3,
        },
      ],
    },
    {
      slug: '/about',
      title: 'About',
      page_type: 'about',
      show_in_nav: true,
      nav_label: 'About',
      nav_order: 4,
      blocks: [
        {
          id: 'about-hero',
          _type: 'hero',
          heading: 'About Altitude',
          alignment: 'left',
        },
        {
          id: 'about-story',
          _type: 'richtext',
          body: "<h2>Why We Exist</h2><p>The consulting industry has a credibility problem. Too many firms sell strategy and deliver slide decks. Their consultants are smart, analytical, and have never run anything.</p><p>Altitude is different. Every person on our team has been an operator — a CEO, COO, VP, or founder who has built, scaled, and sometimes broken things in the real world. We consult because we're good at pattern-matching across companies, not because we couldn't cut it in operations.</p><h2>How We Work</h2><p><strong>Small teams, senior people.</strong> Your engagement is staffed by 2-3 people, all of whom have 10+ years of operating experience. No leverage model, no army of analysts.</p><p><strong>Fixed scope, clear outcomes.</strong> Every engagement starts with a defined outcome and timeline. We don't do open-ended retainers that drift into dependency.</p><p><strong>Operator-tested.</strong> Every recommendation we make, someone on our team has implemented in a real company. We don't recommend things we haven't done.</p>",
        },
        {
          id: 'about-values',
          _type: 'features',
          heading: 'Our Values',
          items: [
            {
              title: 'Outcomes Over Output',
              description:
                'We measure ourselves by what changed in your business, not by the volume of deliverables.',
            },
            {
              title: 'Candor Over Comfort',
              description:
                "We'll tell you what you need to hear, not what you want to hear. That's what you're paying for.",
            },
            {
              title: 'Simplicity Over Sophistication',
              description:
                'The best strategies fit on one page. If it needs a 100-slide deck, it needs more thinking.',
            },
          ],
        },
      ],
    },
    {
      slug: '/contact',
      title: 'Contact',
      page_type: 'contact',
      show_in_nav: true,
      nav_label: 'Contact',
      nav_order: 5,
      blocks: [
        {
          id: 'contact-hero',
          _type: 'hero',
          heading: 'Start a Conversation',
          subheading:
            "Tell us about your challenge. We'll respond within 48 hours with an honest assessment of whether we can help.",
          alignment: 'left',
        },
        {
          id: 'contact-form',
          _type: 'form',
          heading: 'Consultation Request',
          entity_slug: 'consultation_request',
          fields: [
            { name: 'name', type: 'text', label: 'Your Name', required: true },
            { name: 'email', type: 'email', label: 'Work Email', required: true },
            { name: 'company', type: 'text', label: 'Company', required: true },
            { name: 'phone', type: 'tel', label: 'Phone' },
            {
              name: 'service_interest',
              type: 'select',
              label: 'Area of Interest',
              options: [
                'Growth Strategy',
                'Operations',
                'M&A Advisory',
                'Digital Transformation',
                'Not Sure Yet',
              ],
            },
            {
              name: 'company_size',
              type: 'select',
              label: 'Company Size',
              options: ['1-10', '11-50', '51-200', '201-1000', '1000+'],
            },
            {
              name: 'message',
              type: 'textarea',
              label: 'How Can We Help?',
              required: true,
              placeholder: 'Describe your challenge and what a good outcome would look like.',
            },
          ],
          submit_label: 'Request Consultation',
        },
      ],
    },
  ],

  theme: {
    colors: {
      primary: '#1e3a5f',
      secondary: '#4a7c9e',
      accent: '#c7923e',
      background: '#ffffff',
      surface: '#f4f6f9',
      text: '#2d3748',
      heading: '#1a202c',
    },
    fonts: {
      heading: 'Inter, system-ui, sans-serif',
      body: 'Inter, system-ui, sans-serif',
    },
    radius: 'sm',
    shadow: 'sm',
    spacing: 'normal',
  },

  config: {
    title: 'Altitude Consulting',
    description:
      'Strategy consulting for technology companies. Growth strategy, operations, M&A, and digital transformation.',
  },

  nav: {
    logo_text: 'Altitude',
    style: 'standard',
  },

  footer: {
    copyright: '2026 Altitude Consulting LLC',
    links: [{ label: 'LinkedIn', url: 'https://linkedin.com' }],
  },

  admin_views: [
    {
      entity_slug: 'case_study',
      label: 'Case Studies',
      icon: 'K',
      layout: 'cards',
      sort_order: 0,
      config: { image_field: 'image', title_field: 'title', subtitle_field: 'client' },
    },
    {
      entity_slug: 'service',
      label: 'Services',
      icon: 'S',
      layout: 'table',
      sort_order: 1,
      config: { columns: ['title', 'price', 'price_unit'] },
    },
    {
      entity_slug: 'person',
      label: 'Team',
      icon: 'P',
      layout: 'cards',
      sort_order: 2,
      config: { image_field: 'photo', title_field: 'name', subtitle_field: 'title' },
    },
    {
      entity_slug: 'consultation_request',
      label: 'Consultations',
      icon: '✉',
      layout: 'table',
      sort_order: 3,
      config: { columns: ['name', 'email', 'company', 'service_interest'] },
    },
  ],
};
