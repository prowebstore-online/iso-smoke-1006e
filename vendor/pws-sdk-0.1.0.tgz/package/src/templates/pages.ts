// Page recipe builders — common page layouts that templates compose from.
// Each returns a page definition ready for a TemplateBundle's pages array.

import type { TemplatePageDef } from '@pws/shared';
import { cta, grid, hero, richtext } from './helpers.ts';

type PageOpts = { nav_order: number; show_in_nav?: boolean };

/** Home page shell — hero + any custom blocks. */
export const homePage = (
  heroHeading: string,
  heroSub: string,
  blocks: unknown[],
  opts: PageOpts & { cta1?: [string, string]; cta2?: [string, string] },
): TemplatePageDef => ({
  slug: '/',
  title: 'Home',
  page_type: 'home',
  show_in_nav: opts.show_in_nav ?? true,
  nav_label: 'Home',
  nav_order: opts.nav_order,
  blocks: [
    hero('home-hero', heroHeading, heroSub, {
      alignment: 'center',
      ...(opts.cta1 ? { cta_text: opts.cta1[0], cta_url: opts.cta1[1] } : {}),
      ...(opts.cta2 ? { cta2_text: opts.cta2[0], cta2_url: opts.cta2[1] } : {}),
    }),
    ...blocks,
  ] as TemplatePageDef['blocks'],
});

/** Entity list page — hero + entity_grid. */
export const listPage = (
  slug: string,
  title: string,
  entitySlug: string,
  fields: string[],
  opts: PageOpts & {
    heroSub?: string;
    sort?: { field: string; dir: 'asc' | 'desc' };
    columns?: number;
    filter?: Record<string, unknown>;
  },
): TemplatePageDef => ({
  slug,
  title,
  page_type: title.toLowerCase().replace(/\s+/g, '_'),
  show_in_nav: opts.show_in_nav ?? true,
  nav_label: title,
  nav_order: opts.nav_order,
  blocks: [
    hero(`${entitySlug}-hero`, title, opts.heroSub),
    grid(`${entitySlug}-list`, entitySlug, fields, {
      ...(opts.sort ? { sort: opts.sort } : {}),
      ...(opts.columns ? { columns: opts.columns } : {}),
      ...(opts.filter ? { filter: opts.filter } : {}),
    }),
  ] as TemplatePageDef['blocks'],
});

/** About page — hero + richtext story + optional entity grids. */
export const aboutPage = (
  storyHtml: string,
  entityGrids: unknown[],
  opts: PageOpts,
): TemplatePageDef => ({
  slug: '/about',
  title: 'About',
  page_type: 'about',
  show_in_nav: opts.show_in_nav ?? true,
  nav_label: 'About',
  nav_order: opts.nav_order,
  blocks: [
    hero('about-hero', 'About'),
    richtext('about-story', storyHtml),
    ...entityGrids,
  ] as TemplatePageDef['blocks'],
});

/** Contact / visit page — hero + info features + form. */
export const contactPage = (
  title: string,
  slug: string,
  heroSub: string,
  infoItems: Array<{ title: string; description: string }>,
  formConfig: {
    heading: string;
    description: string;
    entity_slug: string;
    fields: unknown[];
    submit_label: string;
  },
  opts: PageOpts,
): TemplatePageDef => ({
  slug,
  title,
  page_type: 'contact',
  show_in_nav: opts.show_in_nav ?? true,
  nav_label: title,
  nav_order: opts.nav_order,
  blocks: [
    hero('contact-hero', title, heroSub),
    { id: 'contact-info', _type: 'features' as const, heading: 'Info', items: infoItems },
    { id: 'contact-form', _type: 'form' as const, ...formConfig },
  ] as TemplatePageDef['blocks'],
});

/** Form-only page — hero + form block. */
export const formPage = (
  slug: string,
  title: string,
  heroSub: string,
  formConfig: {
    heading: string;
    description: string;
    entity_slug: string;
    fields: unknown[];
    submit_label: string;
  },
  opts: PageOpts & { extraBlocks?: unknown[] },
): TemplatePageDef => ({
  slug,
  title,
  page_type: title.toLowerCase().replace(/\s+/g, '_'),
  show_in_nav: opts.show_in_nav ?? false,
  nav_label: title,
  nav_order: opts.nav_order,
  blocks: [
    hero(`${title.toLowerCase().replace(/\s+/g, '-')}-hero`, title, heroSub),
    ...(opts.extraBlocks ?? []),
    {
      id: `${title.toLowerCase().replace(/\s+/g, '-')}-form`,
      _type: 'form' as const,
      ...formConfig,
    },
  ] as TemplatePageDef['blocks'],
});

/** Giving / donate page — hero + richtext + funds grid. */
export const givingPage = (infoHtml: string, opts: PageOpts): TemplatePageDef => ({
  slug: '/give',
  title: 'Give',
  page_type: 'give',
  show_in_nav: opts.show_in_nav ?? true,
  nav_label: 'Give',
  nav_order: opts.nav_order,
  blocks: [
    hero('give-hero', 'Give', 'Your generosity changes lives.', { alignment: 'center' }),
    richtext('give-info', infoHtml),
    grid('give-funds', 'donation_fund', ['name', 'description', 'category'], {
      heading: 'Giving Funds',
      filter: { active: true },
      columns: 3,
    }),
  ] as TemplatePageDef['blocks'],
});

/** Live stream page — hero + embed placeholder + sermon archive CTA. */
export const livePage = (schedule: string, opts: PageOpts): TemplatePageDef => ({
  slug: '/live',
  title: 'Watch Live',
  page_type: 'live',
  show_in_nav: opts.show_in_nav ?? false,
  nav_label: 'Watch Live',
  nav_order: opts.nav_order,
  blocks: [
    hero('live-hero', 'Watch Live', `Can't make it in person? Join us online. ${schedule}`, {
      alignment: 'center',
    }),
    richtext(
      'live-embed',
      '<div style="position:relative;padding-bottom:56.25%;height:0;overflow:hidden;border-radius:0.75rem"><iframe src="https://www.youtube.com/embed/live_stream?channel=YOUR_CHANNEL_ID" style="position:absolute;top:0;left:0;width:100%;height:100%;border:0" allow="accelerometer;autoplay;encrypted-media;gyroscope;picture-in-picture" allowfullscreen></iframe></div><p style="text-align:center;margin-top:1rem;opacity:0.6">Replace the embed URL with your livestream link via the admin chat.</p>',
    ),
    cta(
      'live-archive',
      'Missed the livestream?',
      'Past sermons available with audio, video, and notes.',
      'Sermon Archive',
      '/sermons',
    ),
  ] as TemplatePageDef['blocks'],
});
