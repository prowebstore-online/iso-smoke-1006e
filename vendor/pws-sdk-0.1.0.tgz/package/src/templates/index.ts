// The product template registry. This is the single source of truth used by
// both the shared-CMS Worker and the isolated-site scaffold/fixture contract.
// Import from here to build templates from reusable parts too.
//
// Usage:
//   import { entities, pages, themes, h } from './lib/index.ts';
//   const myTemplate: TemplateBundle = {
//     schemas: [entities.teamMember(), entities.blogPost([...]), myCustomEntity],
//     pages: [pages.homePage(...), pages.listPage(...), pages.aboutPage(...)],
//     theme: themes.warmNeutral,
//   };

export * as entities from './entities.ts';
export * as pages from './pages.ts';
export * as themes from './themes.ts';
export * as h from './helpers.ts';
export { applyTemplateFixture, createTemplateFixture } from './fixture.ts';
export type { TemplateApplier, TemplateFixture } from './fixture.ts';

export { blogTemplate } from './catalog/blog.ts';
export { churchTemplate } from './catalog/church.ts';
export { contractorTemplate } from './catalog/contractor.ts';
export { corporateTemplate } from './catalog/corporate.ts';
export { ecommerceTemplate } from './catalog/ecommerce.ts';
export { galleryTemplate } from './catalog/gallery.ts';
export { podcastTemplate } from './catalog/podcast.ts';
export { portfolioTemplate } from './catalog/portfolio.ts';
export { professionalTemplate } from './catalog/professional.ts';
export { realEstateTemplate } from './catalog/real-estate.ts';
export { restaurantTemplate } from './catalog/restaurant.ts';
export { saasTemplate } from './catalog/saas.ts';
export { salonTemplate } from './catalog/salon.ts';

import type { TemplateBundle } from '@pws/shared';
import { blogTemplate } from './catalog/blog.ts';
import { churchTemplate } from './catalog/church.ts';
import { contractorTemplate } from './catalog/contractor.ts';
import { corporateTemplate } from './catalog/corporate.ts';
import { ecommerceTemplate } from './catalog/ecommerce.ts';
import { galleryTemplate } from './catalog/gallery.ts';
import { podcastTemplate } from './catalog/podcast.ts';
import { portfolioTemplate } from './catalog/portfolio.ts';
import { professionalTemplate } from './catalog/professional.ts';
import { realEstateTemplate } from './catalog/real-estate.ts';
import { restaurantTemplate } from './catalog/restaurant.ts';
import { saasTemplate } from './catalog/saas.ts';
import { salonTemplate } from './catalog/salon.ts';

/** Product templates consumed by every PWS runtime. Do not create a second registry. */
export const ALL_TEMPLATES: readonly TemplateBundle[] = [
  blogTemplate,
  portfolioTemplate,
  podcastTemplate,
  restaurantTemplate,
  professionalTemplate,
  ecommerceTemplate,
  salonTemplate,
  saasTemplate,
  contractorTemplate,
  churchTemplate,
  realEstateTemplate,
  galleryTemplate,
  corporateTemplate,
];

export function getTemplate(slug: string): TemplateBundle | undefined {
  return ALL_TEMPLATES.find((template) => template.slug === slug);
}

/** Return a known template or fail before a fixture/scaffold can drift to blank content. */
export function requireTemplate(slug: string): TemplateBundle {
  const template = getTemplate(slug);
  if (!template) throw new Error(`Unknown product template '${slug}'`);
  return template;
}
