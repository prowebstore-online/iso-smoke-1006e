// Transactional email — Resend HTTPS API.
// Ported from FAS: same provider, same pattern, but called server-side
// (Workers can call Resend directly, no intermediary API needed).
//
// Set RESEND_API_KEY and EMAIL_FROM as Worker secrets.
// Rate limit: 100/day on Resend free tier (3k/month).

export interface EmailConfig {
  apiKey: string;
  from: string;
}

export interface SendEmailOpts {
  to: string;
  subject: string;
  html: string;
  text?: string;
}

export async function sendEmail(cfg: EmailConfig, opts: SendEmailOpts): Promise<void> {
  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${cfg.apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      from: cfg.from,
      to: opts.to,
      subject: opts.subject,
      html: opts.html,
      text: opts.text ?? stripHtml(opts.html),
    }),
  });
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Email send failed: ${res.status} ${body.slice(0, 200)}`);
  }
}

/** Strip HTML tags for plain-text fallback. */
function stripHtml(html: string): string {
  return html
    .replace(/<[^>]*>/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

// ── Email templates ────────────────────────────────────────────────

export function welcomeEmail(siteName: string, memberName: string): SendEmailOpts {
  return {
    to: '', // caller fills this
    subject: `Welcome to ${siteName}`,
    html: `<div style="font-family:system-ui,sans-serif;max-width:500px;margin:0 auto;padding:2rem">
      <h1 style="font-size:1.5rem;margin-bottom:1rem">Welcome, ${esc(memberName)}!</h1>
      <p>You've joined <strong>${esc(siteName)}</strong>. Your account is ready.</p>
      <p style="margin-top:1.5rem;color:#666;font-size:0.85rem">If you didn't create this account, you can ignore this email.</p>
    </div>`,
  };
}

/** Resend config from a Worker env, or null when email is not configured. */
export function emailConfigFromEnv(env: {
  RESEND_API_KEY?: string;
  EMAIL_FROM?: string;
}): EmailConfig | null {
  if (!env.RESEND_API_KEY) return null;
  return {
    apiKey: env.RESEND_API_KEY,
    from: env.EMAIL_FROM ?? 'ProWebStore <noreply@prowebstore.online>',
  };
}

// Field values are visitor input of any record type — entity forms produce
// numbers and booleans, not only strings — so every value is stringified before
// escaping. Passing a number straight to esc() threw, and on the SDK route the
// throw happened before the redirect: a form with a number field 500'd.
export function formSubmissionNotification(
  siteName: string,
  formName: string,
  fields: Record<string, unknown>,
): SendEmailOpts {
  const rows = Object.entries(fields)
    .map(
      ([k, v]) =>
        `<tr><td style="padding:4px 8px;font-weight:600;vertical-align:top">${esc(k)}</td><td style="padding:4px 8px">${esc(String(v ?? ''))}</td></tr>`,
    )
    .join('');
  return {
    to: '', // caller fills this
    subject: `[${siteName}] New ${formName} submission`,
    html: `<div style="font-family:system-ui,sans-serif;max-width:500px;margin:0 auto;padding:2rem">
      <h2 style="font-size:1.25rem;margin-bottom:1rem">New ${esc(formName)} submission</h2>
      <table style="border-collapse:collapse;width:100%">${rows}</table>
      <p style="margin-top:1.5rem;color:#666;font-size:0.85rem">From ${esc(siteName)}</p>
    </div>`,
  };
}

/**
 * Tell a site's owners that a visitor submitted one of its forms (#48).
 *
 * Shared by both render stacks — `packages/worker/src/routes/tenant.ts` (the
 * shared tier) and `site-routes.ts` (the isolated tier, DECISIONS §22) — so the
 * feature `/pricing` sells behaves the same on either. Recipients are the site's
 * own `owner` users in its DO, not the D1 registry's owner_email.
 *
 * Callers run this under `executionCtx.waitUntil` AFTER the submission is
 * stored and never await it before responding: the owner lookup and the Resend
 * calls stay off the visitor's response path, and a mail failure can never
 * turn a stored submission into an error page. Resolves (never rejects) with
 * counts, so the one caller that wants them — tests — can read them.
 */
export async function notifyFormOwners(
  cfg: EmailConfig | null,
  stub: {
    siteSnapshot(): Promise<{ config: { title?: string } }>;
    listUsers(): Promise<Array<{ email: string; role: string }>>;
  },
  submission: { siteId: string; formName: string; fields: Record<string, unknown> },
): Promise<{ sent: number; failed: number }> {
  if (!cfg) return { sent: 0, failed: 0 };
  try {
    const [snap, users] = await Promise.all([stub.siteSnapshot(), stub.listUsers()]);
    const message = formSubmissionNotification(
      snap.config.title || submission.siteId,
      submission.formName,
      submission.fields,
    );
    const owners = users.filter((u) => u.role === 'owner');
    const results = await Promise.allSettled(
      owners.map((o) => sendEmail(cfg, { ...message, to: o.email })),
    );
    const sent = results.filter((r) => r.status === 'fulfilled').length;
    return { sent, failed: results.length - sent };
  } catch {
    return { sent: 0, failed: 0 };
  }
}

export function magicLinkEmail(siteId: string, verifyUrl: string): SendEmailOpts {
  return {
    to: '', // caller fills this
    subject: `Sign in to the ${siteId} admin`,
    html: `<div style="font-family:system-ui,sans-serif;max-width:480px;margin:0 auto;color:#111">
      <h2>Sign in</h2>
      <p>Click below to sign in to the <strong>${esc(siteId)}</strong> admin. This link expires in 15 minutes and can only be used once.</p>
      <p style="margin:20px 0"><a href="${esc(verifyUrl)}" style="background:#111;color:#fff;padding:10px 18px;border-radius:6px;text-decoration:none">Sign in &rarr;</a></p>
      <p style="color:#888;font-size:12px">If you didn't request this, you can ignore this email.</p>
    </div>`,
  };
}

function esc(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
