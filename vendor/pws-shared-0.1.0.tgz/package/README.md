# @pws/shared

Types, Zod schemas and validators shared by the ProWebStore platform and by
`@pws/sdk`: entities and fields, blocks, pages, theme, site meta, and the
record projector.

You normally do not depend on this directly — it is a dependency of
[`@pws/sdk`](https://www.npmjs.com/package/@pws/sdk), and the two are released
together at the same version.

Source-only TypeScript. Consume it through a bundler (wrangler/esbuild, Vite)
with `moduleResolution: "bundler"` and `allowImportingTsExtensions`.

Repository: https://github.com/prowebstore-online/platform (`packages/shared`)
