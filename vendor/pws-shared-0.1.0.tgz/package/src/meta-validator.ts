// Validate meta payloads (config / theme / nav / footer) at the API boundary.
// Without this, AI or external callers can poison the renderer with malformed
// objects (missing required fields) or attempt CSS injection via theme values.

import { z } from 'zod';
import type { AnalyticsConfig, FooterConfig, NavConfig, SiteConfig } from './pages.ts';
import type { Theme } from './theme.ts';

// Color values: hex (#abc, #aabbcc, #aabbccdd), rgb()/rgba(), oklch(), hsl()/hsla(),
// or a CSS named color (alpha lowercase letters only).
//
// Every branch is an ALLOWLIST of the characters that branch legitimately needs.
// It has to be: the value is interpolated into the <style> block by themeToCss(),
// and the only string that ends that element is `</style` — which needs no `;`,
// no `{` and no `(`. This comment used to claim a `; { } ( )` blocklist, but the
// oklch/hsl branches were `[^)]+`, i.e. anything at all without a `)`, so
// `oklch(</style><script src=…>)` validated and shipped (#37). The argument
// class below covers everything those functions take — digits, decimals, `%`,
// `/` for `oklch(70% 0.1 250 / 0.5)`, commas, whitespace, sign, and `deg`-style
// keywords — and excludes `<`, `>`, `;`, `{`, `}` and `*`.
// Keep the oklch() and hsl()/hsla() argument classes identical — they drifted
// from the comment once already, and that was the bug.
const COLOR_RE =
  /^(#[0-9a-fA-F]{3,8}|rgba?\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*(?:,\s*[\d.]+)?\s*\)|oklch\([0-9a-zA-Z.%,\/\s+-]+\)|hsla?\([0-9a-zA-Z.%,\/\s+-]+\)|[a-z]+)$/;
const safeColor = z.string().regex(COLOR_RE, 'invalid color value');

// Font family: letters, digits, spaces, commas, dots, dashes, underscores, quotes.
// The character class is an allowlist, so `;`, `{`, `}`, `<` and `>` are all
// excluded — `Inter</style><script>alert(1)</script>` is rejected here.
const FONT_RE = /^["']?[\w\-,.\s'"]+["']?$/;
const safeFont = z.string().regex(FONT_RE, 'invalid font value');

// BCP 47 language tag: 2-3 letter primary, optional subtags
const LOCALE_RE = /^[a-zA-Z]{2,3}(-[a-zA-Z0-9]{2,8})*$/;

const CommerceSchema = z
  .object({
    sellable_entity: z.string().min(1).max(63).optional(),
  })
  .strict();

const ConfigSchema = z
  .object({
    title: z.string().min(1).max(120),
    description: z.string().max(500).optional(),
    favicon_asset_id: z.string().optional(),
    primary_hostname: z.string().optional(),
    locale: z.string().regex(LOCALE_RE, 'invalid BCP 47 locale').optional(),
    commerce: CommerceSchema.optional(),
  })
  .strict() satisfies z.ZodType<SiteConfig>;

const NeutralSchema = z
  .object({
    50: safeColor.optional(),
    100: safeColor.optional(),
    200: safeColor.optional(),
    300: safeColor.optional(),
    400: safeColor.optional(),
    500: safeColor.optional(),
    600: safeColor.optional(),
    700: safeColor.optional(),
    800: safeColor.optional(),
    900: safeColor.optional(),
    950: safeColor.optional(),
  })
  .strict();

const ThemeSchema = z
  .object({
    colors: z
      .object({
        primary: safeColor,
        secondary: safeColor.optional(),
        accent: safeColor.optional(),
        background: safeColor,
        surface: safeColor.optional(),
        text: safeColor,
        heading: safeColor.optional(),
        neutral: NeutralSchema.optional(),
      })
      .strict(),
    fonts: z
      .object({
        heading: safeFont,
        body: safeFont,
      })
      .strict(),
    radius: z.enum(['none', 'sm', 'md', 'lg', 'full']).optional(),
    shadow: z.enum(['none', 'sm', 'md', 'lg']).optional(),
    spacing: z.enum(['compact', 'normal', 'relaxed']).optional(),
  })
  .strict() satisfies z.ZodType<Theme>;

const NavSchema = z
  .object({
    logo_text: z.string().max(60).optional(),
    logo_asset_id: z.string().optional(),
    style: z.enum(['minimal', 'standard', 'centered']).optional(),
    breadcrumbs: z.boolean().optional(),
  })
  .strict() satisfies z.ZodType<NavConfig>;

// Safe URL protocol check for footer links.
const safeUrl = z
  .string()
  .min(1)
  .refine(
    (v) => /^(?:https?:|mailto:|tel:|\/|#)/i.test(v.trim()),
    'URL must start with https:, http:, mailto:, tel:, /, or #',
  );

const FooterLink = z
  .object({
    label: z.string().min(1).max(60),
    url: safeUrl,
  })
  .strict();

const FooterSchema = z
  .object({
    copyright: z.string().max(200).optional(),
    links: z.array(FooterLink).max(20).optional(),
  })
  .strict() satisfies z.ZodType<FooterConfig>;

// Analytics — narrow validation per provider; custom snippet is creator-trusted
// (only the site owner can set it via authenticated admin endpoints) but capped
// at 4 KB so it can't blow up the rendered page.
const AnalyticsSchema = z
  .object({
    cf_beacon_token: z
      .string()
      .regex(/^[a-f0-9]{32,}$/i, 'invalid cf_beacon_token')
      .optional(),
    ga4: z
      .string()
      .regex(/^G-[A-Z0-9]{6,12}$/i, 'invalid ga4 measurement id')
      .optional(),
    plausible: z
      .string()
      .regex(/^[a-z0-9][a-z0-9.-]{0,253}\.[a-z]{2,}$/i, 'invalid plausible domain')
      .optional(),
    custom_head: z.string().max(4096, 'custom_head exceeds 4 KB').optional(),
  })
  .strict() satisfies z.ZodType<AnalyticsConfig>;

const WebhooksSchema = z.array(
  z.object({
    url: z.string().url(),
    events: z.array(z.string()),
    secret: z.string().optional(),
  }),
);

export type MetaKey = 'config' | 'theme' | 'nav' | 'footer' | 'analytics' | 'webhooks';

const META_SCHEMAS: Record<MetaKey, z.ZodTypeAny> = {
  config: ConfigSchema,
  theme: ThemeSchema,
  nav: NavSchema,
  footer: FooterSchema,
  analytics: AnalyticsSchema,
  webhooks: WebhooksSchema,
};

export interface MetaValidationOk<T> {
  ok: true;
  value: T;
}

export interface MetaValidationErr {
  ok: false;
  errors: Array<{ path: string; message: string; code: string }>;
}

export function validateMeta<T = unknown>(
  key: MetaKey,
  input: unknown,
): MetaValidationOk<T> | MetaValidationErr {
  const schema = META_SCHEMAS[key];
  if (!schema) {
    return {
      ok: false,
      errors: [{ path: '', message: `Unknown meta key '${key}'`, code: 'custom' }],
    };
  }
  const result = schema.safeParse(input);
  if (result.success) return { ok: true, value: result.data as T };
  return {
    ok: false,
    errors: result.error.issues.map((issue) => ({
      path: issue.path.map(String).join('.'),
      message: issue.message,
      code: issue.code,
    })),
  };
}
