// Generate a Zod validator at runtime from an EntitySchema's fields.
// Used on every add_record / update_record to validate input.

import { z } from 'zod';
import type { FieldDef, RecordData } from './types.ts';

const HEX_COLOR = /^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/;
const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;

function fieldValidator(field: FieldDef): z.ZodTypeAny {
  let v: z.ZodTypeAny;
  switch (field.type) {
    case 'text':
      // Generous cap — real content never hits it, but it stops the MCP/agent
      // write path (which, unlike the public HTML form, doesn't slice input) from
      // persisting an unbounded data_json blob.
      v = z.string().max(100_000);
      break;
    case 'richtext':
      // Stored as JSON-stringified Portable Text in v1.x; for now, opaque string.
      v = z.string().max(2_000_000);
      break;
    case 'number':
      v = z.number();
      break;
    case 'boolean':
      v = z.boolean();
      break;
    case 'date':
      v = z.string().regex(ISO_DATE, 'expected YYYY-MM-DD');
      break;
    case 'datetime':
      v = z.string().datetime({ offset: true });
      break;
    case 'email':
      v = z.string().email();
      break;
    case 'url':
      // z.string().url() accepts any parseable URI including javascript:/data:,
      // which become live hrefs when rendered — a stored-XSS vector for
      // public_writable form submissions. Restrict to safe schemes.
      v = z
        .string()
        .url()
        .refine(
          (u) => {
            try {
              return ['http:', 'https:', 'mailto:', 'tel:'].includes(new URL(u).protocol);
            } catch {
              return false;
            }
          },
          { message: 'url must use http, https, mailto, or tel' },
        );
      break;
    case 'phone':
      v = z.string().min(3);
      break;
    case 'image':
      v = z.object({
        asset_id: z.string().min(1),
        alt: z.string(),
        width: z.number().int().positive().optional(),
        height: z.number().int().positive().optional(),
      });
      break;
    case 'color':
      v = z.string().regex(HEX_COLOR, 'expected hex color e.g. #1a2b3c');
      break;
    case 'select':
      if (!field.options?.length) {
        throw new Error(`field '${field.slug}': select requires options`);
      }
      v = z.enum(field.options as [string, ...string[]]);
      break;
    case 'multiselect':
      if (!field.options?.length) {
        throw new Error(`field '${field.slug}': multiselect requires options`);
      }
      v = z.array(z.enum(field.options as [string, ...string[]])).max(1000);
      break;
    case 'reference':
      v = z.string().min(1).max(200); // record id of target entity
      break;
    case 'reference_list':
      v = z.array(z.string().min(1).max(200)).max(1000);
      break;
    default: {
      const _exhaustive: never = field.type;
      throw new Error(`unknown field type: ${_exhaustive}`);
    }
  }

  if (!field.required) {
    v = v.optional().nullable();
  }
  return v;
}

export function validatorForFields(fields: FieldDef[]) {
  const shape = Object.fromEntries(
    fields.map((f) => [f.slug, fieldValidator(f)] as const),
  ) as Record<string, z.ZodTypeAny>;
  // Allow no extra keys; AI must use known fields only.
  return z.object(shape).strict();
}

export interface ValidationOk {
  ok: true;
  data: RecordData;
}

export interface ValidationErr {
  ok: false;
  errors: Array<{ path: string; message: string; code: string }>;
}

export function validateRecord(fields: FieldDef[], input: unknown): ValidationOk | ValidationErr {
  const validator = validatorForFields(fields);
  const result = validator.safeParse(input);
  if (result.success) {
    return { ok: true, data: result.data as RecordData };
  }
  return {
    ok: false,
    errors: result.error.issues.map((issue) => ({
      path: issue.path.join('.'),
      message: issue.message,
      code: issue.code,
    })),
  };
}
