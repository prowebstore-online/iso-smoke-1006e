// Template bundles — fully fledged starter sites with entities, records, pages, and theme.

import type { Block } from './blocks.ts';
import type { FooterConfig, NavConfig, SeoConfig, SiteConfig } from './pages.ts';
import type { Theme } from './theme.ts';
import type { FieldDef, RecordData } from './types.ts';

export interface TemplateEntityDef {
  slug: string;
  name: string;
  name_plural: string;
  icon?: string;
  fields: FieldDef[];
  public_writable?: boolean;
}

export interface TemplatePageDef {
  slug: string;
  title: string;
  page_type: string;
  blocks: Block[];
  seo?: SeoConfig;
  show_in_nav?: boolean;
  nav_label?: string;
  nav_order?: number;
}

export interface AdminViewDef {
  entity_slug: string;
  label: string;
  icon?: string;
  layout?: string;
  sort_order?: number;
  config?: Record<string, unknown>;
}

export interface AdminWidgetDef {
  widget_type: string;
  label: string;
  config?: Record<string, unknown>;
  sort_order?: number;
}

export interface TemplateBundle {
  slug: string;
  name: string;
  description: string;
  icon: string;
  verticals: string[];
  combines_with: string[];

  schemas: TemplateEntityDef[];
  records: Record<string, RecordData[]>;
  pages: TemplatePageDef[];
  theme: Partial<Theme>;
  config: Partial<SiteConfig>;
  nav: Partial<NavConfig>;
  footer: Partial<FooterConfig>;
  admin_views?: AdminViewDef[];
  admin_widgets?: AdminWidgetDef[];
}
