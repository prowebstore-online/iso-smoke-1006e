// Schema evolution: fold a set of field changes into an entity's existing fields.
//
// `updateEntityFields` REPLACES the whole `fields` array, so a caller that hands it
// only the field it wants to add erases every other field definition on a live
// entity. This is the additive layer in front of it (#47): fields not named in
// `changes` are kept untouched, a named field that exists is patched, and a new
// one is appended.
//
// Records are never migrated — `projectRecord` fills a new field with its default
// (or null) on read. What this refuses is every change that would make an
// existing record fail validation on its next write, because that failure lands
// on the owner later, somewhere unrelated, with no undo:
//   - a new field marked required (old records do not have it);
//   - an existing field turned required;
//   - an existing field's type or reference target changed;
//   - a select option taken away (options are unioned, never replaced).
// Removing a field is not offered at all (#47 step 5).

import type { FieldDef } from './types.ts';

export type EvolveFieldsResult =
  | { ok: true; fields: FieldDef[]; added: string[]; updated: string[] }
  | { ok: false; error: string };

export function evolveFields(current: FieldDef[], changes: FieldDef[]): EvolveFieldsResult {
  const fields = [...current];
  const added: string[] = [];
  const updated: string[] = [];

  for (const change of changes) {
    const idx = fields.findIndex((f) => f.slug === change.slug);
    const existing = fields[idx];

    if (!existing) {
      if (change.required) {
        return {
          ok: false,
          error: `New field '${change.slug}' cannot be required: existing records have no value for it, so the next edit of any of them would fail. Add it as optional.`,
        };
      }
      fields.push(change);
      added.push(change.slug);
      continue;
    }

    if (change.type !== existing.type) {
      return {
        ok: false,
        error: `Field '${change.slug}' is '${existing.type}'; changing its type to '${change.type}' would break existing records. Add a new field instead.`,
      };
    }
    if (change.reference_to !== undefined && change.reference_to !== existing.reference_to) {
      return {
        ok: false,
        error: `Field '${change.slug}' references '${existing.reference_to}'; its target cannot be changed. Add a new field instead.`,
      };
    }
    if (change.required && !existing.required) {
      return {
        ok: false,
        error: `Field '${change.slug}' cannot be made required: existing records may have no value for it.`,
      };
    }

    const options = existing.options
      ? [
          ...existing.options,
          ...(change.options ?? []).filter((o) => !existing.options?.includes(o)),
        ]
      : change.options;
    fields[idx] = {
      ...existing,
      ...change,
      required: existing.required,
      reference_to: existing.reference_to,
      ...(options ? { options } : {}),
    };
    updated.push(change.slug);
  }

  return { ok: true, fields, added, updated };
}
