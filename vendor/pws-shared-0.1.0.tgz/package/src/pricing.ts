// The one per-site subscription (#49). PWS sells a single plan per site; there
// are no tiers (`packages/worker/src/entitlement.ts`: a site is comped or
// subscribed, and nothing else).
//
// What the customer is CHARGED is Stripe's price object STRIPE_PRICE_ID
// (`packages/worker/wrangler.toml`), created at $10/mo in 02b8b00 ("reprice the
// per-site Website plan to $10/mo"). This constant is only the DISPLAYED price,
// so it must equal that. Change it only together with a new Stripe price.
//
// The marketing site cannot import it (it deliberately has no workspace deps),
// so `scripts/pricing-consistency.test.ts` pins every copy of the price —
// pricing.astro, the README, the wrangler/env comments — to this value.

export const PRICE_PER_SITE_USD = 10;

/** "$10/mo" — the label every console surface shows. */
export const PRICE_PER_SITE_LABEL = `$${PRICE_PER_SITE_USD}/mo`;
