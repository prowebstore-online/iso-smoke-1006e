// Core CMS types shared between worker and admin.

export const FIELD_TYPES = [
  'text',
  'richtext',
  'number',
  'boolean',
  'date',
  'datetime',
  'email',
  'url',
  'phone',
  'image',
  'color',
  'select',
  'multiselect',
  'reference',
  'reference_list',
] as const;

export type FieldType = (typeof FIELD_TYPES)[number];

export interface FieldDef {
  slug: string;
  name: string;
  type: FieldType;
  required?: boolean;
  default?: unknown;
  options?: string[]; // for select / multiselect
  reference_to?: string; // entity slug for reference / reference_list
  description?: string;
}

export interface EntitySchema {
  slug: string;
  name: string;
  name_plural: string;
  icon?: string | null;
  fields: FieldDef[];
  source_template?: string | null;
  version: number;
  system_managed: boolean;
  public_writable: boolean;
  created_at: string;
  updated_at: string;
}

export interface ImageValue {
  asset_id: string;
  alt: string;
  width?: number;
  height?: number;
}

export type FieldValue = string | number | boolean | string[] | ImageValue | null | undefined;

export type RecordData = Record<string, FieldValue>;

export interface EntityRecord {
  id: string;
  entity_slug: string;
  slug: string | null;
  data: RecordData;
  schema_version: number;
  status: 'live' | 'archived';
  created_at: string;
  updated_at: string;
  created_by: string | null;
}

export type RecordStatus = 'live' | 'archived';
