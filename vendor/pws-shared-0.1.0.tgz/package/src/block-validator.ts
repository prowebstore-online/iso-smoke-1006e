// Validate Block instances at the API boundary so malformed input never
// reaches the renderer (where a default:never switch would otherwise crash).

import { z } from 'zod';
import type { Block } from './blocks.ts';

// URL fields rendered into href/src attributes — only safe protocols allowed.
const safeUrl = z
  .string()
  .refine(
    (v) => /^(?:https?:|mailto:|tel:|\/|#)/i.test(v.trim()),
    'URL must start with https:, http:, mailto:, tel:, /, or #',
  );

// Color values safe for style="" attributes — hex, rgb(), hsl(), oklch(), named.
const safeColor = z
  .string()
  .regex(
    /^(#[0-9a-fA-F]{3,8}|rgba?\(\s*[\d.,\s%]+\)|oklch\([^;{}]+\)|hsla?\([^;{}]+\)|[a-z]+)$/,
    'invalid color value',
  );

const ImageRef = z.object({
  asset_id: z.string().min(1),
  alt: z.string(),
  width: z.number().int().positive().optional(),
  height: z.number().int().positive().optional(),
});

const BlockBase = {
  id: z.string().min(1),
  variant: z.string().optional(),
  label: z.string().optional(),
  visible: z.boolean().optional(),
};

const Hero = z.object({
  ...BlockBase,
  _type: z.literal('hero'),
  heading: z.string(),
  subheading: z.string().optional(),
  cta_text: z.string().optional(),
  cta_url: safeUrl.optional(),
  cta2_text: z.string().optional(),
  cta2_url: safeUrl.optional(),
  bg_image: ImageRef.optional(),
  alignment: z.enum(['left', 'center', 'right']).optional(),
});

const RichText = z.object({
  ...BlockBase,
  _type: z.literal('richtext'),
  body: z.string(),
});

const Cta = z.object({
  ...BlockBase,
  _type: z.literal('cta'),
  heading: z.string(),
  text: z.string().optional(),
  cta_text: z.string(),
  cta_url: safeUrl,
  bg_color: safeColor.optional(),
});

const ImageBlockZ = z.object({
  ...BlockBase,
  _type: z.literal('image_block'),
  image: ImageRef,
  caption: z.string().optional(),
});

const EntityGrid = z.object({
  ...BlockBase,
  _type: z.literal('entity_grid'),
  heading: z.string().optional(),
  entity: z.string().min(1),
  filter: z.record(z.string(), z.unknown()).optional(),
  sort: z
    .object({
      field: z.string(),
      dir: z.enum(['asc', 'desc']),
    })
    .optional(),
  limit: z.number().int().positive().optional(),
  display_fields: z.array(z.string()),
  layout: z.enum(['grid', 'cards', 'compact']).optional(),
  columns: z.number().int().min(1).max(6).optional(),
});

const Features = z.object({
  ...BlockBase,
  _type: z.literal('features'),
  heading: z.string().optional(),
  subheading: z.string().optional(),
  items: z.array(
    z.object({
      icon: z.string().optional(),
      title: z.string(),
      description: z.string(),
    }),
  ),
});

const Cards = z.object({
  ...BlockBase,
  _type: z.literal('cards'),
  heading: z.string().optional(),
  items: z.array(
    z.object({
      image: ImageRef.optional(),
      title: z.string(),
      description: z.string(),
      link: safeUrl.optional(),
    }),
  ),
});

const Testimonials = z.object({
  ...BlockBase,
  _type: z.literal('testimonials'),
  heading: z.string().optional(),
  items: z.array(
    z.object({
      quote: z.string(),
      author: z.string(),
      role: z.string().optional(),
      avatar: ImageRef.optional(),
      rating: z.number().int().min(1).max(5).optional(),
    }),
  ),
});

const Faq = z.object({
  ...BlockBase,
  _type: z.literal('faq'),
  heading: z.string().optional(),
  items: z.array(
    z.object({
      question: z.string(),
      answer: z.string(),
    }),
  ),
});

const Team = z.object({
  ...BlockBase,
  _type: z.literal('team'),
  heading: z.string().optional(),
  members: z.array(
    z.object({
      name: z.string(),
      role: z.string(),
      bio: z.string().optional(),
      image: ImageRef.optional(),
      social: z.record(z.string(), safeUrl).optional(),
    }),
  ),
});

const PricingTable = z.object({
  ...BlockBase,
  _type: z.literal('pricing_table'),
  heading: z.string().optional(),
  plans: z.array(
    z.object({
      name: z.string(),
      price: z.string(),
      period: z.string().optional(),
      features: z.array(z.string()),
      cta_text: z.string().optional(),
      cta_url: safeUrl.optional(),
      highlighted: z.boolean().optional(),
    }),
  ),
});

const FormFieldType = z.enum([
  'text',
  'email',
  'tel',
  'textarea',
  'select',
  'checkbox',
  'number',
  'url',
]);

const FormZ = z.object({
  ...BlockBase,
  _type: z.literal('form'),
  heading: z.string().optional(),
  description: z.string().optional(),
  entity_slug: z.string().optional(),
  fields: z.array(
    z.object({
      name: z.string(),
      type: FormFieldType,
      label: z.string(),
      required: z.boolean().optional(),
      placeholder: z.string().optional(),
      options: z.array(z.string()).optional(),
    }),
  ),
  submit_label: z.string(),
});

const Gallery = z.object({
  ...BlockBase,
  _type: z.literal('gallery'),
  heading: z.string().optional(),
  images: z.array(
    z.object({
      url: safeUrl,
      alt: z.string(),
      caption: z.string().optional(),
    }),
  ),
});

const Divider = z.object({
  ...BlockBase,
  _type: z.literal('divider'),
  style: z.enum(['line', 'space', 'gradient']),
});

const CustomHtml = z.object({
  ...BlockBase,
  _type: z.literal('custom_html'),
  html: z.string(),
});

const ProductGrid = z.object({
  ...BlockBase,
  _type: z.literal('product_grid'),
  heading: z.string().optional(),
  entity: z.string().min(1),
  filter: z.record(z.string(), z.unknown()).optional(),
  sort: z
    .object({
      field: z.string(),
      dir: z.enum(['asc', 'desc']),
    })
    .optional(),
  limit: z.number().int().positive().optional(),
  columns: z.number().int().min(1).max(6).optional(),
  cart_url: safeUrl.optional(),
  image_fit: z.enum(['cover', 'contain']).optional(),
});

const Cart = z.object({
  ...BlockBase,
  _type: z.literal('cart'),
  heading: z.string().optional(),
  empty_message: z.string().optional(),
  checkout_text: z.string().optional(),
  continue_shopping_url: safeUrl.optional(),
  checkout_url: safeUrl.optional(),
});

const Checkout = z.object({
  ...BlockBase,
  _type: z.literal('checkout'),
  heading: z.string().optional(),
  continue_shopping_url: safeUrl.optional(),
});

export const BlockSchema = z.discriminatedUnion('_type', [
  Hero,
  RichText,
  Cta,
  ImageBlockZ,
  EntityGrid,
  Features,
  Cards,
  Testimonials,
  Faq,
  Team,
  PricingTable,
  FormZ,
  Gallery,
  Divider,
  CustomHtml,
  ProductGrid,
  Cart,
  Checkout,
]);

export const BlocksSchema = z.array(BlockSchema);

export interface BlocksValidationOk {
  ok: true;
  blocks: Block[];
}

export interface BlocksValidationErr {
  ok: false;
  errors: Array<{ path: string; message: string; code: string }>;
}

export function validateBlocks(input: unknown): BlocksValidationOk | BlocksValidationErr {
  const result = BlocksSchema.safeParse(input);
  if (result.success) {
    return { ok: true, blocks: result.data as Block[] };
  }
  return {
    ok: false,
    errors: result.error.issues.map((issue) => ({
      path: issue.path.map(String).join('.'),
      message: issue.message,
      code: issue.code,
    })),
  };
}
