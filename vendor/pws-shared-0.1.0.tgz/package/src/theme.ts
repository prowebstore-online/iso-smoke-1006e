// Site theme — design tokens consumed by every block renderer.
// Renderers MUST use only these tokens (CSS custom properties);
// hardcoded colors / fonts in renderers are bugs.

export type RadiusToken = 'none' | 'sm' | 'md' | 'lg' | 'full';
export type ShadowToken = 'none' | 'sm' | 'md' | 'lg';
export type SpacingToken = 'compact' | 'normal' | 'relaxed';

export interface ThemeColors {
  primary: string;
  secondary?: string;
  accent?: string;
  background: string;
  surface?: string;
  text: string;
  heading?: string;
  neutral?: Partial<
    Record<
      '50' | '100' | '200' | '300' | '400' | '500' | '600' | '700' | '800' | '900' | '950',
      string
    >
  >;
}

export interface Theme {
  colors: ThemeColors;
  fonts: {
    heading: string;
    body: string;
  };
  radius?: RadiusToken;
  shadow?: ShadowToken;
  spacing?: SpacingToken;
}

// Default theme is dark — matches the marketing site default. Tenants can
// override via setMeta('theme', ...). The neutral scale is intentionally
// reversed vs. the conventional light scale: token semantics are positional
// (50 = "lightest backdrop, closest to bg", 950 = "highest contrast vs bg"),
// so under a dark background "50" is a near-black surface and "950" is white.
export const DEFAULT_THEME: Theme = {
  colors: {
    primary: '#a78bfa',
    secondary: '#e2e8f0',
    accent: '#fbbf24',
    background: '#0b1020',
    surface: '#131a2e',
    text: '#e6edf7',
    heading: '#f8fafc',
    neutral: {
      '50': '#0f172a',
      '100': '#131a2e',
      '200': '#1e293b',
      '300': '#334155',
      '400': '#475569',
      '500': '#64748b',
      '600': '#94a3b8',
      '700': '#cbd5e1',
      '800': '#e2e8f0',
      '900': '#f1f5f9',
      '950': '#f8fafc',
    },
  },
  fonts: {
    heading: 'Inter, ui-sans-serif, system-ui, sans-serif',
    body: 'Inter, ui-sans-serif, system-ui, sans-serif',
  },
  radius: 'md',
  shadow: 'sm',
  spacing: 'normal',
};
