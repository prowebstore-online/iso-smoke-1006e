// Pages — ordered collections of blocks under a slug.

import type { Block } from './blocks.ts';

export interface SeoConfig {
  title?: string;
  description?: string;
  og_image_asset_id?: string;
  noindex?: boolean;
}

export interface Page {
  id: string;
  slug: string; // "/" for home, "/about", "/shop/:product"
  title: string;
  page_type: string; // "home", "about", "shop", etc.
  blocks: Block[];
  seo?: SeoConfig | null;
  show_in_nav: boolean;
  nav_label?: string | null;
  nav_order: number;
  auth_required: boolean;
  created_at: string;
  updated_at: string;
}

/** Lightweight page metadata for navigation — no blocks or seo. */
export interface NavPage {
  id: string;
  slug: string;
  title: string;
  page_type: string;
  show_in_nav: boolean;
  nav_label?: string | null;
  nav_order: number;
  auth_required: boolean;
  created_at: string;
  updated_at: string;
}
export interface SiteConfig {
  title: string;
  description?: string;
  favicon_asset_id?: string;
  primary_hostname?: string; // e.g. "lifehouse.prowebstore.online"
  locale?: string; // BCP 47 language tag, e.g. "en", "es", "fr", "de", "zh-CN"
  commerce?: CommerceConfig;
}

/**
 * Commerce wiring for a storefront. The cart → checkout → order loop keys off the
 * sellable entity named here; everything else (price in cents, availability) is by
 * field convention so a store only has to declare the entity slug.
 *
 * Field conventions on the sellable entity:
 * - `price` (number, cents) — required; what checkout re-prices against.
 * - `stock` (number) — optional tracked inventory: checkout enforces availability
 *   and decrements it, and the storefront shows "sold out" at 0.
 * - `in_stock` (boolean) — optional manual availability flag (no quantity); used
 *   when there is no `stock` field (e.g. 1-of-1 goods toggled by the owner).
 */
export interface CommerceConfig {
  /** Slug of the sellable entity. Defaults to `product` when omitted. */
  sellable_entity?: string;
}

/** The sellable-entity slug for a site, with the platform default. */
export const DEFAULT_SELLABLE_ENTITY = 'product';
export function sellableEntityOf(config: Pick<SiteConfig, 'commerce'>): string {
  return config.commerce?.sellable_entity || DEFAULT_SELLABLE_ENTITY;
}

export interface NavConfig {
  logo_text?: string;
  logo_asset_id?: string;
  style?: 'minimal' | 'standard' | 'centered';
  breadcrumbs?: boolean;
}

export interface FooterConfig {
  copyright?: string;
  links?: Array<{ label: string; url: string }>;
}

export interface AnalyticsConfig {
  /** Cloudflare Web Analytics site token. Auto-provisioned at site creation; cookieless, no PII. */
  cf_beacon_token?: string;
  /** Google Analytics 4 measurement ID (G-XXXXXXXXXX). */
  ga4?: string;
  /** Plausible domain (e.g. "mysite.com"). Loads from plausible.io. */
  plausible?: string;
  /** Free-form additional <head> snippet for advanced tags. Capped at 4 KB. */
  custom_head?: string;
}

// Block-level edits: pure operations on a page's block list, shared by the admin
// API's /pages/blocks/* routes and the site chat's block tools so the two cannot
// drift. Each returns the new list; the caller writes it back through
// upsertPage, which validates it and banks the previous version as a revision.

export type BlockEditResult =
  | { ok: true; blocks: Block[] }
  | { ok: false; error: string; status: 404 | 409 };

export function insertBlock(blocks: Block[], block: Block, position?: number): BlockEditResult {
  if (blocks.some((b) => b.id === block.id)) {
    return { ok: false, error: `Block '${block.id}' already exists`, status: 409 };
  }
  const next = [...blocks];
  const pos = Math.max(0, position ?? next.length);
  next.splice(Math.min(pos, next.length), 0, block);
  return { ok: true, blocks: next };
}

/** Shallow-merge `updates` into one block. `id` and `_type` cannot be changed. */
export function patchBlock(
  blocks: Block[],
  blockId: string,
  updates: Record<string, unknown>,
): BlockEditResult {
  if (!blocks.some((b) => b.id === blockId)) {
    return { ok: false, error: `Block '${blockId}' not found`, status: 404 };
  }
  return {
    ok: true,
    blocks: blocks.map((b) =>
      b.id === blockId ? ({ ...b, ...updates, id: b.id, _type: b._type } as Block) : b,
    ),
  };
}

export function removeBlock(blocks: Block[], blockId: string): BlockEditResult {
  const next = blocks.filter((b) => b.id !== blockId);
  if (next.length === blocks.length) {
    return { ok: false, error: `Block '${blockId}' not found`, status: 404 };
  }
  return { ok: true, blocks: next };
}

/** Move a block to `position` (0-based, clamped to the list). */
export function moveBlock(blocks: Block[], blockId: string, position: number): BlockEditResult {
  const idx = blocks.findIndex((b) => b.id === blockId);
  if (idx === -1) return { ok: false, error: `Block '${blockId}' not found`, status: 404 };
  const next = [...blocks];
  const [block] = next.splice(idx, 1);
  next.splice(Math.max(0, Math.min(position, next.length)), 0, block!);
  return { ok: true, blocks: next };
}
