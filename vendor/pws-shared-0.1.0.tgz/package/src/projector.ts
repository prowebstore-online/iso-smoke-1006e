// Lazy projection: project a record's stored data through the current schema.
// Records carry their schema_version; the current schema is what the renderer
// (and the AI) actually sees. This lets us add/remove fields instantly without
// touching existing records.

import type { FieldDef, RecordData } from './types.ts';

/**
 * Project a record's data through the current schema.
 *
 * - Fields present in the schema but missing from data → use field default (or null)
 * - Fields present in data but no longer in schema → dropped from output
 * - Field values are passed through as-is (no type coercion in v1)
 *
 * Pure function. Does not mutate input.
 */
export function projectRecord(storedData: RecordData, currentFields: FieldDef[]): RecordData {
  const out: RecordData = {};
  for (const field of currentFields) {
    if (field.slug in storedData) {
      out[field.slug] = storedData[field.slug];
    } else if (field.default !== undefined) {
      out[field.slug] = field.default as RecordData[string];
    } else {
      out[field.slug] = null;
    }
  }
  return out;
}
