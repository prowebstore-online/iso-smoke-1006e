// Block types — the building blocks of pages.
// Pure data; renderers (per block type) live in the worker package.

import type { ImageValue } from './types.ts';

export interface BlockBase {
  id: string;
  variant?: string;
  label?: string;
  visible?: boolean;
}

export interface HeroBlock extends BlockBase {
  _type: 'hero';
  heading: string;
  subheading?: string;
  cta_text?: string;
  cta_url?: string;
  cta2_text?: string;
  cta2_url?: string;
  bg_image?: ImageValue;
  alignment?: 'left' | 'center' | 'right';
}

export interface RichTextBlock extends BlockBase {
  _type: 'richtext';
  body: string; // HTML string in v1; Portable Text JSON in v1.x.
}

export interface CtaBlock extends BlockBase {
  _type: 'cta';
  heading: string;
  text?: string;
  cta_text: string;
  cta_url: string;
  bg_color?: string;
}

export interface ImageBlockBlock extends BlockBase {
  _type: 'image_block';
  image: ImageValue;
  caption?: string;
}

export interface EntityGridBlock extends BlockBase {
  _type: 'entity_grid';
  heading?: string;
  entity: string;
  filter?: Record<string, unknown>;
  sort?: { field: string; dir: 'asc' | 'desc' };
  limit?: number;
  display_fields: string[];
  layout?: 'grid' | 'cards' | 'compact';
  columns?: number;
}

export interface FeaturesBlock extends BlockBase {
  _type: 'features';
  heading?: string;
  subheading?: string;
  items: Array<{ icon?: string; title: string; description: string }>;
}

export interface CardsBlock extends BlockBase {
  _type: 'cards';
  heading?: string;
  items: Array<{ image?: ImageValue; title: string; description: string; link?: string }>;
}

export interface TestimonialsBlock extends BlockBase {
  _type: 'testimonials';
  heading?: string;
  items: Array<{
    quote: string;
    author: string;
    role?: string;
    avatar?: ImageValue;
    rating?: 1 | 2 | 3 | 4 | 5;
  }>;
}

export interface FaqBlock extends BlockBase {
  _type: 'faq';
  heading?: string;
  items: Array<{ question: string; answer: string }>;
}

export interface TeamBlock extends BlockBase {
  _type: 'team';
  heading?: string;
  members: Array<{
    name: string;
    role: string;
    bio?: string;
    image?: ImageValue;
    social?: Record<string, string>;
  }>;
}

export interface PricingTableBlock extends BlockBase {
  _type: 'pricing_table';
  heading?: string;
  plans: Array<{
    name: string;
    price: string;
    period?: string;
    features: string[];
    cta_text?: string;
    cta_url?: string;
    highlighted?: boolean;
  }>;
}

export type FormFieldType =
  | 'text'
  | 'email'
  | 'tel'
  | 'textarea'
  | 'select'
  | 'checkbox'
  | 'number'
  | 'url';

export interface FormBlock extends BlockBase {
  _type: 'form';
  heading?: string;
  description?: string;
  entity_slug?: string;
  fields: Array<{
    name: string;
    type: FormFieldType;
    label: string;
    required?: boolean;
    placeholder?: string;
    options?: string[];
  }>;
  submit_label: string;
}

export interface GalleryBlock extends BlockBase {
  _type: 'gallery';
  heading?: string;
  images: Array<{ url: string; alt: string; caption?: string }>;
}

export interface DividerBlock extends BlockBase {
  _type: 'divider';
  style: 'line' | 'space' | 'gradient';
}

export interface CustomHtmlBlock extends BlockBase {
  _type: 'custom_html';
  html: string;
}

export interface ProductGridBlock extends BlockBase {
  _type: 'product_grid';
  heading?: string;
  entity: string;
  filter?: Record<string, unknown>;
  sort?: { field: string; dir: 'asc' | 'desc' };
  limit?: number;
  columns?: number;
  cart_url?: string;
  /** How tile images fit their frame. 'contain' (art — never crop) or 'cover' (products). Default 'cover'. */
  image_fit?: 'cover' | 'contain';
}

export interface CartBlock extends BlockBase {
  _type: 'cart';
  heading?: string;
  empty_message?: string;
  checkout_text?: string;
  continue_shopping_url?: string;
  /** Where the checkout button navigates. Defaults to /checkout. */
  checkout_url?: string;
}

export interface CheckoutBlock extends BlockBase {
  _type: 'checkout';
  heading?: string;
  /** Where to send the shopper if their cart is empty. Defaults to /. */
  continue_shopping_url?: string;
}

export type Block =
  | HeroBlock
  | RichTextBlock
  | CtaBlock
  | ImageBlockBlock
  | EntityGridBlock
  | FeaturesBlock
  | CardsBlock
  | TestimonialsBlock
  | FaqBlock
  | TeamBlock
  | PricingTableBlock
  | FormBlock
  | GalleryBlock
  | DividerBlock
  | CustomHtmlBlock
  | ProductGridBlock
  | CartBlock
  | CheckoutBlock;

export type BlockType = Block['_type'];
